# Intranet SOFIPO · Paso 3c: permiso para ligar categoría, área y audiencia

## Causa

Dataverse respondió: *"No tiene permiso para asociar o desasociar la tabla cre1f_categoriaaviso para cre1f_aviso"* (código 90040106). Los permisos de Admin RH tenían **Anexar** solo en Aviso y **Anexar a** solo en las tablas relacionadas. La Web API de Power Pages exige ambos privilegios en los dos lados de la relación.

## Contenido

| Archivo | Cambio |
|---|---|
| `table-permissions/PublicacionAvisos.tablepermission.yml` | Agrega **Anexar a** (ya tenía Lectura, Crear, Escribir y Anexar) |
| `table-permissions/PublicacionCategoriasAviso…`, `PublicacionAreas…`, `PublicacionAudiencias…` | Agrega **Anexar** (ya tenían Lectura y Anexar a) |
| `web-templates/sofipo-publicacion-avisos/…source.html` | Los errores de permiso ahora muestran el detalle que envía el servidor |

Sigue sin darse **Eliminar** ni **Escribir** sobre catálogos: Admin RH no puede modificar categorías, áreas ni audiencias desde el sitio.

## Aplicar

1. Copia el contenido de `intranet-sofipo` sobre tu carpeta de **Portal v7** y acepta reemplazar.
2. `pac pages upload --path ./intranet-sofipo`
3. Estudio → **Sincronizar** → `https://<tu-sitio>/_services/about` → **Clear cache**.
4. Verifica en Estudio → Seguridad → **Permisos de tabla**:
   - PublicacionAvisos: Lectura, Crear, Escribir, **Anexar** y **Anexar a**.
   - PublicacionCategoriasAviso, PublicacionAreas y PublicacionAudiencias: Lectura, **Anexar** y **Anexar a**.
   Si alguno no cambió, marca la casilla en esa pantalla.
5. Si aún existen los permisos creados a mano (Aviso publicacion, Categoría anexar, Área anexar, Audiencia anexar), elimínalos.

## Probar

Crea un aviso con categoría, área y portada, y edita otro cambiando su categoría y quitando su área. Si aparece un error, el diálogo ahora muestra el detalle completo.
