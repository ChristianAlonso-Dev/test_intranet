(function () {
  'use strict';

  var PAGE_SIZE = 6;

  function normalize(value) {
    return (value || '')
      .toString()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .trim();
  }

  function createIcon(name) {
    var icon = document.createElement('span');
    icon.className = 'sf-ico sf-ico--' + name;
    icon.setAttribute('aria-hidden', 'true');
    return icon;
  }

  function buildPager(container, totalPages, currentPage, onSelect) {
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    if (totalPages <= 1) {
      container.hidden = true;
      return;
    }

    var list = document.createElement('ul');
    list.className = 'sf-pager__list';

    function addButton(label, page, options) {
      var item = document.createElement('li');
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'sf-pager__btn';
      if (options.icon) {
        button.appendChild(createIcon(options.icon));
        button.setAttribute('aria-label', label);
      } else {
        button.textContent = label;
        button.setAttribute('aria-label', 'Página ' + label);
      }
      if (options.current) {
        button.setAttribute('aria-current', 'page');
      }
      if (options.disabled) {
        button.disabled = true;
      } else {
        button.addEventListener('click', function () {
          onSelect(page);
        });
      }
      item.appendChild(button);
      list.appendChild(item);
    }

    addButton('Página anterior', currentPage - 1, { icon: 'chevron-left', disabled: currentPage === 1 });
    for (var page = 1; page <= totalPages; page += 1) {
      addButton(String(page), page, { current: page === currentPage });
    }
    addButton('Página siguiente', currentPage + 1, { icon: 'chevron-right', disabled: currentPage === totalPages });

    container.appendChild(list);
    container.hidden = false;
  }

  function init() {
    var root = document.querySelector('[data-sf-news]');
    if (!root) {
      return;
    }

    var items = Array.prototype.slice.call(root.querySelectorAll('[data-sf-item]'));
    var search = root.querySelector('[data-sf-search]');
    var chips = Array.prototype.slice.call(root.querySelectorAll('[data-sf-filter]'));
    var counter = root.querySelector('[data-sf-counter]');
    var list = root.querySelector('[data-sf-list]');
    var empty = root.querySelector('[data-sf-empty]');
    var reset = root.querySelector('[data-sf-reset]');
    var pager = root.querySelector('[data-sf-pager]');
    var validCategories = chips.map(function (chip) {
      return chip.getAttribute('data-sf-filter');
    });

    var index = items.map(function (item) {
      return {
        element: item,
        id: item.getAttribute('data-sf-id'),
        category: item.getAttribute('data-sf-categoria'),
        text: normalize(item.textContent)
      };
    });

    var state = { category: 'todas', query: '', page: 1 };

    function matches(entry) {
      var categoryOk = state.category === 'todas' || entry.category === state.category;
      var queryOk = !state.query || entry.text.indexOf(state.query) !== -1;
      return categoryOk && queryOk;
    }

    function render() {
      var visible = index.filter(matches);
      var totalPages = Math.max(1, Math.ceil(visible.length / PAGE_SIZE));
      state.page = Math.min(Math.max(1, state.page), totalPages);
      var start = (state.page - 1) * PAGE_SIZE;
      var pageItems = visible.slice(start, start + PAGE_SIZE);

      index.forEach(function (entry) {
        entry.element.hidden = pageItems.indexOf(entry) === -1;
      });

      chips.forEach(function (chip) {
        var active = chip.getAttribute('data-sf-filter') === state.category;
        chip.setAttribute('aria-pressed', active ? 'true' : 'false');
      });

      if (counter) {
        counter.textContent = 'Mostrando ' + pageItems.length + ' de ' + visible.length + (visible.length === 1 ? ' noticia' : ' noticias');
      }
      if (list) {
        list.hidden = visible.length === 0;
      }
      if (empty) {
        empty.hidden = visible.length !== 0;
      }
      if (pager) {
        buildPager(pager, visible.length ? totalPages : 0, state.page, function (page) {
          state.page = page;
          render();
          root.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
      }
    }

    function selectCategory(category) {
      state.category = validCategories.indexOf(category) !== -1 ? category : 'todas';
      state.page = 1;
      render();
    }

    chips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        selectCategory(chip.getAttribute('data-sf-filter'));
      });
    });

    if (search) {
      search.addEventListener('input', function () {
        state.query = normalize(search.value);
        state.page = 1;
        render();
      });
    }

    if (reset) {
      reset.addEventListener('click', function () {
        if (search) {
          search.value = '';
        }
        state.query = '';
        selectCategory('todas');
      });
    }

    var params = new URLSearchParams(window.location.search);
    if (params.has('categoria')) {
      state.category = validCategories.indexOf(params.get('categoria')) !== -1 ? params.get('categoria') : 'todas';
    }
    if (params.has('q') && search) {
      search.value = params.get('q').slice(0, 100);
      state.query = normalize(search.value);
    }

    var requested = params.get('aviso');
    if (requested) {
      var position = -1;
      index.forEach(function (entry, i) {
        if (entry.id === requested) {
          position = i;
        }
      });
      if (position !== -1) {
        state.category = 'todas';
        state.query = '';
        if (search) {
          search.value = '';
        }
        state.page = Math.floor(position / PAGE_SIZE) + 1;
      }
    }

    render();

    if (requested) {
      index.forEach(function (entry) {
        var selected = entry.id === requested;
        entry.element.classList.toggle('is-highlighted', selected);
        if (selected) {
          entry.element.setAttribute('tabindex', '-1');
          entry.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          entry.element.focus({ preventScroll: true });
        }
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
