(function () {
  'use strict';

  var PAGE_SIZE = 8;

  function normalize(value) {
    return (value || '')
      .toString()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .trim();
  }

  function createIcon(name) {
    var icon = document.createElement('span');
    icon.className = 'sf-ico sf-ico--' + name;
    icon.setAttribute('aria-hidden', 'true');
    return icon;
  }

  function buildPager(container, totalPages, currentPage, onSelect) {
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    if (totalPages <= 1) {
      container.hidden = true;
      return;
    }

    var list = document.createElement('ul');
    list.className = 'sf-pager__list';

    function addButton(label, page, options) {
      var item = document.createElement('li');
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'sf-pager__btn';
      if (options.icon) {
        button.appendChild(createIcon(options.icon));
        button.setAttribute('aria-label', label);
      } else {
        button.textContent = label;
        button.setAttribute('aria-label', 'Página ' + label);
      }
      if (options.current) {
        button.setAttribute('aria-current', 'page');
      }
      if (options.disabled) {
        button.disabled = true;
      } else {
        button.addEventListener('click', function () {
          onSelect(page);
        });
      }
      item.appendChild(button);
      list.appendChild(item);
    }

    addButton('Página anterior', currentPage - 1, { icon: 'chevron-left', disabled: currentPage === 1 });
    for (var page = 1; page <= totalPages; page += 1) {
      addButton(String(page), page, { current: page === currentPage });
    }
    addButton('Página siguiente', currentPage + 1, { icon: 'chevron-right', disabled: currentPage === totalPages });

    container.appendChild(list);
    container.hidden = false;
  }

  function init() {
    var root = document.querySelector('[data-sf-docs]');
    if (!root) {
      return;
    }

    var table = root.querySelector('[data-sf-table]');
    var listPanel = root.querySelector('[data-sf-list]');
    var empty = root.querySelector('[data-sf-empty]');
    var reset = root.querySelector('[data-sf-reset]');
    var pager = root.querySelector('[data-sf-pager]');
    var heading = root.querySelector('[data-sf-heading]');
    var search = root.querySelector('[data-sf-search]');
    var sort = root.querySelector('[data-sf-sort]');
    var categoryInputs = Array.prototype.slice.call(root.querySelectorAll('input[name="sf-categoria"]'));
    var areaAll = root.querySelector('[data-sf-area-all]');
    var areaInputs = Array.prototype.slice.call(root.querySelectorAll('[data-sf-area]'));
    if (!table) {
      return;
    }

    var categoryNames = {};
    categoryInputs.forEach(function (input) {
      var label = input.parentNode.querySelector('.sf-option__label');
      categoryNames[input.value] = label ? label.textContent : input.value;
    });

    var index = Array.prototype.slice.call(table.querySelectorAll('[data-sf-item]')).map(function (item) {
      return {
        element: item,
        category: item.getAttribute('data-sf-categoria'),
        area: item.getAttribute('data-sf-area'),
        date: item.getAttribute('data-sf-fecha') || '',
        title: item.getAttribute('data-sf-titulo') || '',
        text: normalize(item.getAttribute('data-sf-titulo'))
      };
    });

    var state = { category: 'todas', areas: [], query: '', order: 'recientes', page: 1 };

    function selectedAreas() {
      return areaInputs.filter(function (input) {
        return input.checked;
      }).map(function (input) {
        return input.value;
      });
    }

    function matches(entry) {
      var categoryOk = state.category === 'todas' || entry.category === state.category;
      var areaOk = state.areas.length === 0 || state.areas.indexOf(entry.area) !== -1;
      var queryOk = !state.query || entry.text.indexOf(state.query) !== -1;
      return categoryOk && areaOk && queryOk;
    }

    function compare(a, b) {
      if (state.order === 'nombre') {
        return a.title.localeCompare(b.title, 'es', { sensitivity: 'base' });
      }
      if (state.order === 'antiguos') {
        return a.date.localeCompare(b.date);
      }
      return b.date.localeCompare(a.date);
    }

    function updateCounts() {
      var countCategory = { todas: 0 };
      var countArea = { todas: 0 };
      index.forEach(function (entry) {
        countCategory.todas += 1;
        countCategory[entry.category] = (countCategory[entry.category] || 0) + 1;
        countArea.todas += 1;
        countArea[entry.area] = (countArea[entry.area] || 0) + 1;
      });
      Array.prototype.forEach.call(root.querySelectorAll('[data-sf-count-categoria]'), function (node) {
        node.textContent = countCategory[node.getAttribute('data-sf-count-categoria')] || 0;
      });
      Array.prototype.forEach.call(root.querySelectorAll('[data-sf-count-area]'), function (node) {
        node.textContent = countArea[node.getAttribute('data-sf-count-area')] || 0;
      });
    }

    function syncSelectionStyles() {
      categoryInputs.concat(areaAll ? [areaAll] : [], areaInputs).forEach(function (input) {
        input.parentNode.classList.toggle('is-selected', input.checked);
      });
    }

    function render() {
      var visible = index.filter(matches).sort(compare);
      var totalPages = Math.max(1, Math.ceil(visible.length / PAGE_SIZE));
      state.page = Math.min(Math.max(1, state.page), totalPages);
      var start = (state.page - 1) * PAGE_SIZE;
      var pageItems = visible.slice(start, start + PAGE_SIZE);

      index.forEach(function (entry) {
        entry.element.hidden = pageItems.indexOf(entry) === -1;
      });
      pageItems.forEach(function (entry) {
        table.appendChild(entry.element);
      });

      if (heading) {
        var name = state.category === 'todas' ? 'Todos los documentos' : categoryNames[state.category];
        heading.textContent = name + ' · ' + visible.length + (visible.length === 1 ? ' documento' : ' documentos');
      }
      if (listPanel) {
        listPanel.hidden = visible.length === 0;
      }
      if (empty) {
        empty.hidden = visible.length !== 0;
      }
      if (pager) {
        buildPager(pager, visible.length ? totalPages : 0, state.page, function (page) {
          state.page = page;
          render();
          root.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
      }
      syncSelectionStyles();
    }

    function setCategory(value) {
      var exists = categoryInputs.some(function (input) {
        return input.value === value;
      });
      state.category = exists ? value : 'todas';
      categoryInputs.forEach(function (input) {
        input.checked = input.value === state.category;
      });
    }

    categoryInputs.forEach(function (input) {
      input.addEventListener('change', function () {
        if (input.checked) {
          setCategory(input.value);
          state.page = 1;
          render();
        }
      });
    });

    if (areaAll) {
      areaAll.addEventListener('change', function () {
        areaAll.checked = true;
        areaInputs.forEach(function (input) {
          input.checked = false;
        });
        state.areas = [];
        state.page = 1;
        render();
      });
    }

    areaInputs.forEach(function (input) {
      input.addEventListener('change', function () {
        state.areas = selectedAreas();
        if (areaAll) {
          areaAll.checked = state.areas.length === 0;
        }
        state.page = 1;
        render();
      });
    });

    if (search) {
      search.addEventListener('input', function () {
        state.query = normalize(search.value);
        state.page = 1;
        render();
      });
    }

    if (sort) {
      sort.addEventListener('change', function () {
        state.order = sort.value;
        state.page = 1;
        render();
      });
    }

    if (reset) {
      reset.addEventListener('click', function () {
        if (search) {
          search.value = '';
        }
        state.query = '';
        setCategory('todas');
        areaInputs.forEach(function (input) {
          input.checked = false;
        });
        if (areaAll) {
          areaAll.checked = true;
        }
        state.areas = [];
        state.page = 1;
        render();
      });
    }

    var params = new URLSearchParams(window.location.search);
    if (params.has('categoria')) {
      setCategory(params.get('categoria'));
    }
    if (params.has('q') && search) {
      search.value = params.get('q').slice(0, 100);
      state.query = normalize(search.value);
    }

    updateCounts();
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
