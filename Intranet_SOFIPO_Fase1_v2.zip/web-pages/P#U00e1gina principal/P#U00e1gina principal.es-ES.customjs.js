(function () {
  'use strict';

  function setGreeting() {
    var target = document.querySelector('[data-sf-greeting]');
    if (!target) {
      return;
    }
    var hour = new Date().getHours();
    var text = 'Buenas noches';
    if (hour >= 5 && hour < 12) {
      text = 'Buenos días';
    } else if (hour >= 12 && hour < 19) {
      text = 'Buenas tardes';
    }
    target.textContent = text;
  }

  function initCarousel(root) {
    var slides = Array.prototype.slice.call(root.querySelectorAll('.sf-hero__slide'));
    var dotsContainer = root.querySelector('[data-sf-dots]');
    var prev = root.querySelector('[data-sf-prev]');
    var next = root.querySelector('[data-sf-next]');
    if (slides.length < 2 || !dotsContainer || !prev || !next) {
      return;
    }

    var current = 0;
    var dots = slides.map(function (slide, index) {
      var dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'sf-hero__dot';
      dot.setAttribute('aria-label', 'Ver aviso ' + (index + 1) + ' de ' + slides.length);
      dot.addEventListener('click', function () {
        show(index);
      });
      dotsContainer.appendChild(dot);
      return dot;
    });

    function show(index) {
      current = (index + slides.length) % slides.length;
      slides.forEach(function (slide, i) {
        slide.hidden = i !== current;
      });
      dots.forEach(function (dot, i) {
        dot.setAttribute('aria-current', i === current ? 'true' : 'false');
      });
    }

    prev.addEventListener('click', function () {
      show(current - 1);
    });
    next.addEventListener('click', function () {
      show(current + 1);
    });
    root.addEventListener('keydown', function (event) {
      if (!event.target.closest('.sf-hero__dots, .sf-hero__arrows')) {
        return;
      }
      if (event.key === 'ArrowLeft') {
        show(current - 1);
      } else if (event.key === 'ArrowRight') {
        show(current + 1);
      }
    });

    show(0);
    root.classList.add('is-ready');
  }

  function init() {
    setGreeting();
    var carousel = document.querySelector('[data-sf-carousel]');
    if (carousel) {
      initCarousel(carousel);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
