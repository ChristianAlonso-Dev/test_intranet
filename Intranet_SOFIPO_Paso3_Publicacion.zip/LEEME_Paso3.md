# Intranet SOFIPO · Paso 3: Publicación de avisos (pantallas 05 y 06)

Módulo propio, con el diseño de Figma, conectado a Dataverse:

- **Lectura** con Liquid (`fetchxml`): todos los avisos, incluidos borradores y programados.
- **Escritura** con la **Web API de Power Pages** (`/_api/cre1f_avisos`): crear, editar, publicar o pasar a borrador, destacar y subir la portada en el mismo paso.
- **Seguridad:** la página y la Web API solo funcionan para el rol **Admin RH** (permiso de página + permisos de tabla). No se puede eliminar avisos: se retiran pasándolos a borrador.

## Contenido del paquete (sobre Portal v6)

| Tipo | Archivo | Qué hace |
|---|---|---|
| Nuevo | `web-templates/sofipo-publicacion-avisos/` | Plantilla del módulo: lista, filtros, orden, paginación, diálogo de alta y edición, menú de acciones y mensajes |
| Nuevo | `web-pages/publicacion-de-avisos/` | Página "Publicación de avisos" (`/publicacion-avisos/`), hija de Inicio |
| Nuevo | `table-permissions/Publicacion*.tablepermission.yml` (4) | Admin RH: Aviso (Lectura, Crear, Escribir, Anexar); CategoriaAviso, Area y Audiencia (Lectura, Anexar a) |
| Cambia | `sitesetting.yml` | Agrega `Webapi/cre1f_aviso/enabled` y `Webapi/cre1f_aviso/fields` |
| Cambia | `webpagerule.yml` | Agrega la regla "Restringir lectura" de la página para Admin RH |
| Cambia | `weblink-sets/default/…weblink.yml` | Agrega el vínculo **Publicación** (orden 3) y pasa **Soporte** al orden 4 |
| Cambia | `web-files/sofipo-intranet.css` | Estilos del módulo (al final del archivo); el resto no cambia |

## A. Pendiente de pasos anteriores (interfaz)

Administración del portal → **Páginas web** → *Página principal* (idioma **Español**) → pestaña **Avanzado** → borra **CSS personalizado** y **JavaScript personalizado** → Guardar. Repite en *Noticias Internas* (Español).

## B. Subir

1. Respaldo: `pac pages download --path ./respaldo-paso3 --webSiteId a5595b5a-e6e0-4342-a230-25a2ec76cebe`
2. Copia el contenido de `intranet-sofipo` de este paquete sobre tu carpeta de **Portal v6** y acepta reemplazar.
3. `pac pages upload --path ./intranet-sofipo`
4. Estudio → **Sincronizar**. Después `https://<tu-sitio>/_services/about` → **Clear cache**.

## C. Verificación en la interfaz

- [ ] Administración del portal → **Configuración del sitio**: existen `Webapi/cre1f_aviso/enabled` = `true` y `Webapi/cre1f_aviso/fields` con las 10 columnas.
- [ ] Estudio → Seguridad → **Permisos de tabla**: existen PublicacionAvisos, PublicacionCategoriasAviso, PublicacionAreas y PublicacionAudiencias, con el rol **Admin RH**.
- [ ] Estudio → **Páginas**: existe "Publicación de avisos". En su configuración → **Permisos**: solo **Admin RH**.
- [ ] Administración del portal → **Plantillas web**: existe `sofipo-publicacion-avisos`.
- [ ] Menú: Inicio · Noticias · **Publicación** · Soporte.

Si algún registro no se creó, avísame cuál y lo creamos a mano.

## D. Prueba funcional (con tu usuario Admin RH)

1. **Publicación** muestra todos los avisos, con estado *Borrador* o *Programado* cuando aplica.
2. **Nuevo aviso** → llena los campos, agrega una portada (JPG o PNG, hasta 5 MB) → **Publicar aviso**. Aparece el mensaje "Aviso publicado correctamente" y el aviso se ve en la lista, en Noticias y, si es destacado, en Inicio.
3. **Editar** un aviso → cambia algo → **Guardar como borrador**. Desaparece de Noticias y queda como *Borrador* en la lista.
4. Menú **⋯** → *Publicar* / *Pasar a borrador* y *Destacar en Inicio* / *Quitar de destacados*.
5. Quítate el rol Admin RH: el menú ya no muestra "Publicación" y `/publicacion-avisos/` lleva a Acceso denegado. Vuelve a asignártelo.

## E. Si guardar muestra un error

El diálogo muestra el motivo. Los nombres de la Web API están en un solo lugar, al inicio del `<script>` de la plantilla (`CONFIG`):

```
entitySet: 'cre1f_avisos'
categoria: navigation 'cre1f_categoriaavisoid', entitySet 'cre1f_categoriaavisos'
audiencia: navigation 'cre1f_audienciaid',      entitySet 'cre1f_audiencias'
area:      navigation 'cre1f_areaid',           entitySet 'cre1f_areas'
```

- "No tienes permiso…": revisa los permisos de tabla y tu rol.
- "El servicio de avisos no está habilitado…": revisa las 2 configuraciones del sitio y haz Clear cache.
- Un detalle que mencione una propiedad o un conjunto no encontrado: comparte el mensaje; se corrige el nombre en `CONFIG`.

Si después de guardar la lista no refleja el cambio de inmediato, haz Clear cache y recarga.
