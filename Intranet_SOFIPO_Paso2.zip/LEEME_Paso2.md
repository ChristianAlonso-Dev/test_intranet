# Intranet SOFIPO · Paso 2 sobre Portal v5

## Estado del paso 1 (revisado en tu descarga v5)

Se aplicó todo, **excepto** el vaciado del CSS y del JavaScript personalizados de Inicio y Noticias: pac no sube archivos vacíos, así que esos campos siguen con el código de la primera entrega y el carrusel sigue duplicado. Esto se hace en la interfaz (sección A).

## Contenido del paquete (4 archivos, mismas rutas de `intranet-sofipo`)

| Archivo | Cambio |
|---|---|
| `web-templates/header/Header.webtemplate.source.html` | Los vínculos del menú que abren en pestaña nueva reciben el icono de enlace externo, `rel="noopener noreferrer"` y el aviso accesible "se abre en una pestaña nueva" |
| `web-files/sofipo-intranet.css` | Estilo del icono de enlace externo en el menú |
| `web-pages/página-no-encontrada/…copy.html` (2) | Página 404 con el estado de Figma (pantalla 12): icono, mensaje y botón "Volver al inicio" |

## A. Pendiente del paso 1 (interfaz)

1. Administración del portal → **Páginas web** → *Página principal* (idioma **Español**) → pestaña **Avanzado** → borra todo el **CSS personalizado** y el **JavaScript personalizado** → Guardar.
2. Repite en *Noticias Internas* (idioma Español).

## B. Subir el paquete

1. Respaldo: `pac pages download --path ./respaldo-paso2 --webSiteId a5595b5a-e6e0-4342-a230-25a2ec76cebe`
2. Copia el contenido de `intranet-sofipo` de este paquete sobre tu carpeta de **Portal v5** y acepta reemplazar.
3. `pac pages upload --path ./intranet-sofipo`
4. Si al revisar el sitio el icono externo no aparece, reemplaza el archivo adjunto en Administración del portal → **Archivos web** → *sofipo-intranet.css* → Notas, con el `sofipo-intranet.css` de este paquete.

## C. Vínculo a ServiceNow en la barra (interfaz)

Administración del portal → **Vínculos web** → **Nuevo**:

| Campo | Valor |
|---|---|
| Nombre | Mis pendientes RH |
| Conjunto de vínculos web | Default |
| URL externa | `https://ictineoprod.service-now.com/esc?id=hrm_todos_page` |
| Abrir en ventana nueva | Sí |
| Orden de presentación | 3 |
| Información sobre herramientas | Abre ServiceNow en una pestaña nueva |
| Estado de publicación | Publicado |

Deja vacío el campo **Página**: el vínculo usa solo la URL externa. El nombre se puede cambiar en cualquier momento desde este mismo registro.

## D. Cierre

1. Estudio → **Sincronizar**.
2. `https://<tu-sitio>/_services/about` → **Clear cache**.
3. Revisa:
   - [ ] Menú: Inicio · Noticias · Mis pendientes RH (con icono de enlace externo).
   - [ ] "Mis pendientes RH" abre ServiceNow en una pestaña nueva.
   - [ ] El carrusel de Inicio muestra un punto por cada aviso destacado.
   - [ ] Una dirección inexistente (por ejemplo `/no-existe`) muestra la nueva página "No encontramos esta página".
4. Haz un `pac pages download` nuevo y compártelo.
