package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Response segments. If a data item does not exist in the Buró de Crédito database, the field is not shown.
 */

@Schema(name = "buroPerson", description = "Response segments. If a data item does not exist in the Buró de Crédito database, the field is not shown.")
@JsonTypeName("buroPerson")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroPerson {

  private BuroHeader header;

  private BuroName name;

  @Valid
  private List<@Valid BuroAddress> addresses = new ArrayList<>();

  @Valid
  private List<@Valid BuroEmployment> employments = new ArrayList<>();

  @Valid
  private List<@Valid BuroAccount> accounts = new ArrayList<>();

  @Valid
  private List<@Valid BuroInquiry> inquiries = new ArrayList<>();

  @Valid
  private List<@Valid BuroReportSummary> reportSummary = new ArrayList<>();

  @Valid
  private List<@Valid BuroHawkAlertInquiry> hawkAlertInquiry = new ArrayList<>();

  @Valid
  private List<@Valid BuroHawkAlertDatabase> hawkAlertDatabase = new ArrayList<>();

  private BuroConsumerStatement consumerStatements;

  @Valid
  private List<@Valid BuroScore> scores = new ArrayList<>();

  public BuroPerson header(BuroHeader header) {
    this.header = header;
    return this;
  }

  /**
   * Get header
   * @return header
  */
  @Valid 
  @Schema(name = "header", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("header")
  public BuroHeader getHeader() {
    return header;
  }

  public void setHeader(BuroHeader header) {
    this.header = header;
  }

  public BuroPerson name(BuroName name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  */
  @Valid 
  @Schema(name = "name", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("name")
  public BuroName getName() {
    return name;
  }

  public void setName(BuroName name) {
    this.name = name;
  }

  public BuroPerson addresses(List<@Valid BuroAddress> addresses) {
    this.addresses = addresses;
    return this;
  }

  public BuroPerson addAddressesItem(BuroAddress addressesItem) {
    if (this.addresses == null) {
      this.addresses = new ArrayList<>();
    }
    this.addresses.add(addressesItem);
    return this;
  }

  /**
   * Customer addresses. Up to 4.
   * @return addresses
  */
  @Valid @Size(max = 4) 
  @Schema(name = "addresses", description = "Customer addresses. Up to 4.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addresses")
  public List<@Valid BuroAddress> getAddresses() {
    return addresses;
  }

  public void setAddresses(List<@Valid BuroAddress> addresses) {
    this.addresses = addresses;
  }

  public BuroPerson employments(List<@Valid BuroEmployment> employments) {
    this.employments = employments;
    return this;
  }

  public BuroPerson addEmploymentsItem(BuroEmployment employmentsItem) {
    if (this.employments == null) {
      this.employments = new ArrayList<>();
    }
    this.employments.add(employmentsItem);
    return this;
  }

  /**
   * Customer employments. Up to 2.
   * @return employments
  */
  @Valid @Size(max = 2) 
  @Schema(name = "employments", description = "Customer employments. Up to 2.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("employments")
  public List<@Valid BuroEmployment> getEmployments() {
    return employments;
  }

  public void setEmployments(List<@Valid BuroEmployment> employments) {
    this.employments = employments;
  }

  public BuroPerson accounts(List<@Valid BuroAccount> accounts) {
    this.accounts = accounts;
    return this;
  }

  public BuroPerson addAccountsItem(BuroAccount accountsItem) {
    if (this.accounts == null) {
      this.accounts = new ArrayList<>();
    }
    this.accounts.add(accountsItem);
    return this;
  }

  /**
   * Accounts or credits in the Customer's file. Unlimited.
   * @return accounts
  */
  @Valid 
  @Schema(name = "accounts", description = "Accounts or credits in the Customer's file. Unlimited.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accounts")
  public List<@Valid BuroAccount> getAccounts() {
    return accounts;
  }

  public void setAccounts(List<@Valid BuroAccount> accounts) {
    this.accounts = accounts;
  }

  public BuroPerson inquiries(List<@Valid BuroInquiry> inquiries) {
    this.inquiries = inquiries;
    return this;
  }

  public BuroPerson addInquiriesItem(BuroInquiry inquiriesItem) {
    if (this.inquiries == null) {
      this.inquiries = new ArrayList<>();
    }
    this.inquiries.add(inquiriesItem);
    return this;
  }

  /**
   * Queries made to the Customer's file. Unlimited.
   * @return inquiries
  */
  @Valid 
  @Schema(name = "inquiries", description = "Queries made to the Customer's file. Unlimited.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("inquiries")
  public List<@Valid BuroInquiry> getInquiries() {
    return inquiries;
  }

  public void setInquiries(List<@Valid BuroInquiry> inquiries) {
    this.inquiries = inquiries;
  }

  public BuroPerson reportSummary(List<@Valid BuroReportSummary> reportSummary) {
    this.reportSummary = reportSummary;
    return this;
  }

  public BuroPerson addReportSummaryItem(BuroReportSummary reportSummaryItem) {
    if (this.reportSummary == null) {
      this.reportSummary = new ArrayList<>();
    }
    this.reportSummary.add(reportSummaryItem);
    return this;
  }

  /**
   * Summary of the Customer's file. Up to 3.
   * @return reportSummary
  */
  @Valid @Size(max = 3) 
  @Schema(name = "reportSummary", description = "Summary of the Customer's file. Up to 3.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reportSummary")
  public List<@Valid BuroReportSummary> getReportSummary() {
    return reportSummary;
  }

  public void setReportSummary(List<@Valid BuroReportSummary> reportSummary) {
    this.reportSummary = reportSummary;
  }

  public BuroPerson hawkAlertInquiry(List<@Valid BuroHawkAlertInquiry> hawkAlertInquiry) {
    this.hawkAlertInquiry = hawkAlertInquiry;
    return this;
  }

  public BuroPerson addHawkAlertInquiryItem(BuroHawkAlertInquiry hawkAlertInquiryItem) {
    if (this.hawkAlertInquiry == null) {
      this.hawkAlertInquiry = new ArrayList<>();
    }
    this.hawkAlertInquiry.add(hawkAlertInquiryItem);
    return this;
  }

  /**
   * Hawk alerts matching the query data. Unlimited (lawsuit information: up to 20).
   * @return hawkAlertInquiry
  */
  @Valid 
  @Schema(name = "hawkAlertInquiry", description = "Hawk alerts matching the query data. Unlimited (lawsuit information: up to 20).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("hawkAlertInquiry")
  public List<@Valid BuroHawkAlertInquiry> getHawkAlertInquiry() {
    return hawkAlertInquiry;
  }

  public void setHawkAlertInquiry(List<@Valid BuroHawkAlertInquiry> hawkAlertInquiry) {
    this.hawkAlertInquiry = hawkAlertInquiry;
  }

  public BuroPerson hawkAlertDatabase(List<@Valid BuroHawkAlertDatabase> hawkAlertDatabase) {
    this.hawkAlertDatabase = hawkAlertDatabase;
    return this;
  }

  public BuroPerson addHawkAlertDatabaseItem(BuroHawkAlertDatabase hawkAlertDatabaseItem) {
    if (this.hawkAlertDatabase == null) {
      this.hawkAlertDatabase = new ArrayList<>();
    }
    this.hawkAlertDatabase.add(hawkAlertDatabaseItem);
    return this;
  }

  /**
   * Hawk alerts matching the Buró de Crédito database. Unlimited (lawsuit information: up to 20).
   * @return hawkAlertDatabase
  */
  @Valid 
  @Schema(name = "hawkAlertDatabase", description = "Hawk alerts matching the Buró de Crédito database. Unlimited (lawsuit information: up to 20).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("hawkAlertDatabase")
  public List<@Valid BuroHawkAlertDatabase> getHawkAlertDatabase() {
    return hawkAlertDatabase;
  }

  public void setHawkAlertDatabase(List<@Valid BuroHawkAlertDatabase> hawkAlertDatabase) {
    this.hawkAlertDatabase = hawkAlertDatabase;
  }

  public BuroPerson consumerStatements(BuroConsumerStatement consumerStatements) {
    this.consumerStatements = consumerStatements;
    return this;
  }

  /**
   * Get consumerStatements
   * @return consumerStatements
  */
  @Valid 
  @Schema(name = "consumerStatements", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("consumerStatements")
  public BuroConsumerStatement getConsumerStatements() {
    return consumerStatements;
  }

  public void setConsumerStatements(BuroConsumerStatement consumerStatements) {
    this.consumerStatements = consumerStatements;
  }

  public BuroPerson scores(List<@Valid BuroScore> scores) {
    this.scores = scores;
    return this;
  }

  public BuroPerson addScoresItem(BuroScore scoresItem) {
    if (this.scores == null) {
      this.scores = new ArrayList<>();
    }
    this.scores.add(scoresItem);
    return this;
  }

  /**
   * Score results. Up to 15.
   * @return scores
  */
  @Valid @Size(max = 15) 
  @Schema(name = "scores", description = "Score results. Up to 15.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("scores")
  public List<@Valid BuroScore> getScores() {
    return scores;
  }

  public void setScores(List<@Valid BuroScore> scores) {
    this.scores = scores;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroPerson buroPerson = (BuroPerson) o;
    return Objects.equals(this.header, buroPerson.header) &&
        Objects.equals(this.name, buroPerson.name) &&
        Objects.equals(this.addresses, buroPerson.addresses) &&
        Objects.equals(this.employments, buroPerson.employments) &&
        Objects.equals(this.accounts, buroPerson.accounts) &&
        Objects.equals(this.inquiries, buroPerson.inquiries) &&
        Objects.equals(this.reportSummary, buroPerson.reportSummary) &&
        Objects.equals(this.hawkAlertInquiry, buroPerson.hawkAlertInquiry) &&
        Objects.equals(this.hawkAlertDatabase, buroPerson.hawkAlertDatabase) &&
        Objects.equals(this.consumerStatements, buroPerson.consumerStatements) &&
        Objects.equals(this.scores, buroPerson.scores);
  }

  @Override
  public int hashCode() {
    return Objects.hash(header, name, addresses, employments, accounts, inquiries, reportSummary, hawkAlertInquiry, hawkAlertDatabase, consumerStatements, scores);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroPerson {\n");
    sb.append("    header: ").append(toIndentedString(header)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    addresses: ").append(toIndentedString(addresses)).append("\n");
    sb.append("    employments: ").append(toIndentedString(employments)).append("\n");
    sb.append("    accounts: ").append(toIndentedString(accounts)).append("\n");
    sb.append("    inquiries: ").append(toIndentedString(inquiries)).append("\n");
    sb.append("    reportSummary: ").append(toIndentedString(reportSummary)).append("\n");
    sb.append("    hawkAlertInquiry: ").append(toIndentedString(hawkAlertInquiry)).append("\n");
    sb.append("    hawkAlertDatabase: ").append(toIndentedString(hawkAlertDatabase)).append("\n");
    sb.append("    consumerStatements: ").append(toIndentedString(consumerStatements)).append("\n");
    sb.append("    scores: ").append(toIndentedString(scores)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

