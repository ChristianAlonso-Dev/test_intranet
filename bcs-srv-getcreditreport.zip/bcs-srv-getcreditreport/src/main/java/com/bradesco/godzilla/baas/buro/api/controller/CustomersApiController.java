package com.bradesco.godzilla.baas.buro.api.controller;

import com.bradesco.godzilla.baas.buro.api.controller.validation.HeaderValidator;
import com.bradesco.godzilla.baas.buro.api.model.BuroCreditReportResponse;
import com.bradesco.godzilla.baas.buro.api.model.ChannelId;
import com.bradesco.godzilla.baas.buro.api.model.ChannelType;
import com.bradesco.godzilla.baas.buro.api.model.GetCustomerCreditReportRequest;
import com.bradesco.godzilla.baas.buro.adapter.input.mapper.CreditReportApiMapper;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;
import com.bradesco.godzilla.baas.buro.port.input.GetCreditReportQuery;
import com.bradesco.godzilla.baas.buro.port.input.IGetCreditReportUseCase;
import java.beans.PropertyEditorSupport;
import java.util.Optional;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.context.request.NativeWebRequest;

@Controller
public class CustomersApiController implements CustomersApi {
    private static final String CHANNEL_ID_HEADER = "Channel-ID";
    private static final String CHANNEL_TYPE_HEADER = "Channel-Type";

    private final NativeWebRequest request;
    private final IGetCreditReportUseCase getCreditReportUseCase;
    private final CreditReportApiMapper mapper;
    private final HeaderValidator headerValidator;

    public CustomersApiController(
            NativeWebRequest request,
            IGetCreditReportUseCase getCreditReportUseCase,
            CreditReportApiMapper mapper,
            HeaderValidator headerValidator) {
        this.request = request;
        this.getCreditReportUseCase = getCreditReportUseCase;
        this.mapper = mapper;
        this.headerValidator = headerValidator;
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(ChannelId.class, new PropertyEditorSupport() {
            @Override
            public void setAsText(String text) {
                setValue(ApiUtil.toChannelId(text));
            }
        });
        binder.registerCustomEditor(ChannelType.class, new PropertyEditorSupport() {
            @Override
            public void setAsText(String text) {
                setValue(ApiUtil.toChannelType(text));
            }
        });
    }

    @Override
    public Optional<NativeWebRequest> getRequest() {
        return Optional.ofNullable(request);
    }

    @Override
    public ResponseEntity<BuroCreditReportResponse> getCustomerCreditReport(
            String geoLocation,
            String authorization,
            String contentType,
            String traceparent,
            ChannelId channelID,
            ChannelType channelType,
            String requestID,
            String customerId,
            GetCustomerCreditReportRequest getCustomerCreditReportRequest,
            String tracestate) {

        headerValidator.validate(
                geoLocation,
                authorization,
                contentType,
                traceparent,
                request.getHeader(CHANNEL_ID_HEADER),
                request.getHeader(CHANNEL_TYPE_HEADER),
                requestID,
                tracestate);

        GetCreditReportQuery query = GetCreditReportQuery.builder()
                .requestId(requestID)
                .customerId(customerId)
                .channelId(channelID.getValue())
                .channelType(channelType.getValue())
                .inquiry(mapper.toInquiry(getCustomerCreditReportRequest))
                .build();

        CreditReport creditReport = getCreditReportUseCase.execute(query);

        return ResponseEntity.ok(mapper.toApiResponse(creditReport));
    }
}
