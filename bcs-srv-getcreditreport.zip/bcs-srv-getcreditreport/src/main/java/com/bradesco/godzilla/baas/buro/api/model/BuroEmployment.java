package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Customer employment.
 */

@Schema(name = "buroEmployment", description = "Customer employment.")
@JsonTypeName("buroEmployment")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroEmployment {

  private String companyName;

  private String addressLine1;

  private String addressLine2;

  private String neighborhood;

  private String municipality;

  private String city;

  private String state;

  private String postalCode;

  private String phoneNumber;

  private String extension;

  private String fax;

  private String position;

  private String hireDate;

  private String salaryCurrency;

  private String salary;

  private String salaryPeriod;

  private String employeeNumber;

  private String lastEmploymentDate;

  private String employmentReportDate;

  private String verificationDate;

  private String verificationMode;

  private String countryCode;

  public BuroEmployment companyName(String companyName) {
    this.companyName = companyName;
    return this;
  }

  /**
   * Employer name or corporate name.
   * @return companyName
  */
  @Size(max = 40) 
  @Schema(name = "companyName", example = " nombreEmpresa", description = "Employer name or corporate name.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("companyName")
  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public BuroEmployment addressLine1(String addressLine1) {
    this.addressLine1 = addressLine1;
    return this;
  }

  /**
   * Employer address line 1.
   * @return addressLine1
  */
  @Size(max = 40) 
  @Schema(name = "addressLine1", example = "CALLE 19 30", description = "Employer address line 1.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addressLine1")
  public String getAddressLine1() {
    return addressLine1;
  }

  public void setAddressLine1(String addressLine1) {
    this.addressLine1 = addressLine1;
  }

  public BuroEmployment addressLine2(String addressLine2) {
    this.addressLine2 = addressLine2;
    return this;
  }

  /**
   * Employer address line 2.
   * @return addressLine2
  */
  @Size(max = 40) 
  @Schema(name = "addressLine2", description = "Employer address line 2.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addressLine2")
  public String getAddressLine2() {
    return addressLine2;
  }

  public void setAddressLine2(String addressLine2) {
    this.addressLine2 = addressLine2;
  }

  public BuroEmployment neighborhood(String neighborhood) {
    this.neighborhood = neighborhood;
    return this;
  }

  /**
   * Neighborhood (colonia) or town of the employment address.
   * @return neighborhood
  */
  @Size(max = 40) 
  @Schema(name = "neighborhood", example = "PROLETARIA", description = "Neighborhood (colonia) or town of the employment address.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("neighborhood")
  public String getNeighborhood() {
    return neighborhood;
  }

  public void setNeighborhood(String neighborhood) {
    this.neighborhood = neighborhood;
  }

  public BuroEmployment municipality(String municipality) {
    this.municipality = municipality;
    return this;
  }

  /**
   * Mayor's office (Alcaldía) or municipality of the employment address.
   * @return municipality
  */
  @Size(max = 40) 
  @Schema(name = "municipality", example = "CUAUHTEMOC", description = "Mayor's office (Alcaldía) or municipality of the employment address.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("municipality")
  public String getMunicipality() {
    return municipality;
  }

  public void setMunicipality(String municipality) {
    this.municipality = municipality;
  }

  public BuroEmployment city(String city) {
    this.city = city;
    return this;
  }

  /**
   * City of the employment.
   * @return city
  */
  @Size(max = 40) 
  @Schema(name = "city", example = "CD DE MEXICO", description = "City of the employment.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("city")
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public BuroEmployment state(String state) {
    this.state = state;
    return this;
  }

  /**
   * State code of the employer address (Annex 6).
   * @return state
  */
  @Size(max = 4) 
  @Schema(name = "state", example = "CDMX", description = "State code of the employer address (Annex 6).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("state")
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public BuroEmployment postalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Postal code of the employment address.
   * @return postalCode
  */
  @Size(max = 5) 
  @Schema(name = "postalCode", example = "07670", description = "Postal code of the employment address.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("postalCode")
  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public BuroEmployment phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

  /**
   * Employment telephone. Area code + up to 8 digits.
   * @return phoneNumber
  */
  @Size(max = 11) 
  @Schema(name = "phoneNumber", description = "Employment telephone. Area code + up to 8 digits.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public BuroEmployment extension(String extension) {
    this.extension = extension;
    return this;
  }

  /**
   * Employment telephone extension.
   * @return extension
  */
  @Size(max = 8) 
  @Schema(name = "extension", description = "Employment telephone extension.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("extension")
  public String getExtension() {
    return extension;
  }

  public void setExtension(String extension) {
    this.extension = extension;
  }

  public BuroEmployment fax(String fax) {
    this.fax = fax;
    return this;
  }

  /**
   * Employment fax number. Area code + up to 8 digits.
   * @return fax
  */
  @Size(max = 11) 
  @Schema(name = "fax", description = "Employment fax number. Area code + up to 8 digits.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fax")
  public String getFax() {
    return fax;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public BuroEmployment position(String position) {
    this.position = position;
    return this;
  }

  /**
   * Position or occupation.
   * @return position
  */
  @Size(max = 30) 
  @Schema(name = "position", example = "VENDEDORA", description = "Position or occupation.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("position")
  public String getPosition() {
    return position;
  }

  public void setPosition(String position) {
    this.position = position;
  }

  public BuroEmployment hireDate(String hireDate) {
    this.hireDate = hireDate;
    return this;
  }

  /**
   * Hiring date (DDMMAAAA).
   * @return hireDate
  */
  @Size(max = 8) 
  @Schema(name = "hireDate", example = "19112020", description = "Hiring date (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("hireDate")
  public String getHireDate() {
    return hireDate;
  }

  public void setHireDate(String hireDate) {
    this.hireDate = hireDate;
  }

  public BuroEmployment salaryCurrency(String salaryCurrency) {
    this.salaryCurrency = salaryCurrency;
    return this;
  }

  /**
   * Currency of the salary (Annex 5).
   * @return salaryCurrency
  */
  @Size(max = 2) 
  @Schema(name = "salaryCurrency", description = "Currency of the salary (Annex 5).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("salaryCurrency")
  public String getSalaryCurrency() {
    return salaryCurrency;
  }

  public void setSalaryCurrency(String salaryCurrency) {
    this.salaryCurrency = salaryCurrency;
  }

  public BuroEmployment salary(String salary) {
    this.salary = salary;
    return this;
  }

  /**
   * Salary amount, according to the payment period in salaryPeriod.
   * @return salary
  */
  @Size(max = 9) 
  @Schema(name = "salary", example = "12000", description = "Salary amount, according to the payment period in salaryPeriod.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("salary")
  public String getSalary() {
    return salary;
  }

  public void setSalary(String salary) {
    this.salary = salary;
  }

  public BuroEmployment salaryPeriod(String salaryPeriod) {
    this.salaryPeriod = salaryPeriod;
    return this;
  }

  /**
   * Payment period: B = Bimonthly, D = Daily, H = Per hour, K = Every fourteen days, M = Monthly, S = Semi-monthly, W = Weekly, Y = Annual.
   * @return salaryPeriod
  */
  @Size(max = 1) 
  @Schema(name = "salaryPeriod", example = "M", description = "Payment period: B = Bimonthly, D = Daily, H = Per hour, K = Every fourteen days, M = Monthly, S = Semi-monthly, W = Weekly, Y = Annual.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("salaryPeriod")
  public String getSalaryPeriod() {
    return salaryPeriod;
  }

  public void setSalaryPeriod(String salaryPeriod) {
    this.salaryPeriod = salaryPeriod;
  }

  public BuroEmployment employeeNumber(String employeeNumber) {
    this.employeeNumber = employeeNumber;
    return this;
  }

  /**
   * Employee or payroll number.
   * @return employeeNumber
  */
  @Size(max = 15) 
  @Schema(name = "employeeNumber", description = "Employee or payroll number.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("employeeNumber")
  public String getEmployeeNumber() {
    return employeeNumber;
  }

  public void setEmployeeNumber(String employeeNumber) {
    this.employeeNumber = employeeNumber;
  }

  public BuroEmployment lastEmploymentDate(String lastEmploymentDate) {
    this.lastEmploymentDate = lastEmploymentDate;
    return this;
  }

  /**
   * Last day of employment (DDMMAAAA).
   * @return lastEmploymentDate
  */
  @Size(max = 8) 
  @Schema(name = "lastEmploymentDate", description = "Last day of employment (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastEmploymentDate")
  public String getLastEmploymentDate() {
    return lastEmploymentDate;
  }

  public void setLastEmploymentDate(String lastEmploymentDate) {
    this.lastEmploymentDate = lastEmploymentDate;
  }

  public BuroEmployment employmentReportDate(String employmentReportDate) {
    this.employmentReportDate = employmentReportDate;
    return this;
  }

  /**
   * Date the employment was first reported to Buró de Crédito (DDMMAAAA).
   * @return employmentReportDate
  */
  @Size(max = 8) 
  @Schema(name = "employmentReportDate", example = "19112020", description = "Date the employment was first reported to Buró de Crédito (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("employmentReportDate")
  public String getEmploymentReportDate() {
    return employmentReportDate;
  }

  public void setEmploymentReportDate(String employmentReportDate) {
    this.employmentReportDate = employmentReportDate;
  }

  public BuroEmployment verificationDate(String verificationDate) {
    this.verificationDate = verificationDate;
    return this;
  }

  /**
   * Date the User last verified the employment (DDMMAAAA).
   * @return verificationDate
  */
  @Size(max = 8) 
  @Schema(name = "verificationDate", example = "19112020", description = "Date the User last verified the employment (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("verificationDate")
  public String getVerificationDate() {
    return verificationDate;
  }

  public void setVerificationDate(String verificationDate) {
    this.verificationDate = verificationDate;
  }

  public BuroEmployment verificationMode(String verificationMode) {
    this.verificationMode = verificationMode;
    return this;
  }

  /**
   * Verification mode: A = Automated, M = Manual.
   * @return verificationMode
  */
  @Size(max = 1) 
  @Schema(name = "verificationMode", example = "A", description = "Verification mode: A = Automated, M = Manual.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("verificationMode")
  public String getVerificationMode() {
    return verificationMode;
  }

  public void setVerificationMode(String verificationMode) {
    this.verificationMode = verificationMode;
  }

  public BuroEmployment countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Country of origin of the employer's corporate name and address (Annex 5).
   * @return countryCode
  */
  @Size(max = 2) 
  @Schema(name = "countryCode", example = "MX", description = "Country of origin of the employer's corporate name and address (Annex 5).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("countryCode")
  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroEmployment buroEmployment = (BuroEmployment) o;
    return Objects.equals(this.companyName, buroEmployment.companyName) &&
        Objects.equals(this.addressLine1, buroEmployment.addressLine1) &&
        Objects.equals(this.addressLine2, buroEmployment.addressLine2) &&
        Objects.equals(this.neighborhood, buroEmployment.neighborhood) &&
        Objects.equals(this.municipality, buroEmployment.municipality) &&
        Objects.equals(this.city, buroEmployment.city) &&
        Objects.equals(this.state, buroEmployment.state) &&
        Objects.equals(this.postalCode, buroEmployment.postalCode) &&
        Objects.equals(this.phoneNumber, buroEmployment.phoneNumber) &&
        Objects.equals(this.extension, buroEmployment.extension) &&
        Objects.equals(this.fax, buroEmployment.fax) &&
        Objects.equals(this.position, buroEmployment.position) &&
        Objects.equals(this.hireDate, buroEmployment.hireDate) &&
        Objects.equals(this.salaryCurrency, buroEmployment.salaryCurrency) &&
        Objects.equals(this.salary, buroEmployment.salary) &&
        Objects.equals(this.salaryPeriod, buroEmployment.salaryPeriod) &&
        Objects.equals(this.employeeNumber, buroEmployment.employeeNumber) &&
        Objects.equals(this.lastEmploymentDate, buroEmployment.lastEmploymentDate) &&
        Objects.equals(this.employmentReportDate, buroEmployment.employmentReportDate) &&
        Objects.equals(this.verificationDate, buroEmployment.verificationDate) &&
        Objects.equals(this.verificationMode, buroEmployment.verificationMode) &&
        Objects.equals(this.countryCode, buroEmployment.countryCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(companyName, addressLine1, addressLine2, neighborhood, municipality, city, state, postalCode, phoneNumber, extension, fax, position, hireDate, salaryCurrency, salary, salaryPeriod, employeeNumber, lastEmploymentDate, employmentReportDate, verificationDate, verificationMode, countryCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroEmployment {\n");
    sb.append("    companyName: ").append(toIndentedString(companyName)).append("\n");
    sb.append("    addressLine1: ").append(toIndentedString(addressLine1)).append("\n");
    sb.append("    addressLine2: ").append(toIndentedString(addressLine2)).append("\n");
    sb.append("    neighborhood: ").append(toIndentedString(neighborhood)).append("\n");
    sb.append("    municipality: ").append(toIndentedString(municipality)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    extension: ").append(toIndentedString(extension)).append("\n");
    sb.append("    fax: ").append(toIndentedString(fax)).append("\n");
    sb.append("    position: ").append(toIndentedString(position)).append("\n");
    sb.append("    hireDate: ").append(toIndentedString(hireDate)).append("\n");
    sb.append("    salaryCurrency: ").append(toIndentedString(salaryCurrency)).append("\n");
    sb.append("    salary: ").append(toIndentedString(salary)).append("\n");
    sb.append("    salaryPeriod: ").append(toIndentedString(salaryPeriod)).append("\n");
    sb.append("    employeeNumber: ").append(toIndentedString(employeeNumber)).append("\n");
    sb.append("    lastEmploymentDate: ").append(toIndentedString(lastEmploymentDate)).append("\n");
    sb.append("    employmentReportDate: ").append(toIndentedString(employmentReportDate)).append("\n");
    sb.append("    verificationDate: ").append(toIndentedString(verificationDate)).append("\n");
    sb.append("    verificationMode: ").append(toIndentedString(verificationMode)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

