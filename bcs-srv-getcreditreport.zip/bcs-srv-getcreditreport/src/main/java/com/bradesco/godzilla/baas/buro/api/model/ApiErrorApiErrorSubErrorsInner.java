package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * ApiErrorApiErrorSubErrorsInner
 */

@JsonTypeName("ApiError_apiError_subErrors_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class ApiErrorApiErrorSubErrorsInner {

  private Integer code;

  private String message;

  public ApiErrorApiErrorSubErrorsInner() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public ApiErrorApiErrorSubErrorsInner(Integer code, String message) {
    this.code = code;
    this.message = message;
  }

  public ApiErrorApiErrorSubErrorsInner code(Integer code) {
    this.code = code;
    return this;
  }

  /**
   * Codigo del sub-error. Corresponde al mismo errorCode del objeto apiError que lo contiene.
   * minimum: 1
   * @return code
  */
  @NotNull @Min(1) 
  @Schema(name = "code", example = "8410", description = "Codigo del sub-error. Corresponde al mismo errorCode del objeto apiError que lo contiene.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("code")
  public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public ApiErrorApiErrorSubErrorsInner message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Descripcion del sub-error.
   * @return message
  */
  @NotNull @Size(min = 1) 
  @Schema(name = "message", example = "InvalidParameters.", description = "Descripcion del sub-error.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApiErrorApiErrorSubErrorsInner apiErrorApiErrorSubErrorsInner = (ApiErrorApiErrorSubErrorsInner) o;
    return Objects.equals(this.code, apiErrorApiErrorSubErrorsInner.code) &&
        Objects.equals(this.message, apiErrorApiErrorSubErrorsInner.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApiErrorApiErrorSubErrorsInner {\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

