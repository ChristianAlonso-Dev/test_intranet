package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Credit Report query data.
 */

@Schema(name = "getCustomerCreditReportRequest", description = "Credit Report query data.")
@JsonTypeName("getCustomerCreditReportRequest")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class GetCustomerCreditReportRequest {

  private CreditReportHeader header;

  private CreditReportName name;

  @Valid
  private List<@Valid CreditReportAddress> addresses = new ArrayList<>();

  public GetCustomerCreditReportRequest() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public GetCustomerCreditReportRequest(CreditReportHeader header, CreditReportName name, List<@Valid CreditReportAddress> addresses) {
    this.header = header;
    this.name = name;
    this.addresses = addresses;
  }

  public GetCustomerCreditReportRequest header(CreditReportHeader header) {
    this.header = header;
    return this;
  }

  /**
   * Get header
   * @return header
  */
  @NotNull @Valid 
  @Schema(name = "header", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("header")
  public CreditReportHeader getHeader() {
    return header;
  }

  public void setHeader(CreditReportHeader header) {
    this.header = header;
  }

  public GetCustomerCreditReportRequest name(CreditReportName name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  */
  @NotNull @Valid 
  @Schema(name = "name", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("name")
  public CreditReportName getName() {
    return name;
  }

  public void setName(CreditReportName name) {
    this.name = name;
  }

  public GetCustomerCreditReportRequest addresses(List<@Valid CreditReportAddress> addresses) {
    this.addresses = addresses;
    return this;
  }

  public GetCustomerCreditReportRequest addAddressesItem(CreditReportAddress addressesItem) {
    if (this.addresses == null) {
      this.addresses = new ArrayList<>();
    }
    this.addresses.add(addressesItem);
    return this;
  }

  /**
   * Customer addresses. Required: at least 1, up to 2.
   * @return addresses
  */
  @NotNull @Valid @Size(min = 1, max = 2) 
  @Schema(name = "addresses", description = "Customer addresses. Required: at least 1, up to 2.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("addresses")
  public List<@Valid CreditReportAddress> getAddresses() {
    return addresses;
  }

  public void setAddresses(List<@Valid CreditReportAddress> addresses) {
    this.addresses = addresses;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GetCustomerCreditReportRequest getCustomerCreditReportRequest = (GetCustomerCreditReportRequest) o;
    return Objects.equals(this.header, getCustomerCreditReportRequest.header) &&
        Objects.equals(this.name, getCustomerCreditReportRequest.name) &&
        Objects.equals(this.addresses, getCustomerCreditReportRequest.addresses);
  }

  @Override
  public int hashCode() {
    return Objects.hash(header, name, addresses);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GetCustomerCreditReportRequest {\n");
    sb.append("    header: ").append(toIndentedString(header)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    addresses: ").append(toIndentedString(addresses)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

