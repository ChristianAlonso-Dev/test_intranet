package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Summary of the Customer&#39;s file.
 */

@Schema(name = "buroReportSummary", description = "Summary of the Customer's file.")
@JsonTypeName("buroReportSummary")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroReportSummary {

  private String databaseEntryDate;

  private String accountsMop7;

  private String accountsMop6;

  private String accountsMop5;

  private String accountsMop4;

  private String accountsMop3;

  private String accountsMop2;

  private String accountsMop1;

  private String accountsMop0;

  private String accountsMopUr;

  private String totalAccounts;

  private String fixedPaymentMortgageAccounts;

  private String openRevolvingAccounts;

  private String closedAccounts;

  private String currentNegativeAccounts;

  private String negativeHistoryAccounts;

  private String disputedAccounts;

  private String newAddressLast60Days;

  private String alertMessages;

  private String currencyCode;

  private String revolvingTotalMaximumCredit;

  private String revolvingTotalCreditLimit;

  private String revolvingTotalCurrentBalance;

  private String revolvingTotalPastDueBalance;

  private String revolvingTotalPayments;

  private String revolvingCreditLimitUsedPercentage;

  private String accountsMop96;

  private String accountsMop97;

  private String accountsMop99;

  private String oldestAccountOpeningDate;

  private String newestAccountOpeningDate;

  private String totalInquiries;

  private String mostRecentInquiryDate;

  private String collectionAgencyAccounts;

  private String collectionAgencyNewestAccountOpeningDate;

  private String collectionAgencyInquiries;

  private String collectionAgencyMostRecentInquiryDate;

  private String consumerStatementExists;

  private String inquiriesLast6Months;

  private String fixedPaymentTotalMaximumCredit;

  private String fixedPaymentTotalPastDueBalance;

  private String fixedPaymentTotalPayments;

  private String fixedPaymentTotalCurrentBalance;

  public BuroReportSummary databaseEntryDate(String databaseEntryDate) {
    this.databaseEntryDate = databaseEntryDate;
    return this;
  }

  /**
   * Date the Customer was first registered in the database (DDMMAAAA).
   * @return databaseEntryDate
  */
  @Size(max = 8) 
  @Schema(name = "databaseEntryDate", example = "23052013", description = "Date the Customer was first registered in the database (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("databaseEntryDate")
  public String getDatabaseEntryDate() {
    return databaseEntryDate;
  }

  public void setDatabaseEntryDate(String databaseEntryDate) {
    this.databaseEntryDate = databaseEntryDate;
  }

  public BuroReportSummary accountsMop7(String accountsMop7) {
    this.accountsMop7 = accountsMop7;
    return this;
  }

  /**
   * Accounts with MOP = 07.
   * @return accountsMop7
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop7", example = "00", description = "Accounts with MOP = 07.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop7")
  public String getAccountsMop7() {
    return accountsMop7;
  }

  public void setAccountsMop7(String accountsMop7) {
    this.accountsMop7 = accountsMop7;
  }

  public BuroReportSummary accountsMop6(String accountsMop6) {
    this.accountsMop6 = accountsMop6;
    return this;
  }

  /**
   * Accounts with MOP = 06.
   * @return accountsMop6
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop6", example = "00", description = "Accounts with MOP = 06.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop6")
  public String getAccountsMop6() {
    return accountsMop6;
  }

  public void setAccountsMop6(String accountsMop6) {
    this.accountsMop6 = accountsMop6;
  }

  public BuroReportSummary accountsMop5(String accountsMop5) {
    this.accountsMop5 = accountsMop5;
    return this;
  }

  /**
   * Accounts with MOP = 05.
   * @return accountsMop5
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop5", example = "00", description = "Accounts with MOP = 05.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop5")
  public String getAccountsMop5() {
    return accountsMop5;
  }

  public void setAccountsMop5(String accountsMop5) {
    this.accountsMop5 = accountsMop5;
  }

  public BuroReportSummary accountsMop4(String accountsMop4) {
    this.accountsMop4 = accountsMop4;
    return this;
  }

  /**
   * Accounts with MOP = 04.
   * @return accountsMop4
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop4", example = "00", description = "Accounts with MOP = 04.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop4")
  public String getAccountsMop4() {
    return accountsMop4;
  }

  public void setAccountsMop4(String accountsMop4) {
    this.accountsMop4 = accountsMop4;
  }

  public BuroReportSummary accountsMop3(String accountsMop3) {
    this.accountsMop3 = accountsMop3;
    return this;
  }

  /**
   * Accounts with MOP = 03.
   * @return accountsMop3
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop3", example = "00", description = "Accounts with MOP = 03.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop3")
  public String getAccountsMop3() {
    return accountsMop3;
  }

  public void setAccountsMop3(String accountsMop3) {
    this.accountsMop3 = accountsMop3;
  }

  public BuroReportSummary accountsMop2(String accountsMop2) {
    this.accountsMop2 = accountsMop2;
    return this;
  }

  /**
   * Accounts with MOP = 02.
   * @return accountsMop2
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop2", example = "03", description = "Accounts with MOP = 02.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop2")
  public String getAccountsMop2() {
    return accountsMop2;
  }

  public void setAccountsMop2(String accountsMop2) {
    this.accountsMop2 = accountsMop2;
  }

  public BuroReportSummary accountsMop1(String accountsMop1) {
    this.accountsMop1 = accountsMop1;
    return this;
  }

  /**
   * Accounts with MOP = 01.
   * @return accountsMop1
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop1", example = "36", description = "Accounts with MOP = 01.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop1")
  public String getAccountsMop1() {
    return accountsMop1;
  }

  public void setAccountsMop1(String accountsMop1) {
    this.accountsMop1 = accountsMop1;
  }

  public BuroReportSummary accountsMop0(String accountsMop0) {
    this.accountsMop0 = accountsMop0;
    return this;
  }

  /**
   * Accounts with MOP = 00.
   * @return accountsMop0
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop0", example = "04", description = "Accounts with MOP = 00.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop0")
  public String getAccountsMop0() {
    return accountsMop0;
  }

  public void setAccountsMop0(String accountsMop0) {
    this.accountsMop0 = accountsMop0;
  }

  public BuroReportSummary accountsMopUr(String accountsMopUr) {
    this.accountsMopUr = accountsMopUr;
    return this;
  }

  /**
   * Accounts with MOP = UR.
   * @return accountsMopUr
  */
  @Size(max = 2) 
  @Schema(name = "accountsMopUr", example = "00", description = "Accounts with MOP = UR.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMopUr")
  public String getAccountsMopUr() {
    return accountsMopUr;
  }

  public void setAccountsMopUr(String accountsMopUr) {
    this.accountsMopUr = accountsMopUr;
  }

  public BuroReportSummary totalAccounts(String totalAccounts) {
    this.totalAccounts = totalAccounts;
    return this;
  }

  /**
   * Total accounts in the file.
   * @return totalAccounts
  */
  @Size(max = 4) 
  @Schema(name = "totalAccounts", example = "0044", description = "Total accounts in the file.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalAccounts")
  public String getTotalAccounts() {
    return totalAccounts;
  }

  public void setTotalAccounts(String totalAccounts) {
    this.totalAccounts = totalAccounts;
  }

  public BuroReportSummary fixedPaymentMortgageAccounts(String fixedPaymentMortgageAccounts) {
    this.fixedPaymentMortgageAccounts = fixedPaymentMortgageAccounts;
    return this;
  }

  /**
   * Fixed payment (I) and mortgage (M) accounts.
   * @return fixedPaymentMortgageAccounts
  */
  @Size(max = 4) 
  @Schema(name = "fixedPaymentMortgageAccounts", example = "0021", description = "Fixed payment (I) and mortgage (M) accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fixedPaymentMortgageAccounts")
  public String getFixedPaymentMortgageAccounts() {
    return fixedPaymentMortgageAccounts;
  }

  public void setFixedPaymentMortgageAccounts(String fixedPaymentMortgageAccounts) {
    this.fixedPaymentMortgageAccounts = fixedPaymentMortgageAccounts;
  }

  public BuroReportSummary openRevolvingAccounts(String openRevolvingAccounts) {
    this.openRevolvingAccounts = openRevolvingAccounts;
    return this;
  }

  /**
   * Revolving (R) and no pre-established limit (O) accounts.
   * @return openRevolvingAccounts
  */
  @Size(max = 4) 
  @Schema(name = "openRevolvingAccounts", example = "0023", description = "Revolving (R) and no pre-established limit (O) accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("openRevolvingAccounts")
  public String getOpenRevolvingAccounts() {
    return openRevolvingAccounts;
  }

  public void setOpenRevolvingAccounts(String openRevolvingAccounts) {
    this.openRevolvingAccounts = openRevolvingAccounts;
  }

  public BuroReportSummary closedAccounts(String closedAccounts) {
    this.closedAccounts = closedAccounts;
    return this;
  }

  /**
   * Closed accounts.
   * @return closedAccounts
  */
  @Size(max = 4) 
  @Schema(name = "closedAccounts", example = "0014", description = "Closed accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("closedAccounts")
  public String getClosedAccounts() {
    return closedAccounts;
  }

  public void setClosedAccounts(String closedAccounts) {
    this.closedAccounts = closedAccounts;
  }

  public BuroReportSummary currentNegativeAccounts(String currentNegativeAccounts) {
    this.currentNegativeAccounts = currentNegativeAccounts;
    return this;
  }

  /**
   * Accounts with current MOP 02 to 07, 96, 97 or 99.
   * @return currentNegativeAccounts
  */
  @Size(max = 4) 
  @Schema(name = "currentNegativeAccounts", example = "0004", description = "Accounts with current MOP 02 to 07, 96, 97 or 99.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentNegativeAccounts")
  public String getCurrentNegativeAccounts() {
    return currentNegativeAccounts;
  }

  public void setCurrentNegativeAccounts(String currentNegativeAccounts) {
    this.currentNegativeAccounts = currentNegativeAccounts;
  }

  public BuroReportSummary negativeHistoryAccounts(String negativeHistoryAccounts) {
    this.negativeHistoryAccounts = negativeHistoryAccounts;
    return this;
  }

  /**
   * Accounts with current MOP UR or 01 and negative history (MOP 02 to 07, 96, 97 or 99), up to 72 months.
   * @return negativeHistoryAccounts
  */
  @Size(max = 4) 
  @Schema(name = "negativeHistoryAccounts", example = "0002", description = "Accounts with current MOP UR or 01 and negative history (MOP 02 to 07, 96, 97 or 99), up to 72 months.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("negativeHistoryAccounts")
  public String getNegativeHistoryAccounts() {
    return negativeHistoryAccounts;
  }

  public void setNegativeHistoryAccounts(String negativeHistoryAccounts) {
    this.negativeHistoryAccounts = negativeHistoryAccounts;
  }

  public BuroReportSummary disputedAccounts(String disputedAccounts) {
    this.disputedAccounts = disputedAccounts;
    return this;
  }

  /**
   * Accounts with observation code AD (under clarification).
   * @return disputedAccounts
  */
  @Size(max = 2) 
  @Schema(name = "disputedAccounts", example = "01", description = "Accounts with observation code AD (under clarification).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("disputedAccounts")
  public String getDisputedAccounts() {
    return disputedAccounts;
  }

  public void setDisputedAccounts(String disputedAccounts) {
    this.disputedAccounts = disputedAccounts;
  }

  public BuroReportSummary newAddressLast60Days(String newAddressLast60Days) {
    this.newAddressLast60Days = newAddressLast60Days;
    return this;
  }

  /**
   * New address in the last 60 days: Y = Yes, N = No.
   * @return newAddressLast60Days
  */
  @Size(max = 1) 
  @Schema(name = "newAddressLast60Days", example = "Y", description = "New address in the last 60 days: Y = Yes, N = No.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("newAddressLast60Days")
  public String getNewAddressLast60Days() {
    return newAddressLast60Days;
  }

  public void setNewAddressLast60Days(String newAddressLast60Days) {
    this.newAddressLast60Days = newAddressLast60Days;
  }

  public BuroReportSummary alertMessages(String alertMessages) {
    this.alertMessages = alertMessages;
    return this;
  }

  /**
   * Alert flags (Y/N) by position: 1 date of death, 2 RFC mismatch, 3 address mismatch, 4 future use, 5 invalid address in the query, 6 User with fewer than 5,000 records, 7-8 future use. NNNNN = no alerts.
   * @return alertMessages
  */
  @Size(max = 8) 
  @Schema(name = "alertMessages", example = "NNNYNY", description = "Alert flags (Y/N) by position: 1 date of death, 2 RFC mismatch, 3 address mismatch, 4 future use, 5 invalid address in the query, 6 User with fewer than 5,000 records, 7-8 future use. NNNNN = no alerts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("alertMessages")
  public String getAlertMessages() {
    return alertMessages;
  }

  public void setAlertMessages(String alertMessages) {
    this.alertMessages = alertMessages;
  }

  public BuroReportSummary currencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
    return this;
  }

  /**
   * Credit currency: MX = Mexican Pesos, N$ = Mexican Pesos, UD = Investment Units (UDI's), US = US Dollars.
   * @return currencyCode
  */
  @Size(max = 2) 
  @Schema(name = "currencyCode", example = "MX", description = "Credit currency: MX = Mexican Pesos, N$ = Mexican Pesos, UD = Investment Units (UDI's), US = US Dollars.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currencyCode")
  public String getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
  }

  public BuroReportSummary revolvingTotalMaximumCredit(String revolvingTotalMaximumCredit) {
    this.revolvingTotalMaximumCredit = revolvingTotalMaximumCredit;
    return this;
  }

  /**
   * Sum of maximum credits of active R and O accounts.
   * @return revolvingTotalMaximumCredit
  */
  @Size(max = 9) 
  @Schema(name = "revolvingTotalMaximumCredit", example = "000234211", description = "Sum of maximum credits of active R and O accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("revolvingTotalMaximumCredit")
  public String getRevolvingTotalMaximumCredit() {
    return revolvingTotalMaximumCredit;
  }

  public void setRevolvingTotalMaximumCredit(String revolvingTotalMaximumCredit) {
    this.revolvingTotalMaximumCredit = revolvingTotalMaximumCredit;
  }

  public BuroReportSummary revolvingTotalCreditLimit(String revolvingTotalCreditLimit) {
    this.revolvingTotalCreditLimit = revolvingTotalCreditLimit;
    return this;
  }

  /**
   * Sum of credit limits of active R and O accounts.
   * @return revolvingTotalCreditLimit
  */
  @Size(max = 9) 
  @Schema(name = "revolvingTotalCreditLimit", example = "000517291", description = "Sum of credit limits of active R and O accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("revolvingTotalCreditLimit")
  public String getRevolvingTotalCreditLimit() {
    return revolvingTotalCreditLimit;
  }

  public void setRevolvingTotalCreditLimit(String revolvingTotalCreditLimit) {
    this.revolvingTotalCreditLimit = revolvingTotalCreditLimit;
  }

  public BuroReportSummary revolvingTotalCurrentBalance(String revolvingTotalCurrentBalance) {
    this.revolvingTotalCurrentBalance = revolvingTotalCurrentBalance;
    return this;
  }

  /**
   * Sum of current balances of active R and O accounts.
   * @return revolvingTotalCurrentBalance
  */
  @Size(max = 10) 
  @Schema(name = "revolvingTotalCurrentBalance", example = "000334673+", description = "Sum of current balances of active R and O accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("revolvingTotalCurrentBalance")
  public String getRevolvingTotalCurrentBalance() {
    return revolvingTotalCurrentBalance;
  }

  public void setRevolvingTotalCurrentBalance(String revolvingTotalCurrentBalance) {
    this.revolvingTotalCurrentBalance = revolvingTotalCurrentBalance;
  }

  public BuroReportSummary revolvingTotalPastDueBalance(String revolvingTotalPastDueBalance) {
    this.revolvingTotalPastDueBalance = revolvingTotalPastDueBalance;
    return this;
  }

  /**
   * Sum of past due balances of R and O accounts.
   * @return revolvingTotalPastDueBalance
  */
  @Size(max = 9) 
  @Schema(name = "revolvingTotalPastDueBalance", example = "000000050", description = "Sum of past due balances of R and O accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("revolvingTotalPastDueBalance")
  public String getRevolvingTotalPastDueBalance() {
    return revolvingTotalPastDueBalance;
  }

  public void setRevolvingTotalPastDueBalance(String revolvingTotalPastDueBalance) {
    this.revolvingTotalPastDueBalance = revolvingTotalPastDueBalance;
  }

  public BuroReportSummary revolvingTotalPayments(String revolvingTotalPayments) {
    this.revolvingTotalPayments = revolvingTotalPayments;
    return this;
  }

  /**
   * Sum of payment amounts of active R and O accounts.
   * @return revolvingTotalPayments
  */
  @Size(max = 9) 
  @Schema(name = "revolvingTotalPayments", example = "000015184", description = "Sum of payment amounts of active R and O accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("revolvingTotalPayments")
  public String getRevolvingTotalPayments() {
    return revolvingTotalPayments;
  }

  public void setRevolvingTotalPayments(String revolvingTotalPayments) {
    this.revolvingTotalPayments = revolvingTotalPayments;
  }

  public BuroReportSummary revolvingCreditLimitUsedPercentage(String revolvingCreditLimitUsedPercentage) {
    this.revolvingCreditLimitUsedPercentage = revolvingCreditLimitUsedPercentage;
    return this;
  }

  /**
   * Percentage of the credit limit used by active R and O accounts.
   * @return revolvingCreditLimitUsedPercentage
  */
  @Size(max = 3) 
  @Schema(name = "revolvingCreditLimitUsedPercentage", example = "115", description = "Percentage of the credit limit used by active R and O accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("revolvingCreditLimitUsedPercentage")
  public String getRevolvingCreditLimitUsedPercentage() {
    return revolvingCreditLimitUsedPercentage;
  }

  public void setRevolvingCreditLimitUsedPercentage(String revolvingCreditLimitUsedPercentage) {
    this.revolvingCreditLimitUsedPercentage = revolvingCreditLimitUsedPercentage;
  }

  public BuroReportSummary accountsMop96(String accountsMop96) {
    this.accountsMop96 = accountsMop96;
    return this;
  }

  /**
   * Accounts with MOP = 96.
   * @return accountsMop96
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop96", example = "00", description = "Accounts with MOP = 96.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop96")
  public String getAccountsMop96() {
    return accountsMop96;
  }

  public void setAccountsMop96(String accountsMop96) {
    this.accountsMop96 = accountsMop96;
  }

  public BuroReportSummary accountsMop97(String accountsMop97) {
    this.accountsMop97 = accountsMop97;
    return this;
  }

  /**
   * Accounts with MOP = 97.
   * @return accountsMop97
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop97", example = "00", description = "Accounts with MOP = 97.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop97")
  public String getAccountsMop97() {
    return accountsMop97;
  }

  public void setAccountsMop97(String accountsMop97) {
    this.accountsMop97 = accountsMop97;
  }

  public BuroReportSummary accountsMop99(String accountsMop99) {
    this.accountsMop99 = accountsMop99;
    return this;
  }

  /**
   * Accounts with MOP = 99.
   * @return accountsMop99
  */
  @Size(max = 2) 
  @Schema(name = "accountsMop99", example = "01", description = "Accounts with MOP = 99.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountsMop99")
  public String getAccountsMop99() {
    return accountsMop99;
  }

  public void setAccountsMop99(String accountsMop99) {
    this.accountsMop99 = accountsMop99;
  }

  public BuroReportSummary oldestAccountOpeningDate(String oldestAccountOpeningDate) {
    this.oldestAccountOpeningDate = oldestAccountOpeningDate;
    return this;
  }

  /**
   * Opening date of the oldest account.
   * @return oldestAccountOpeningDate
  */
  @Size(max = 8) 
  @Schema(name = "oldestAccountOpeningDate", example = "01012000", description = "Opening date of the oldest account.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("oldestAccountOpeningDate")
  public String getOldestAccountOpeningDate() {
    return oldestAccountOpeningDate;
  }

  public void setOldestAccountOpeningDate(String oldestAccountOpeningDate) {
    this.oldestAccountOpeningDate = oldestAccountOpeningDate;
  }

  public BuroReportSummary newestAccountOpeningDate(String newestAccountOpeningDate) {
    this.newestAccountOpeningDate = newestAccountOpeningDate;
    return this;
  }

  /**
   * Opening date of the most recent account.
   * @return newestAccountOpeningDate
  */
  @Size(max = 8) 
  @Schema(name = "newestAccountOpeningDate", example = "20062021", description = "Opening date of the most recent account.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("newestAccountOpeningDate")
  public String getNewestAccountOpeningDate() {
    return newestAccountOpeningDate;
  }

  public void setNewestAccountOpeningDate(String newestAccountOpeningDate) {
    this.newestAccountOpeningDate = newestAccountOpeningDate;
  }

  public BuroReportSummary totalInquiries(String totalInquiries) {
    this.totalInquiries = totalInquiries;
    return this;
  }

  /**
   * Queries to the file, excluding the current one.
   * @return totalInquiries
  */
  @Size(max = 2) 
  @Schema(name = "totalInquiries", example = "99", description = "Queries to the file, excluding the current one.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalInquiries")
  public String getTotalInquiries() {
    return totalInquiries;
  }

  public void setTotalInquiries(String totalInquiries) {
    this.totalInquiries = totalInquiries;
  }

  public BuroReportSummary mostRecentInquiryDate(String mostRecentInquiryDate) {
    this.mostRecentInquiryDate = mostRecentInquiryDate;
    return this;
  }

  /**
   * Most recent query date, excluding the current one.
   * @return mostRecentInquiryDate
  */
  @Size(max = 8) 
  @Schema(name = "mostRecentInquiryDate", example = "13092022", description = "Most recent query date, excluding the current one.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("mostRecentInquiryDate")
  public String getMostRecentInquiryDate() {
    return mostRecentInquiryDate;
  }

  public void setMostRecentInquiryDate(String mostRecentInquiryDate) {
    this.mostRecentInquiryDate = mostRecentInquiryDate;
  }

  public BuroReportSummary collectionAgencyAccounts(String collectionAgencyAccounts) {
    this.collectionAgencyAccounts = collectionAgencyAccounts;
    return this;
  }

  /**
   * Accounts reported by collection agencies or portfolio managers (KOB YY).
   * @return collectionAgencyAccounts
  */
  @Size(max = 2) 
  @Schema(name = "collectionAgencyAccounts", example = "00", description = "Accounts reported by collection agencies or portfolio managers (KOB YY).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("collectionAgencyAccounts")
  public String getCollectionAgencyAccounts() {
    return collectionAgencyAccounts;
  }

  public void setCollectionAgencyAccounts(String collectionAgencyAccounts) {
    this.collectionAgencyAccounts = collectionAgencyAccounts;
  }

  public BuroReportSummary collectionAgencyNewestAccountOpeningDate(String collectionAgencyNewestAccountOpeningDate) {
    this.collectionAgencyNewestAccountOpeningDate = collectionAgencyNewestAccountOpeningDate;
    return this;
  }

  /**
   * Opening date of the most recent account in a collection agency or portfolio manager.
   * @return collectionAgencyNewestAccountOpeningDate
  */
  @Size(max = 8) 
  @Schema(name = "collectionAgencyNewestAccountOpeningDate", example = "00000000", description = "Opening date of the most recent account in a collection agency or portfolio manager.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("collectionAgencyNewestAccountOpeningDate")
  public String getCollectionAgencyNewestAccountOpeningDate() {
    return collectionAgencyNewestAccountOpeningDate;
  }

  public void setCollectionAgencyNewestAccountOpeningDate(String collectionAgencyNewestAccountOpeningDate) {
    this.collectionAgencyNewestAccountOpeningDate = collectionAgencyNewestAccountOpeningDate;
  }

  public BuroReportSummary collectionAgencyInquiries(String collectionAgencyInquiries) {
    this.collectionAgencyInquiries = collectionAgencyInquiries;
    return this;
  }

  /**
   * Queries by collection agencies or portfolio managers, excluding the current one.
   * @return collectionAgencyInquiries
  */
  @Size(max = 2) 
  @Schema(name = "collectionAgencyInquiries", example = "00", description = "Queries by collection agencies or portfolio managers, excluding the current one.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("collectionAgencyInquiries")
  public String getCollectionAgencyInquiries() {
    return collectionAgencyInquiries;
  }

  public void setCollectionAgencyInquiries(String collectionAgencyInquiries) {
    this.collectionAgencyInquiries = collectionAgencyInquiries;
  }

  public BuroReportSummary collectionAgencyMostRecentInquiryDate(String collectionAgencyMostRecentInquiryDate) {
    this.collectionAgencyMostRecentInquiryDate = collectionAgencyMostRecentInquiryDate;
    return this;
  }

  /**
   * Most recent query by a collection agency or portfolio manager (KOB YY), excluding the current one.
   * @return collectionAgencyMostRecentInquiryDate
  */
  @Size(max = 8) 
  @Schema(name = "collectionAgencyMostRecentInquiryDate", example = "00000000", description = "Most recent query by a collection agency or portfolio manager (KOB YY), excluding the current one.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("collectionAgencyMostRecentInquiryDate")
  public String getCollectionAgencyMostRecentInquiryDate() {
    return collectionAgencyMostRecentInquiryDate;
  }

  public void setCollectionAgencyMostRecentInquiryDate(String collectionAgencyMostRecentInquiryDate) {
    this.collectionAgencyMostRecentInquiryDate = collectionAgencyMostRecentInquiryDate;
  }

  public BuroReportSummary consumerStatementExists(String consumerStatementExists) {
    this.consumerStatementExists = consumerStatementExists;
    return this;
  }

  /**
   * Consumer statement in the file: Y = Yes, N = No.
   * @return consumerStatementExists
  */
  @Size(max = 1) 
  @Schema(name = "consumerStatementExists", example = "Y", description = "Consumer statement in the file: Y = Yes, N = No.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("consumerStatementExists")
  public String getConsumerStatementExists() {
    return consumerStatementExists;
  }

  public void setConsumerStatementExists(String consumerStatementExists) {
    this.consumerStatementExists = consumerStatementExists;
  }

  public BuroReportSummary inquiriesLast6Months(String inquiriesLast6Months) {
    this.inquiriesLast6Months = inquiriesLast6Months;
    return this;
  }

  /**
   * Queries to the file in the last 6 months.
   * @return inquiriesLast6Months
  */
  @Size(max = 2) 
  @Schema(name = "inquiriesLast6Months", example = "99", description = "Queries to the file in the last 6 months.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("inquiriesLast6Months")
  public String getInquiriesLast6Months() {
    return inquiriesLast6Months;
  }

  public void setInquiriesLast6Months(String inquiriesLast6Months) {
    this.inquiriesLast6Months = inquiriesLast6Months;
  }

  public BuroReportSummary fixedPaymentTotalMaximumCredit(String fixedPaymentTotalMaximumCredit) {
    this.fixedPaymentTotalMaximumCredit = fixedPaymentTotalMaximumCredit;
    return this;
  }

  /**
   * Sum of maximum credits of open fixed payment and mortgage accounts. The plus symbol (+) may be shown at the end of the amount.
   * @return fixedPaymentTotalMaximumCredit
  */
  @Size(max = 9) 
  @Schema(name = "fixedPaymentTotalMaximumCredit", example = "000434093", description = "Sum of maximum credits of open fixed payment and mortgage accounts. The plus symbol (+) may be shown at the end of the amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fixedPaymentTotalMaximumCredit")
  public String getFixedPaymentTotalMaximumCredit() {
    return fixedPaymentTotalMaximumCredit;
  }

  public void setFixedPaymentTotalMaximumCredit(String fixedPaymentTotalMaximumCredit) {
    this.fixedPaymentTotalMaximumCredit = fixedPaymentTotalMaximumCredit;
  }

  public BuroReportSummary fixedPaymentTotalPastDueBalance(String fixedPaymentTotalPastDueBalance) {
    this.fixedPaymentTotalPastDueBalance = fixedPaymentTotalPastDueBalance;
    return this;
  }

  /**
   * Sum of past due balances of open fixed payment and mortgage accounts. The plus symbol (+) may be shown at the end of the amount.
   * @return fixedPaymentTotalPastDueBalance
  */
  @Size(max = 9) 
  @Schema(name = "fixedPaymentTotalPastDueBalance", example = "000000544", description = "Sum of past due balances of open fixed payment and mortgage accounts. The plus symbol (+) may be shown at the end of the amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fixedPaymentTotalPastDueBalance")
  public String getFixedPaymentTotalPastDueBalance() {
    return fixedPaymentTotalPastDueBalance;
  }

  public void setFixedPaymentTotalPastDueBalance(String fixedPaymentTotalPastDueBalance) {
    this.fixedPaymentTotalPastDueBalance = fixedPaymentTotalPastDueBalance;
  }

  public BuroReportSummary fixedPaymentTotalPayments(String fixedPaymentTotalPayments) {
    this.fixedPaymentTotalPayments = fixedPaymentTotalPayments;
    return this;
  }

  /**
   * Sum of payment amounts of open fixed payment and mortgage accounts.
   * @return fixedPaymentTotalPayments
  */
  @Size(max = 9) 
  @Schema(name = "fixedPaymentTotalPayments", example = "000009562", description = "Sum of payment amounts of open fixed payment and mortgage accounts.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fixedPaymentTotalPayments")
  public String getFixedPaymentTotalPayments() {
    return fixedPaymentTotalPayments;
  }

  public void setFixedPaymentTotalPayments(String fixedPaymentTotalPayments) {
    this.fixedPaymentTotalPayments = fixedPaymentTotalPayments;
  }

  public BuroReportSummary fixedPaymentTotalCurrentBalance(String fixedPaymentTotalCurrentBalance) {
    this.fixedPaymentTotalCurrentBalance = fixedPaymentTotalCurrentBalance;
    return this;
  }

  /**
   * Sum of current balances of open fixed payment and mortgage accounts. The plus symbol (+) may be shown at the end of the amount.
   * @return fixedPaymentTotalCurrentBalance
  */
  @Size(max = 10) 
  @Schema(name = "fixedPaymentTotalCurrentBalance", example = "000400565+", description = "Sum of current balances of open fixed payment and mortgage accounts. The plus symbol (+) may be shown at the end of the amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fixedPaymentTotalCurrentBalance")
  public String getFixedPaymentTotalCurrentBalance() {
    return fixedPaymentTotalCurrentBalance;
  }

  public void setFixedPaymentTotalCurrentBalance(String fixedPaymentTotalCurrentBalance) {
    this.fixedPaymentTotalCurrentBalance = fixedPaymentTotalCurrentBalance;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroReportSummary buroReportSummary = (BuroReportSummary) o;
    return Objects.equals(this.databaseEntryDate, buroReportSummary.databaseEntryDate) &&
        Objects.equals(this.accountsMop7, buroReportSummary.accountsMop7) &&
        Objects.equals(this.accountsMop6, buroReportSummary.accountsMop6) &&
        Objects.equals(this.accountsMop5, buroReportSummary.accountsMop5) &&
        Objects.equals(this.accountsMop4, buroReportSummary.accountsMop4) &&
        Objects.equals(this.accountsMop3, buroReportSummary.accountsMop3) &&
        Objects.equals(this.accountsMop2, buroReportSummary.accountsMop2) &&
        Objects.equals(this.accountsMop1, buroReportSummary.accountsMop1) &&
        Objects.equals(this.accountsMop0, buroReportSummary.accountsMop0) &&
        Objects.equals(this.accountsMopUr, buroReportSummary.accountsMopUr) &&
        Objects.equals(this.totalAccounts, buroReportSummary.totalAccounts) &&
        Objects.equals(this.fixedPaymentMortgageAccounts, buroReportSummary.fixedPaymentMortgageAccounts) &&
        Objects.equals(this.openRevolvingAccounts, buroReportSummary.openRevolvingAccounts) &&
        Objects.equals(this.closedAccounts, buroReportSummary.closedAccounts) &&
        Objects.equals(this.currentNegativeAccounts, buroReportSummary.currentNegativeAccounts) &&
        Objects.equals(this.negativeHistoryAccounts, buroReportSummary.negativeHistoryAccounts) &&
        Objects.equals(this.disputedAccounts, buroReportSummary.disputedAccounts) &&
        Objects.equals(this.newAddressLast60Days, buroReportSummary.newAddressLast60Days) &&
        Objects.equals(this.alertMessages, buroReportSummary.alertMessages) &&
        Objects.equals(this.currencyCode, buroReportSummary.currencyCode) &&
        Objects.equals(this.revolvingTotalMaximumCredit, buroReportSummary.revolvingTotalMaximumCredit) &&
        Objects.equals(this.revolvingTotalCreditLimit, buroReportSummary.revolvingTotalCreditLimit) &&
        Objects.equals(this.revolvingTotalCurrentBalance, buroReportSummary.revolvingTotalCurrentBalance) &&
        Objects.equals(this.revolvingTotalPastDueBalance, buroReportSummary.revolvingTotalPastDueBalance) &&
        Objects.equals(this.revolvingTotalPayments, buroReportSummary.revolvingTotalPayments) &&
        Objects.equals(this.revolvingCreditLimitUsedPercentage, buroReportSummary.revolvingCreditLimitUsedPercentage) &&
        Objects.equals(this.accountsMop96, buroReportSummary.accountsMop96) &&
        Objects.equals(this.accountsMop97, buroReportSummary.accountsMop97) &&
        Objects.equals(this.accountsMop99, buroReportSummary.accountsMop99) &&
        Objects.equals(this.oldestAccountOpeningDate, buroReportSummary.oldestAccountOpeningDate) &&
        Objects.equals(this.newestAccountOpeningDate, buroReportSummary.newestAccountOpeningDate) &&
        Objects.equals(this.totalInquiries, buroReportSummary.totalInquiries) &&
        Objects.equals(this.mostRecentInquiryDate, buroReportSummary.mostRecentInquiryDate) &&
        Objects.equals(this.collectionAgencyAccounts, buroReportSummary.collectionAgencyAccounts) &&
        Objects.equals(this.collectionAgencyNewestAccountOpeningDate, buroReportSummary.collectionAgencyNewestAccountOpeningDate) &&
        Objects.equals(this.collectionAgencyInquiries, buroReportSummary.collectionAgencyInquiries) &&
        Objects.equals(this.collectionAgencyMostRecentInquiryDate, buroReportSummary.collectionAgencyMostRecentInquiryDate) &&
        Objects.equals(this.consumerStatementExists, buroReportSummary.consumerStatementExists) &&
        Objects.equals(this.inquiriesLast6Months, buroReportSummary.inquiriesLast6Months) &&
        Objects.equals(this.fixedPaymentTotalMaximumCredit, buroReportSummary.fixedPaymentTotalMaximumCredit) &&
        Objects.equals(this.fixedPaymentTotalPastDueBalance, buroReportSummary.fixedPaymentTotalPastDueBalance) &&
        Objects.equals(this.fixedPaymentTotalPayments, buroReportSummary.fixedPaymentTotalPayments) &&
        Objects.equals(this.fixedPaymentTotalCurrentBalance, buroReportSummary.fixedPaymentTotalCurrentBalance);
  }

  @Override
  public int hashCode() {
    return Objects.hash(databaseEntryDate, accountsMop7, accountsMop6, accountsMop5, accountsMop4, accountsMop3, accountsMop2, accountsMop1, accountsMop0, accountsMopUr, totalAccounts, fixedPaymentMortgageAccounts, openRevolvingAccounts, closedAccounts, currentNegativeAccounts, negativeHistoryAccounts, disputedAccounts, newAddressLast60Days, alertMessages, currencyCode, revolvingTotalMaximumCredit, revolvingTotalCreditLimit, revolvingTotalCurrentBalance, revolvingTotalPastDueBalance, revolvingTotalPayments, revolvingCreditLimitUsedPercentage, accountsMop96, accountsMop97, accountsMop99, oldestAccountOpeningDate, newestAccountOpeningDate, totalInquiries, mostRecentInquiryDate, collectionAgencyAccounts, collectionAgencyNewestAccountOpeningDate, collectionAgencyInquiries, collectionAgencyMostRecentInquiryDate, consumerStatementExists, inquiriesLast6Months, fixedPaymentTotalMaximumCredit, fixedPaymentTotalPastDueBalance, fixedPaymentTotalPayments, fixedPaymentTotalCurrentBalance);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroReportSummary {\n");
    sb.append("    databaseEntryDate: ").append(toIndentedString(databaseEntryDate)).append("\n");
    sb.append("    accountsMop7: ").append(toIndentedString(accountsMop7)).append("\n");
    sb.append("    accountsMop6: ").append(toIndentedString(accountsMop6)).append("\n");
    sb.append("    accountsMop5: ").append(toIndentedString(accountsMop5)).append("\n");
    sb.append("    accountsMop4: ").append(toIndentedString(accountsMop4)).append("\n");
    sb.append("    accountsMop3: ").append(toIndentedString(accountsMop3)).append("\n");
    sb.append("    accountsMop2: ").append(toIndentedString(accountsMop2)).append("\n");
    sb.append("    accountsMop1: ").append(toIndentedString(accountsMop1)).append("\n");
    sb.append("    accountsMop0: ").append(toIndentedString(accountsMop0)).append("\n");
    sb.append("    accountsMopUr: ").append(toIndentedString(accountsMopUr)).append("\n");
    sb.append("    totalAccounts: ").append(toIndentedString(totalAccounts)).append("\n");
    sb.append("    fixedPaymentMortgageAccounts: ").append(toIndentedString(fixedPaymentMortgageAccounts)).append("\n");
    sb.append("    openRevolvingAccounts: ").append(toIndentedString(openRevolvingAccounts)).append("\n");
    sb.append("    closedAccounts: ").append(toIndentedString(closedAccounts)).append("\n");
    sb.append("    currentNegativeAccounts: ").append(toIndentedString(currentNegativeAccounts)).append("\n");
    sb.append("    negativeHistoryAccounts: ").append(toIndentedString(negativeHistoryAccounts)).append("\n");
    sb.append("    disputedAccounts: ").append(toIndentedString(disputedAccounts)).append("\n");
    sb.append("    newAddressLast60Days: ").append(toIndentedString(newAddressLast60Days)).append("\n");
    sb.append("    alertMessages: ").append(toIndentedString(alertMessages)).append("\n");
    sb.append("    currencyCode: ").append(toIndentedString(currencyCode)).append("\n");
    sb.append("    revolvingTotalMaximumCredit: ").append(toIndentedString(revolvingTotalMaximumCredit)).append("\n");
    sb.append("    revolvingTotalCreditLimit: ").append(toIndentedString(revolvingTotalCreditLimit)).append("\n");
    sb.append("    revolvingTotalCurrentBalance: ").append(toIndentedString(revolvingTotalCurrentBalance)).append("\n");
    sb.append("    revolvingTotalPastDueBalance: ").append(toIndentedString(revolvingTotalPastDueBalance)).append("\n");
    sb.append("    revolvingTotalPayments: ").append(toIndentedString(revolvingTotalPayments)).append("\n");
    sb.append("    revolvingCreditLimitUsedPercentage: ").append(toIndentedString(revolvingCreditLimitUsedPercentage)).append("\n");
    sb.append("    accountsMop96: ").append(toIndentedString(accountsMop96)).append("\n");
    sb.append("    accountsMop97: ").append(toIndentedString(accountsMop97)).append("\n");
    sb.append("    accountsMop99: ").append(toIndentedString(accountsMop99)).append("\n");
    sb.append("    oldestAccountOpeningDate: ").append(toIndentedString(oldestAccountOpeningDate)).append("\n");
    sb.append("    newestAccountOpeningDate: ").append(toIndentedString(newestAccountOpeningDate)).append("\n");
    sb.append("    totalInquiries: ").append(toIndentedString(totalInquiries)).append("\n");
    sb.append("    mostRecentInquiryDate: ").append(toIndentedString(mostRecentInquiryDate)).append("\n");
    sb.append("    collectionAgencyAccounts: ").append(toIndentedString(collectionAgencyAccounts)).append("\n");
    sb.append("    collectionAgencyNewestAccountOpeningDate: ").append(toIndentedString(collectionAgencyNewestAccountOpeningDate)).append("\n");
    sb.append("    collectionAgencyInquiries: ").append(toIndentedString(collectionAgencyInquiries)).append("\n");
    sb.append("    collectionAgencyMostRecentInquiryDate: ").append(toIndentedString(collectionAgencyMostRecentInquiryDate)).append("\n");
    sb.append("    consumerStatementExists: ").append(toIndentedString(consumerStatementExists)).append("\n");
    sb.append("    inquiriesLast6Months: ").append(toIndentedString(inquiriesLast6Months)).append("\n");
    sb.append("    fixedPaymentTotalMaximumCredit: ").append(toIndentedString(fixedPaymentTotalMaximumCredit)).append("\n");
    sb.append("    fixedPaymentTotalPastDueBalance: ").append(toIndentedString(fixedPaymentTotalPastDueBalance)).append("\n");
    sb.append("    fixedPaymentTotalPayments: ").append(toIndentedString(fixedPaymentTotalPayments)).append("\n");
    sb.append("    fixedPaymentTotalCurrentBalance: ").append(toIndentedString(fixedPaymentTotalCurrentBalance)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

