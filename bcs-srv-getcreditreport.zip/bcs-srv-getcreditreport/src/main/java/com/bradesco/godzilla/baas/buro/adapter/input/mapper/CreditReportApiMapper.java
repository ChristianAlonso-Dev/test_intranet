package com.bradesco.godzilla.baas.buro.adapter.input.mapper;

import com.bradesco.godzilla.baas.buro.api.model.*;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerAddress;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerName;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.InquiryHeader;
import com.bradesco.godzilla.baas.buro.domain.model.report.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface CreditReportApiMapper {

    CreditReportInquiry toInquiry(GetCustomerCreditReportRequest request);

    InquiryHeader toInquiryHeader(CreditReportHeader header);

    CustomerName toCustomerName(CreditReportName name);

    CustomerAddress toCustomerAddress(CreditReportAddress address);

    List<CustomerAddress> toCustomerAddresses(List<CreditReportAddress> addresses);

    @Mapping(target = "response.person", source = "creditReport")
    BuroCreditReportResponse toApiResponse(CreditReport creditReport);

    BuroPerson toApiPerson(CreditReport creditReport);

    BuroHeader toApiHeader(ReportHeader header);

    BuroName toApiName(ReportName name);

    BuroAddress toApiAddress(ReportAddress address);

    BuroEmployment toApiEmployment(ReportEmployment employment);

    BuroAccount toApiAccount(ReportAccount account);

    BuroInquiry toApiInquiry(ReportInquiry inquiry);

    BuroReportSummary toApiReportSummary(ReportSummary reportSummary);

    BuroHawkAlertInquiry toApiHawkAlertInquiry(HawkAlert hawkAlert);

    BuroHawkAlertDatabase toApiHawkAlertDatabase(HawkAlert hawkAlert);

    BuroConsumerStatement toApiConsumerStatement(ConsumerStatement consumerStatement);

    BuroScore toApiScore(ReportScore score);

    default String toValue(CreditReportHeader.ContractTypeEnum contractType) {
        return contractType == null ? null : contractType.getValue();
    }

    default String toValue(CreditReportHeader.RequiredProductEnum requiredProduct) {
        return requiredProduct == null ? null : requiredProduct.getValue();
    }

    default String toValue(CreditReportAddress.StateEnum state) {
        return state == null ? null : state.getValue();
    }

    default String toValue(CreditReportAddress.CountryCodeEnum countryCode) {
        return countryCode == null ? null : countryCode.getValue();
    }
}
