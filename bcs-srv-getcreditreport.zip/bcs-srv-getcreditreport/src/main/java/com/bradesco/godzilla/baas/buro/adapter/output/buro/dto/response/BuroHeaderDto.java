package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroHeaderDto(
        @JsonProperty("clavePais") String countryCode,
        @JsonProperty("identificadorBuro") String buroIdentifier,
        @JsonProperty("numeroReferenciaOperador") String operatorReference,
        @JsonProperty("claveOtorgante") String memberCode,
        @JsonProperty("claveRetornoConsumidorPrincipal") String primaryConsumerReturnCode,
        @JsonProperty("claveRetornoConsumidorSecundario") String secondaryConsumerReturnCode,
        @JsonProperty("numeroControlConsulta") String queryControlNumber
) {
}
