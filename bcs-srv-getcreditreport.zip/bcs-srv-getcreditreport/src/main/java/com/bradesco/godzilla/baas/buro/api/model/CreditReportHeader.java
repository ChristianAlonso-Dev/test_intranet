package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Query header. If any data is missing or incorrect, the complete query is rejected.
 */

@Schema(name = "creditReportHeader", description = "Query header. If any data is missing or incorrect, the complete query is rejected.")
@JsonTypeName("creditReportHeader")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class CreditReportHeader {

  private String operatorReference;

  /**
   * Type of product granted to the Customer.
   */
  public enum ContractTypeEnum {
    AF("AF"),
    
    AG("AG"),
    
    AL("AL"),
    
    AP("AP"),
    
    AU("AU"),
    
    BD("BD"),
    
    BT("BT"),
    
    CC("CC"),
    
    CE("CE"),
    
    CF("CF"),
    
    CL("CL"),
    
    CO("CO"),
    
    CS("CS"),
    
    CT("CT"),
    
    DE("DE"),
    
    EQ("EQ"),
    
    FI("FI"),
    
    FT("FT"),
    
    HA("HA"),
    
    HE("HE"),
    
    HI("HI"),
    
    LR("LR"),
    
    LS("LS"),
    
    MI("MI"),
    
    OA("OA"),
    
    PA("PA"),
    
    PB("PB"),
    
    PG("PG"),
    
    PL("PL"),
    
    PN("PN"),
    
    PQ("PQ"),
    
    PR("PR"),
    
    PS("PS"),
    
    RC("RC"),
    
    RD("RD"),
    
    RE("RE"),
    
    RF("RF"),
    
    RN("RN"),
    
    RV("RV"),
    
    SC("SC"),
    
    SE("SE"),
    
    SG("SG"),
    
    SM("SM"),
    
    ST("ST"),
    
    TE("TE"),
    
    UK("UK"),
    
    US("US");

    private String value;

    ContractTypeEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ContractTypeEnum fromValue(String value) {
      for (ContractTypeEnum b : ContractTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private ContractTypeEnum contractType;

  /**
   * Code of the product required.
   */
  public enum RequiredProductEnum {
    _001("001"),
    
    _004("004"),
    
    _006("006"),
    
    _007("007"),
    
    _009("009"),
    
    _010("010"),
    
    _011("011"),
    
    _013("013"),
    
    _016("016"),
    
    _017("017"),
    
    _020("020"),
    
    _040("040"),
    
    _041("041"),
    
    _042("042"),
    
    _045("045"),
    
    _046("046"),
    
    _047("047"),
    
    _048("048"),
    
    _053("053"),
    
    _054("054"),
    
    _057("057"),
    
    _058("058"),
    
    _059("059"),
    
    _060("060"),
    
    _067("067"),
    
    _068("068"),
    
    _075("075"),
    
    _077("077"),
    
    _080("080"),
    
    _081("081"),
    
    _207("207");

    private String value;

    RequiredProductEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RequiredProductEnum fromValue(String value) {
      for (RequiredProductEnum b : RequiredProductEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private RequiredProductEnum requiredProduct;

  public CreditReportHeader() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public CreditReportHeader(String operatorReference, ContractTypeEnum contractType, RequiredProductEnum requiredProduct) {
    this.operatorReference = operatorReference;
    this.contractType = contractType;
    this.requiredProduct = requiredProduct;
  }

  public CreditReportHeader operatorReference(String operatorReference) {
    this.operatorReference = operatorReference;
    return this;
  }

  /**
   * Reference to identify the query.
   * @return operatorReference
  */
  @NotNull @Pattern(regexp = "^[A-Za-z0-9]+$") @Size(min = 1, max = 25) 
  @Schema(name = "operatorReference", example = "12345678", description = "Reference to identify the query.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("operatorReference")
  public String getOperatorReference() {
    return operatorReference;
  }

  public void setOperatorReference(String operatorReference) {
    this.operatorReference = operatorReference;
  }

  public CreditReportHeader contractType(ContractTypeEnum contractType) {
    this.contractType = contractType;
    return this;
  }

  /**
   * Type of product granted to the Customer.
   * @return contractType
  */
  @NotNull
  @Schema(name = "contractType", example = "CC", description = "Type of product granted to the Customer.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("contractType")
  public ContractTypeEnum getContractType() {
    return contractType;
  }

  public void setContractType(ContractTypeEnum contractType) {
    this.contractType = contractType;
  }

  public CreditReportHeader requiredProduct(RequiredProductEnum requiredProduct) {
    this.requiredProduct = requiredProduct;
    return this;
  }

  /**
   * Code of the product required.
   * @return requiredProduct
  */
  @NotNull
  @Schema(name = "requiredProduct", example = "047", description = "Code of the product required.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("requiredProduct")
  public RequiredProductEnum getRequiredProduct() {
    return requiredProduct;
  }

  public void setRequiredProduct(RequiredProductEnum requiredProduct) {
    this.requiredProduct = requiredProduct;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CreditReportHeader creditReportHeader = (CreditReportHeader) o;
    return Objects.equals(this.operatorReference, creditReportHeader.operatorReference) &&
        Objects.equals(this.contractType, creditReportHeader.contractType) &&
        Objects.equals(this.requiredProduct, creditReportHeader.requiredProduct);
  }

  @Override
  public int hashCode() {
    return Objects.hash(operatorReference, contractType, requiredProduct);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CreditReportHeader {\n");
    sb.append("    operatorReference: ").append(toIndentedString(operatorReference)).append("\n");
    sb.append("    contractType: ").append(toIndentedString(contractType)).append("\n");
    sb.append("    requiredProduct: ").append(toIndentedString(requiredProduct)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

