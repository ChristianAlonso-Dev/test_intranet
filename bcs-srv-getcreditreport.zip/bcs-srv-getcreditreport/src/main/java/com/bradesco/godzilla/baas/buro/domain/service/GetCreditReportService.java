package com.bradesco.godzilla.baas.buro.domain.service;

import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerAddress;
import com.bradesco.godzilla.baas.buro.domain.model.log.CreditReportLog;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReportResult;
import com.bradesco.godzilla.baas.buro.port.input.GetCreditReportQuery;
import com.bradesco.godzilla.baas.buro.port.input.IGetCreditReportUseCase;
import com.bradesco.godzilla.baas.buro.port.output.ICreditReportLogPort;
import com.bradesco.godzilla.baas.buro.port.output.IGetCreditReportPort;
import com.bradesco.godzilla.baas.buro.port.output.IProspectPort;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.BusinessErrorCode;
import java.time.LocalDateTime;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;

@Service
public class GetCreditReportService implements IGetCreditReportUseCase {

    private static final Pattern CUSTOMER_ID = Pattern.compile("^\\d{1,20}$");
    private static final Pattern STREET_NUMBER = Pattern.compile("\\d|\\bS/?N\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern KNOWN_ADDRESS = Pattern.compile("^DOMICILIO CONOCIDO$", Pattern.CASE_INSENSITIVE);

    private final IGetCreditReportPort getCreditReportPort;
    private final ICreditReportLogPort creditReportLogPort;
    private final IProspectPort prospectPort;

    public GetCreditReportService(
            IGetCreditReportPort getCreditReportPort,
            ICreditReportLogPort creditReportLogPort,
            IProspectPort prospectPort) {
        this.getCreditReportPort = getCreditReportPort;
        this.creditReportLogPort = creditReportLogPort;
        this.prospectPort = prospectPort;
    }

    @Override
    public CreditReport execute(GetCreditReportQuery query) {
        validateCustomerId(query.getCustomerId());
        query.getInquiry().addresses().forEach(this::validateStreet);
        validateRequestId(query.getRequestId());
        validateProspect(query.getCustomerId());

        LocalDateTime requestedAt = LocalDateTime.now();
        CreditReportResult result = getCreditReportPort.getCreditReport(query.getInquiry());
        RuntimeException error = result.failure();

        creditReportLogPort.save(CreditReportLog.builder()
                .requestId(query.getRequestId())
                .customerId(query.getCustomerId())
                .rfc(query.getInquiry().name().rfc())
                .requiredProduct(query.getInquiry().header().requiredProduct())
                .operatorReference(query.getInquiry().header().operatorReference())
                .channelId(query.getChannelId())
                .channelType(query.getChannelType())
                .geoLocation(query.getGeoLocation())
                .traceparent(query.getTraceparent())
                .providerRequest(result.providerRequest())
                .providerResponse(result.providerResponse())
                .requestedAt(requestedAt)
                .build());

        if (error != null) {
            throw error;
        }
        return result.creditReport();
    }

    private void validateCustomerId(String customerId) {
        if (customerId == null || customerId.isBlank()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8412_MANDATORY_PARAMETERS_MISSING);
        }
        if (!CUSTOMER_ID.matcher(customerId).matches()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    private void validateStreet(CustomerAddress address) {
        String street = address.street() == null ? "" : address.street().trim();
        if (!STREET_NUMBER.matcher(street).find() && !KNOWN_ADDRESS.matcher(street).matches()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8423_INVALID_DATA);
        }
    }

    private void validateRequestId(String requestId) {
        if (creditReportLogPort.existsByRequestId(requestId)) {
            throw new BusinessException(BusinessErrorCode.ERROR_892_REQUESTED_ALREADY_EXISTS);
        }
    }

    private void validateProspect(String prospectId) {
        if (!prospectPort.existsActiveProspect(prospectId)) {
            throw new BusinessException(BusinessErrorCode.ERROR_8044_NONEXISTENT_RESOURCE);
        }
    }
}
