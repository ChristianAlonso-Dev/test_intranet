package com.bradesco.godzilla.baas.buro.domain.model.report;

import java.util.List;

public record CreditReport(
        ReportHeader header,
        ReportName name,
        List<ReportAddress> addresses,
        List<ReportEmployment> employments,
        List<ReportAccount> accounts,
        List<ReportInquiry> inquiries,
        List<ReportSummary> reportSummary,
        List<HawkAlert> hawkAlertInquiry,
        List<HawkAlert> hawkAlertDatabase,
        ConsumerStatement consumerStatements,
        List<ReportScore> scores
) {
}
