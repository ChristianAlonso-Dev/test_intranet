package com.bradesco.godzilla.baas.buro.api.model;

import com.fasterxml.jackson.annotation.JsonValue;


import jakarta.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Identifies the channel through which the request is made.
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public enum ChannelId {
  
  WEB("web"),
  
  MOBILE("mobile"),
  
  SISTEMA_INTERNO("sistema_interno");

  private String value;

  ChannelId(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ChannelId fromValue(String value) {
    for (ChannelId b : ChannelId.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

