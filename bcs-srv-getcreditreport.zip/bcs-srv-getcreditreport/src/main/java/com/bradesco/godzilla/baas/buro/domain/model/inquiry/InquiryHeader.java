package com.bradesco.godzilla.baas.buro.domain.model.inquiry;

public record InquiryHeader(
        String operatorReference,
        String contractType,
        String requiredProduct
) {
}
