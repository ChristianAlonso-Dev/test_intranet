package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Customer account or credit.
 */

@Schema(name = "buroAccount", description = "Customer account or credit.")
@JsonTypeName("buroAccount")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroAccount {

  private String updateDate;

  private String disputedRecord;

  private String memberCode;

  private String grantorName;

  private String grantorPhoneNumber;

  private String accountNumber;

  private String responsibilityType;

  private String accountType;

  private String contractType;

  private String currencyCode;

  private String assetValuationAmount;

  private String paymentsNumber;

  private String paymentFrequency;

  private String paymentAmount;

  private String openingDate;

  private String lastPaymentDate;

  private String lastPurchaseDate;

  private String closingDate;

  private String reportDate;

  private String reportingMode;

  private String lastZeroBalanceDate;

  private String guarantee;

  private String maximumCredit;

  private String currentBalance;

  private String creditLimit;

  private String pastDueBalance;

  private String pastDuePaymentsNumber;

  private String paymentHistory;

  private String paymentHistoryMostRecentDate;

  private String paymentHistoryOldestDate;

  private String observationCode;

  private String totalReportedPayments;

  private String totalPaymentsMop2;

  private String totalPaymentsMop3;

  private String totalPaymentsMop4;

  private String totalPaymentsMop5;

  private String worstDelinquencyBalance;

  private String worstDelinquencyDate;

  private String restructuringStartDate;

  private String lastPaymentAmount;

  private String email;

  private String creditIdentifier;

  private String canIdentifier;

  private String canOpeningDate;

  private String canCancellationDate;

  private String canHistory;

  private String canHistoryMostRecentDate;

  private String canHistoryOldestDate;

  private String currentPaymentStatus;

  private String creditBureauIdentifier;

  private String worstDelinquencyMop;

  public BuroAccount updateDate(String updateDate) {
    this.updateDate = updateDate;
    return this;
  }

  /**
   * Last update date in the Buró de Crédito database (DDMMAAAA).
   * @return updateDate
  */
  @Size(max = 8) 
  @Schema(name = "updateDate", example = "05062022", description = "Last update date in the Buró de Crédito database (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("updateDate")
  public String getUpdateDate() {
    return updateDate;
  }

  public void setUpdateDate(String updateDate) {
    this.updateDate = updateDate;
  }

  public BuroAccount disputedRecord(String disputedRecord) {
    this.disputedRecord = disputedRecord;
    return this;
  }

  /**
   * Greater than 00 if the Customer disputed the account; 00 is always presented.
   * @return disputedRecord
  */
  @Size(max = 8) 
  @Schema(name = "disputedRecord", example = "00", description = "Greater than 00 if the Customer disputed the account; 00 is always presented.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("disputedRecord")
  public String getDisputedRecord() {
    return disputedRecord;
  }

  public void setDisputedRecord(String disputedRecord) {
    this.disputedRecord = disputedRecord;
  }

  public BuroAccount memberCode(String memberCode) {
    this.memberCode = memberCode;
    return this;
  }

  /**
   * Member code of the User, only if it is the same User that queries; otherwise blank spaces. Format: KOB (2) + User (4) + product/branch (4).
   * @return memberCode
  */
  @Size(max = 10) 
  @Schema(name = "memberCode", description = "Member code of the User, only if it is the same User that queries; otherwise blank spaces. Format: KOB (2) + User (4) + product/branch (4).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("memberCode")
  public String getMemberCode() {
    return memberCode;
  }

  public void setMemberCode(String memberCode) {
    this.memberCode = memberCode;
  }

  public BuroAccount grantorName(String grantorName) {
    this.grantorName = grantorName;
    return this;
  }

  /**
   * Name of the reporting User, or a generic name (e.g. BANCO) if it is a different User.
   * @return grantorName
  */
  @Size(max = 16) 
  @Schema(name = "grantorName", example = "BANCO", description = "Name of the reporting User, or a generic name (e.g. BANCO) if it is a different User.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("grantorName")
  public String getGrantorName() {
    return grantorName;
  }

  public void setGrantorName(String grantorName) {
    this.grantorName = grantorName;
  }

  public BuroAccount grantorPhoneNumber(String grantorPhoneNumber) {
    this.grantorPhoneNumber = grantorPhoneNumber;
    return this;
  }

  /**
   * Telephone of the reporting User. Area code + up to 8 digits.
   * @return grantorPhoneNumber
  */
  @Size(max = 11) 
  @Schema(name = "grantorPhoneNumber", description = "Telephone of the reporting User. Area code + up to 8 digits.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("grantorPhoneNumber")
  public String getGrantorPhoneNumber() {
    return grantorPhoneNumber;
  }

  public void setGrantorPhoneNumber(String grantorPhoneNumber) {
    this.grantorPhoneNumber = grantorPhoneNumber;
  }

  public BuroAccount accountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
    return this;
  }

  /**
   * Account or credit number.
   * @return accountNumber
  */
  @Size(max = 25) 
  @Schema(name = "accountNumber", description = "Account or credit number.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountNumber")
  public String getAccountNumber() {
    return accountNumber;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public BuroAccount responsibilityType(String responsibilityType) {
    this.responsibilityType = responsibilityType;
    return this;
  }

  /**
   * Responsibility type: A = Authorized User (Additional), I = Individual, J = Joint, C = Joint and Several Obligor.
   * @return responsibilityType
  */
  @Size(max = 1) 
  @Schema(name = "responsibilityType", example = "I", description = "Responsibility type: A = Authorized User (Additional), I = Individual, J = Joint, C = Joint and Several Obligor.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("responsibilityType")
  public String getResponsibilityType() {
    return responsibilityType;
  }

  public void setResponsibilityType(String responsibilityType) {
    this.responsibilityType = responsibilityType;
  }

  public BuroAccount accountType(String accountType) {
    this.accountType = accountType;
    return this;
  }

  /**
   * Account type: I = Fixed payments, M = Mortgage, O = No pre-established limit, R = Revolving, X = Reported in Dun & Bradstreet.
   * @return accountType
  */
  @Size(max = 1) 
  @Schema(name = "accountType", example = "I", description = "Account type: I = Fixed payments, M = Mortgage, O = No pre-established limit, R = Revolving, X = Reported in Dun & Bradstreet.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accountType")
  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public BuroAccount contractType(String contractType) {
    this.contractType = contractType;
    return this;
  }

  /**
   * Contract or product type (Annex 3).
   * @return contractType
  */
  @Size(max = 2) 
  @Schema(name = "contractType", example = "AF", description = "Contract or product type (Annex 3).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contractType")
  public String getContractType() {
    return contractType;
  }

  public void setContractType(String contractType) {
    this.contractType = contractType;
  }

  public BuroAccount currencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
    return this;
  }

  /**
   * Credit currency: MX = Mexican Pesos, N$ = Mexican Pesos, UD = Investment Units (UDI's), US = US Dollars.
   * @return currencyCode
  */
  @Size(max = 2) 
  @Schema(name = "currencyCode", example = "MX", description = "Credit currency: MX = Mexican Pesos, N$ = Mexican Pesos, UD = Investment Units (UDI's), US = US Dollars.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currencyCode")
  public String getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
  }

  public BuroAccount assetValuationAmount(String assetValuationAmount) {
    this.assetValuationAmount = assetValuationAmount;
    return this;
  }

  /**
   * Asset valuation amount (fixed payments or mortgage).
   * @return assetValuationAmount
  */
  @Size(max = 9) 
  @Schema(name = "assetValuationAmount", description = "Asset valuation amount (fixed payments or mortgage).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("assetValuationAmount")
  public String getAssetValuationAmount() {
    return assetValuationAmount;
  }

  public void setAssetValuationAmount(String assetValuationAmount) {
    this.assetValuationAmount = assetValuationAmount;
  }

  public BuroAccount paymentsNumber(String paymentsNumber) {
    this.paymentsNumber = paymentsNumber;
    return this;
  }

  /**
   * Total number of payments agreed (fixed payments or mortgage).
   * @return paymentsNumber
  */
  @Size(max = 4) 
  @Schema(name = "paymentsNumber", example = "4562", description = "Total number of payments agreed (fixed payments or mortgage).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paymentsNumber")
  public String getPaymentsNumber() {
    return paymentsNumber;
  }

  public void setPaymentsNumber(String paymentsNumber) {
    this.paymentsNumber = paymentsNumber;
  }

  public BuroAccount paymentFrequency(String paymentFrequency) {
    this.paymentFrequency = paymentFrequency;
    return this;
  }

  /**
   * Payment frequency. I/M: B = Bimonthly, D = Daily, H = Semi-annual, K = Every fourteen days, M = Monthly, P = Salary deduction, Q = Quarterly, S = Semi-monthly, V = Variable, W = Weekly, Y = Annual. R/O: Z = Minimum payment.
   * @return paymentFrequency
  */
  @Size(max = 1) 
  @Schema(name = "paymentFrequency", example = "M", description = "Payment frequency. I/M: B = Bimonthly, D = Daily, H = Semi-annual, K = Every fourteen days, M = Monthly, P = Salary deduction, Q = Quarterly, S = Semi-monthly, V = Variable, W = Weekly, Y = Annual. R/O: Z = Minimum payment.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paymentFrequency")
  public String getPaymentFrequency() {
    return paymentFrequency;
  }

  public void setPaymentFrequency(String paymentFrequency) {
    this.paymentFrequency = paymentFrequency;
  }

  public BuroAccount paymentAmount(String paymentAmount) {
    this.paymentAmount = paymentAmount;
    return this;
  }

  /**
   * Amount to pay in the next monthly period. The plus symbol (+) may be shown at the end of the amount.
   * @return paymentAmount
  */
  @Size(max = 9) 
  @Schema(name = "paymentAmount", example = "159", description = "Amount to pay in the next monthly period. The plus symbol (+) may be shown at the end of the amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paymentAmount")
  public String getPaymentAmount() {
    return paymentAmount;
  }

  public void setPaymentAmount(String paymentAmount) {
    this.paymentAmount = paymentAmount;
  }

  public BuroAccount openingDate(String openingDate) {
    this.openingDate = openingDate;
    return this;
  }

  /**
   * Account opening date (DDMMAAAA).
   * @return openingDate
  */
  @Size(max = 8) 
  @Schema(name = "openingDate", example = "05052020", description = "Account opening date (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("openingDate")
  public String getOpeningDate() {
    return openingDate;
  }

  public void setOpeningDate(String openingDate) {
    this.openingDate = openingDate;
  }

  public BuroAccount lastPaymentDate(String lastPaymentDate) {
    this.lastPaymentDate = lastPaymentDate;
    return this;
  }

  /**
   * Last payment date (DDMMAAAA).
   * @return lastPaymentDate
  */
  @Size(max = 8) 
  @Schema(name = "lastPaymentDate", example = "07072020", description = "Last payment date (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastPaymentDate")
  public String getLastPaymentDate() {
    return lastPaymentDate;
  }

  public void setLastPaymentDate(String lastPaymentDate) {
    this.lastPaymentDate = lastPaymentDate;
  }

  public BuroAccount lastPurchaseDate(String lastPurchaseDate) {
    this.lastPurchaseDate = lastPurchaseDate;
    return this;
  }

  /**
   * Last purchase or cash withdrawal date (DDMMAAAA).
   * @return lastPurchaseDate
  */
  @Size(max = 8) 
  @Schema(name = "lastPurchaseDate", example = "06062020", description = "Last purchase or cash withdrawal date (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastPurchaseDate")
  public String getLastPurchaseDate() {
    return lastPurchaseDate;
  }

  public void setLastPurchaseDate(String lastPurchaseDate) {
    this.lastPurchaseDate = lastPurchaseDate;
  }

  public BuroAccount closingDate(String closingDate) {
    this.closingDate = closingDate;
    return this;
  }

  /**
   * Account closing date (DDMMAAAA).
   * @return closingDate
  */
  @Size(max = 8) 
  @Schema(name = "closingDate", example = "26082021", description = "Account closing date (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("closingDate")
  public String getClosingDate() {
    return closingDate;
  }

  public void setClosingDate(String closingDate) {
    this.closingDate = closingDate;
  }

  public BuroAccount reportDate(String reportDate) {
    this.reportDate = reportDate;
    return this;
  }

  /**
   * Extraction date of the User's information reported to Buró de Crédito (DDMMAAAA).
   * @return reportDate
  */
  @Size(max = 8) 
  @Schema(name = "reportDate", example = "05062022", description = "Extraction date of the User's information reported to Buró de Crédito (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reportDate")
  public String getReportDate() {
    return reportDate;
  }

  public void setReportDate(String reportDate) {
    this.reportDate = reportDate;
  }

  public BuroAccount reportingMode(String reportingMode) {
    this.reportingMode = reportingMode;
    return this;
  }

  /**
   * Reporting mode: A = Automated, M = Manual, C = Confin, P = Special process.
   * @return reportingMode
  */
  @Size(max = 1) 
  @Schema(name = "reportingMode", example = "M", description = "Reporting mode: A = Automated, M = Manual, C = Confin, P = Special process.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reportingMode")
  public String getReportingMode() {
    return reportingMode;
  }

  public void setReportingMode(String reportingMode) {
    this.reportingMode = reportingMode;
  }

  public BuroAccount lastZeroBalanceDate(String lastZeroBalanceDate) {
    this.lastZeroBalanceDate = lastZeroBalanceDate;
    return this;
  }

  /**
   * Last date with zero balance (DDMMAAAA).
   * @return lastZeroBalanceDate
  */
  @Size(max = 8) 
  @Schema(name = "lastZeroBalanceDate", description = "Last date with zero balance (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastZeroBalanceDate")
  public String getLastZeroBalanceDate() {
    return lastZeroBalanceDate;
  }

  public void setLastZeroBalanceDate(String lastZeroBalanceDate) {
    this.lastZeroBalanceDate = lastZeroBalanceDate;
  }

  public BuroAccount guarantee(String guarantee) {
    this.guarantee = guarantee;
    return this;
  }

  /**
   * Description of the guarantee (mortgage or fixed payments).
   * @return guarantee
  */
  @Size(max = 40) 
  @Schema(name = "guarantee", description = "Description of the guarantee (mortgage or fixed payments).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("guarantee")
  public String getGuarantee() {
    return guarantee;
  }

  public void setGuarantee(String guarantee) {
    this.guarantee = guarantee;
  }

  public BuroAccount maximumCredit(String maximumCredit) {
    this.maximumCredit = maximumCredit;
    return this;
  }

  /**
   * Maximum amount used. The plus symbol (+) may be shown at the end of the amount.
   * @return maximumCredit
  */
  @Size(max = 9) 
  @Schema(name = "maximumCredit", example = "40000", description = "Maximum amount used. The plus symbol (+) may be shown at the end of the amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("maximumCredit")
  public String getMaximumCredit() {
    return maximumCredit;
  }

  public void setMaximumCredit(String maximumCredit) {
    this.maximumCredit = maximumCredit;
  }

  public BuroAccount currentBalance(String currentBalance) {
    this.currentBalance = currentBalance;
    return this;
  }

  /**
   * Total amount of the debt that remains to be paid.
   * @return currentBalance
  */
  @Size(max = 10) 
  @Schema(name = "currentBalance", example = "500+", description = "Total amount of the debt that remains to be paid.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentBalance")
  public String getCurrentBalance() {
    return currentBalance;
  }

  public void setCurrentBalance(String currentBalance) {
    this.currentBalance = currentBalance;
  }

  public BuroAccount creditLimit(String creditLimit) {
    this.creditLimit = creditLimit;
    return this;
  }

  /**
   * Credit limit (revolving accounts).
   * @return creditLimit
  */
  @Size(max = 9) 
  @Schema(name = "creditLimit", example = "10000", description = "Credit limit (revolving accounts).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("creditLimit")
  public String getCreditLimit() {
    return creditLimit;
  }

  public void setCreditLimit(String creditLimit) {
    this.creditLimit = creditLimit;
  }

  public BuroAccount pastDueBalance(String pastDueBalance) {
    this.pastDueBalance = pastDueBalance;
    return this;
  }

  /**
   * Past due balance at the reported period.
   * @return pastDueBalance
  */
  @Size(max = 9) 
  @Schema(name = "pastDueBalance", example = "0", description = "Past due balance at the reported period.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("pastDueBalance")
  public String getPastDueBalance() {
    return pastDueBalance;
  }

  public void setPastDueBalance(String pastDueBalance) {
    this.pastDueBalance = pastDueBalance;
  }

  public BuroAccount pastDuePaymentsNumber(String pastDuePaymentsNumber) {
    this.pastDuePaymentsNumber = pastDuePaymentsNumber;
    return this;
  }

  /**
   * Number of past due payments.
   * @return pastDuePaymentsNumber
  */
  @Size(max = 4) 
  @Schema(name = "pastDuePaymentsNumber", example = "3", description = "Number of past due payments.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("pastDuePaymentsNumber")
  public String getPastDuePaymentsNumber() {
    return pastDuePaymentsNumber;
  }

  public void setPastDuePaymentsNumber(String pastDuePaymentsNumber) {
    this.pastDuePaymentsNumber = pastDuePaymentsNumber;
  }

  public BuroAccount paymentHistory(String paymentHistory) {
    this.paymentHistory = paymentHistory;
    return this;
  }

  /**
   * Payment history of the last 24 months (Annex 1, MOP).
   * @return paymentHistory
  */
  @Size(max = 24) 
  @Schema(name = "paymentHistory", example = "XXXXXX9XXXXXXX99", description = "Payment history of the last 24 months (Annex 1, MOP).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paymentHistory")
  public String getPaymentHistory() {
    return paymentHistory;
  }

  public void setPaymentHistory(String paymentHistory) {
    this.paymentHistory = paymentHistory;
  }

  public BuroAccount paymentHistoryMostRecentDate(String paymentHistoryMostRecentDate) {
    this.paymentHistoryMostRecentDate = paymentHistoryMostRecentDate;
    return this;
  }

  /**
   * Most recent date of the payment history.
   * @return paymentHistoryMostRecentDate
  */
  @Size(max = 8) 
  @Schema(name = "paymentHistoryMostRecentDate", example = "05052022", description = "Most recent date of the payment history.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paymentHistoryMostRecentDate")
  public String getPaymentHistoryMostRecentDate() {
    return paymentHistoryMostRecentDate;
  }

  public void setPaymentHistoryMostRecentDate(String paymentHistoryMostRecentDate) {
    this.paymentHistoryMostRecentDate = paymentHistoryMostRecentDate;
  }

  public BuroAccount paymentHistoryOldestDate(String paymentHistoryOldestDate) {
    this.paymentHistoryOldestDate = paymentHistoryOldestDate;
    return this;
  }

  /**
   * Start date of the payment history (up to 72 months).
   * @return paymentHistoryOldestDate
  */
  @Size(max = 8) 
  @Schema(name = "paymentHistoryOldestDate", example = "05022021", description = "Start date of the payment history (up to 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paymentHistoryOldestDate")
  public String getPaymentHistoryOldestDate() {
    return paymentHistoryOldestDate;
  }

  public void setPaymentHistoryOldestDate(String paymentHistoryOldestDate) {
    this.paymentHistoryOldestDate = paymentHistoryOldestDate;
  }

  public BuroAccount observationCode(String observationCode) {
    this.observationCode = observationCode;
    return this;
  }

  /**
   * Observation code of the account (Annex 9).
   * @return observationCode
  */
  @Size(max = 2) 
  @Schema(name = "observationCode", example = "LG", description = "Observation code of the account (Annex 9).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("observationCode")
  public String getObservationCode() {
    return observationCode;
  }

  public void setObservationCode(String observationCode) {
    this.observationCode = observationCode;
  }

  public BuroAccount totalReportedPayments(String totalReportedPayments) {
    this.totalReportedPayments = totalReportedPayments;
    return this;
  }

  /**
   * Statistic of the Customer's credit behavior.
   * @return totalReportedPayments
  */
  @Size(max = 3) 
  @Schema(name = "totalReportedPayments", example = "016", description = "Statistic of the Customer's credit behavior.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalReportedPayments")
  public String getTotalReportedPayments() {
    return totalReportedPayments;
  }

  public void setTotalReportedPayments(String totalReportedPayments) {
    this.totalReportedPayments = totalReportedPayments;
  }

  public BuroAccount totalPaymentsMop2(String totalPaymentsMop2) {
    this.totalPaymentsMop2 = totalPaymentsMop2;
    return this;
  }

  /**
   * Times with MOP = 02 (maximum 72 months).
   * @return totalPaymentsMop2
  */
  @Size(max = 2) 
  @Schema(name = "totalPaymentsMop2", example = "01", description = "Times with MOP = 02 (maximum 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalPaymentsMop2")
  public String getTotalPaymentsMop2() {
    return totalPaymentsMop2;
  }

  public void setTotalPaymentsMop2(String totalPaymentsMop2) {
    this.totalPaymentsMop2 = totalPaymentsMop2;
  }

  public BuroAccount totalPaymentsMop3(String totalPaymentsMop3) {
    this.totalPaymentsMop3 = totalPaymentsMop3;
    return this;
  }

  /**
   * Times with MOP = 03 (maximum 72 months).
   * @return totalPaymentsMop3
  */
  @Size(max = 2) 
  @Schema(name = "totalPaymentsMop3", description = "Times with MOP = 03 (maximum 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalPaymentsMop3")
  public String getTotalPaymentsMop3() {
    return totalPaymentsMop3;
  }

  public void setTotalPaymentsMop3(String totalPaymentsMop3) {
    this.totalPaymentsMop3 = totalPaymentsMop3;
  }

  public BuroAccount totalPaymentsMop4(String totalPaymentsMop4) {
    this.totalPaymentsMop4 = totalPaymentsMop4;
    return this;
  }

  /**
   * Times with MOP = 04 (maximum 72 months).
   * @return totalPaymentsMop4
  */
  @Size(max = 2) 
  @Schema(name = "totalPaymentsMop4", description = "Times with MOP = 04 (maximum 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalPaymentsMop4")
  public String getTotalPaymentsMop4() {
    return totalPaymentsMop4;
  }

  public void setTotalPaymentsMop4(String totalPaymentsMop4) {
    this.totalPaymentsMop4 = totalPaymentsMop4;
  }

  public BuroAccount totalPaymentsMop5(String totalPaymentsMop5) {
    this.totalPaymentsMop5 = totalPaymentsMop5;
    return this;
  }

  /**
   * Times with MOP = 05 or greater (maximum 72 months).
   * @return totalPaymentsMop5
  */
  @Size(max = 2) 
  @Schema(name = "totalPaymentsMop5", example = "03", description = "Times with MOP = 05 or greater (maximum 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalPaymentsMop5")
  public String getTotalPaymentsMop5() {
    return totalPaymentsMop5;
  }

  public void setTotalPaymentsMop5(String totalPaymentsMop5) {
    this.totalPaymentsMop5 = totalPaymentsMop5;
  }

  public BuroAccount worstDelinquencyBalance(String worstDelinquencyBalance) {
    this.worstDelinquencyBalance = worstDelinquencyBalance;
    return this;
  }

  /**
   * Balance at the highest historical delinquency (maximum 72 months).
   * @return worstDelinquencyBalance
  */
  @Size(max = 9) 
  @Schema(name = "worstDelinquencyBalance", example = "500", description = "Balance at the highest historical delinquency (maximum 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("worstDelinquencyBalance")
  public String getWorstDelinquencyBalance() {
    return worstDelinquencyBalance;
  }

  public void setWorstDelinquencyBalance(String worstDelinquencyBalance) {
    this.worstDelinquencyBalance = worstDelinquencyBalance;
  }

  public BuroAccount worstDelinquencyDate(String worstDelinquencyDate) {
    this.worstDelinquencyDate = worstDelinquencyDate;
    return this;
  }

  /**
   * Date of the highest historical delinquency (maximum 72 months).
   * @return worstDelinquencyDate
  */
  @Size(max = 8) 
  @Schema(name = "worstDelinquencyDate", example = "02062022", description = "Date of the highest historical delinquency (maximum 72 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("worstDelinquencyDate")
  public String getWorstDelinquencyDate() {
    return worstDelinquencyDate;
  }

  public void setWorstDelinquencyDate(String worstDelinquencyDate) {
    this.worstDelinquencyDate = worstDelinquencyDate;
  }

  public BuroAccount restructuringStartDate(String restructuringStartDate) {
    this.restructuringStartDate = restructuringStartDate;
    return this;
  }

  /**
   * Date of the first observation code RA, RN or RV (restructuring).
   * @return restructuringStartDate
  */
  @Size(max = 8) 
  @Schema(name = "restructuringStartDate", description = "Date of the first observation code RA, RN or RV (restructuring).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("restructuringStartDate")
  public String getRestructuringStartDate() {
    return restructuringStartDate;
  }

  public void setRestructuringStartDate(String restructuringStartDate) {
    this.restructuringStartDate = restructuringStartDate;
  }

  public BuroAccount lastPaymentAmount(String lastPaymentAmount) {
    this.lastPaymentAmount = lastPaymentAmount;
    return this;
  }

  /**
   * Last payment amount.
   * @return lastPaymentAmount
  */
  @Size(max = 9) 
  @Schema(name = "lastPaymentAmount", example = "100", description = "Last payment amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastPaymentAmount")
  public String getLastPaymentAmount() {
    return lastPaymentAmount;
  }

  public void setLastPaymentAmount(String lastPaymentAmount) {
    this.lastPaymentAmount = lastPaymentAmount;
  }

  public BuroAccount email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Email associated with the credit, as reported by the granting institution.
   * @return email
  */
  @Size(max = 99) 
  @Schema(name = "email", example = "PRUEBACORREO@GMAIL.COM", description = "Email associated with the credit, as reported by the granting institution.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public BuroAccount creditIdentifier(String creditIdentifier) {
    this.creditIdentifier = creditIdentifier;
    return this;
  }

  /**
   * Y in position 1: grantor reports fewer than 5,000 credits. Y in position 2: file with suspicious information.
   * @return creditIdentifier
  */
  @Size(max = 20) 
  @Schema(name = "creditIdentifier", example = "YY", description = "Y in position 1: grantor reports fewer than 5,000 credits. Y in position 2: file with suspicious information.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("creditIdentifier")
  public String getCreditIdentifier() {
    return creditIdentifier;
  }

  public void setCreditIdentifier(String creditIdentifier) {
    this.creditIdentifier = creditIdentifier;
  }

  public BuroAccount canIdentifier(String canIdentifier) {
    this.canIdentifier = canIdentifier;
    return this;
  }

  /**
   * Payroll-associated credit (CAN). Positions 1-2 status (01 Active, 02 Cancelled), 3-4 origin priority, 5-6 current priority, 7-8 future use.
   * @return canIdentifier
  */
  @Size(max = 8) 
  @Schema(name = "canIdentifier", example = "01010100", description = "Payroll-associated credit (CAN). Positions 1-2 status (01 Active, 02 Cancelled), 3-4 origin priority, 5-6 current priority, 7-8 future use.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("canIdentifier")
  public String getCanIdentifier() {
    return canIdentifier;
  }

  public void setCanIdentifier(String canIdentifier) {
    this.canIdentifier = canIdentifier;
  }

  public BuroAccount canOpeningDate(String canOpeningDate) {
    this.canOpeningDate = canOpeningDate;
    return this;
  }

  /**
   * Most recent CAN opening date.
   * @return canOpeningDate
  */
  @Size(max = 8) 
  @Schema(name = "canOpeningDate", example = "01122021", description = "Most recent CAN opening date.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("canOpeningDate")
  public String getCanOpeningDate() {
    return canOpeningDate;
  }

  public void setCanOpeningDate(String canOpeningDate) {
    this.canOpeningDate = canOpeningDate;
  }

  public BuroAccount canCancellationDate(String canCancellationDate) {
    this.canCancellationDate = canCancellationDate;
    return this;
  }

  /**
   * Most recent CAN cancellation date.
   * @return canCancellationDate
  */
  @Size(max = 8) 
  @Schema(name = "canCancellationDate", example = "06062020", description = "Most recent CAN cancellation date.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("canCancellationDate")
  public String getCanCancellationDate() {
    return canCancellationDate;
  }

  public void setCanCancellationDate(String canCancellationDate) {
    this.canCancellationDate = canCancellationDate;
  }

  public BuroAccount canHistory(String canHistory) {
    this.canHistory = canHistory;
    return this;
  }

  /**
   * CAN history of the last 36 months: 1 = Active, 2 = Inactive, - = Not reported.
   * @return canHistory
  */
  @Size(max = 36) 
  @Schema(name = "canHistory", example = "1111", description = "CAN history of the last 36 months: 1 = Active, 2 = Inactive, - = Not reported.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("canHistory")
  public String getCanHistory() {
    return canHistory;
  }

  public void setCanHistory(String canHistory) {
    this.canHistory = canHistory;
  }

  public BuroAccount canHistoryMostRecentDate(String canHistoryMostRecentDate) {
    this.canHistoryMostRecentDate = canHistoryMostRecentDate;
    return this;
  }

  /**
   * Most recent date of the CAN history.
   * @return canHistoryMostRecentDate
  */
  @Size(max = 8) 
  @Schema(name = "canHistoryMostRecentDate", example = "01052020", description = "Most recent date of the CAN history.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("canHistoryMostRecentDate")
  public String getCanHistoryMostRecentDate() {
    return canHistoryMostRecentDate;
  }

  public void setCanHistoryMostRecentDate(String canHistoryMostRecentDate) {
    this.canHistoryMostRecentDate = canHistoryMostRecentDate;
  }

  public BuroAccount canHistoryOldestDate(String canHistoryOldestDate) {
    this.canHistoryOldestDate = canHistoryOldestDate;
    return this;
  }

  /**
   * Start date of the CAN history (maximum 36 months).
   * @return canHistoryOldestDate
  */
  @Size(max = 8) 
  @Schema(name = "canHistoryOldestDate", example = "01022020", description = "Start date of the CAN history (maximum 36 months).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("canHistoryOldestDate")
  public String getCanHistoryOldestDate() {
    return canHistoryOldestDate;
  }

  public void setCanHistoryOldestDate(String canHistoryOldestDate) {
    this.canHistoryOldestDate = canHistoryOldestDate;
  }

  public BuroAccount currentPaymentStatus(String currentPaymentStatus) {
    this.currentPaymentStatus = currentPaymentStatus;
    return this;
  }

  /**
   * Current payment punctuality classification (MOP, Annex 1).
   * @return currentPaymentStatus
  */
  @Size(max = 2) 
  @Schema(name = "currentPaymentStatus", example = "99", description = "Current payment punctuality classification (MOP, Annex 1).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentPaymentStatus")
  public String getCurrentPaymentStatus() {
    return currentPaymentStatus;
  }

  public void setCurrentPaymentStatus(String currentPaymentStatus) {
    this.currentPaymentStatus = currentPaymentStatus;
  }

  public BuroAccount creditBureauIdentifier(String creditBureauIdentifier) {
    this.creditBureauIdentifier = creditBureauIdentifier;
    return this;
  }

  /**
   * Credit Information Company: 0 = Buró de Crédito, 1 = Círculo de Crédito, 2 = Dun & Bradstreet.
   * @return creditBureauIdentifier
  */
  @Size(max = 11) 
  @Schema(name = "creditBureauIdentifier", example = "0", description = "Credit Information Company: 0 = Buró de Crédito, 1 = Círculo de Crédito, 2 = Dun & Bradstreet.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("creditBureauIdentifier")
  public String getCreditBureauIdentifier() {
    return creditBureauIdentifier;
  }

  public void setCreditBureauIdentifier(String creditBureauIdentifier) {
    this.creditBureauIdentifier = creditBureauIdentifier;
  }

  public BuroAccount worstDelinquencyMop(String worstDelinquencyMop) {
    this.worstDelinquencyMop = worstDelinquencyMop;
    return this;
  }

  /**
   * Worst MOP reported in the credit history; delinquency starts at MOP 02.
   * @return worstDelinquencyMop
  */
  @Size(max = 2) 
  @Schema(name = "worstDelinquencyMop", example = "99", description = "Worst MOP reported in the credit history; delinquency starts at MOP 02.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("worstDelinquencyMop")
  public String getWorstDelinquencyMop() {
    return worstDelinquencyMop;
  }

  public void setWorstDelinquencyMop(String worstDelinquencyMop) {
    this.worstDelinquencyMop = worstDelinquencyMop;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroAccount buroAccount = (BuroAccount) o;
    return Objects.equals(this.updateDate, buroAccount.updateDate) &&
        Objects.equals(this.disputedRecord, buroAccount.disputedRecord) &&
        Objects.equals(this.memberCode, buroAccount.memberCode) &&
        Objects.equals(this.grantorName, buroAccount.grantorName) &&
        Objects.equals(this.grantorPhoneNumber, buroAccount.grantorPhoneNumber) &&
        Objects.equals(this.accountNumber, buroAccount.accountNumber) &&
        Objects.equals(this.responsibilityType, buroAccount.responsibilityType) &&
        Objects.equals(this.accountType, buroAccount.accountType) &&
        Objects.equals(this.contractType, buroAccount.contractType) &&
        Objects.equals(this.currencyCode, buroAccount.currencyCode) &&
        Objects.equals(this.assetValuationAmount, buroAccount.assetValuationAmount) &&
        Objects.equals(this.paymentsNumber, buroAccount.paymentsNumber) &&
        Objects.equals(this.paymentFrequency, buroAccount.paymentFrequency) &&
        Objects.equals(this.paymentAmount, buroAccount.paymentAmount) &&
        Objects.equals(this.openingDate, buroAccount.openingDate) &&
        Objects.equals(this.lastPaymentDate, buroAccount.lastPaymentDate) &&
        Objects.equals(this.lastPurchaseDate, buroAccount.lastPurchaseDate) &&
        Objects.equals(this.closingDate, buroAccount.closingDate) &&
        Objects.equals(this.reportDate, buroAccount.reportDate) &&
        Objects.equals(this.reportingMode, buroAccount.reportingMode) &&
        Objects.equals(this.lastZeroBalanceDate, buroAccount.lastZeroBalanceDate) &&
        Objects.equals(this.guarantee, buroAccount.guarantee) &&
        Objects.equals(this.maximumCredit, buroAccount.maximumCredit) &&
        Objects.equals(this.currentBalance, buroAccount.currentBalance) &&
        Objects.equals(this.creditLimit, buroAccount.creditLimit) &&
        Objects.equals(this.pastDueBalance, buroAccount.pastDueBalance) &&
        Objects.equals(this.pastDuePaymentsNumber, buroAccount.pastDuePaymentsNumber) &&
        Objects.equals(this.paymentHistory, buroAccount.paymentHistory) &&
        Objects.equals(this.paymentHistoryMostRecentDate, buroAccount.paymentHistoryMostRecentDate) &&
        Objects.equals(this.paymentHistoryOldestDate, buroAccount.paymentHistoryOldestDate) &&
        Objects.equals(this.observationCode, buroAccount.observationCode) &&
        Objects.equals(this.totalReportedPayments, buroAccount.totalReportedPayments) &&
        Objects.equals(this.totalPaymentsMop2, buroAccount.totalPaymentsMop2) &&
        Objects.equals(this.totalPaymentsMop3, buroAccount.totalPaymentsMop3) &&
        Objects.equals(this.totalPaymentsMop4, buroAccount.totalPaymentsMop4) &&
        Objects.equals(this.totalPaymentsMop5, buroAccount.totalPaymentsMop5) &&
        Objects.equals(this.worstDelinquencyBalance, buroAccount.worstDelinquencyBalance) &&
        Objects.equals(this.worstDelinquencyDate, buroAccount.worstDelinquencyDate) &&
        Objects.equals(this.restructuringStartDate, buroAccount.restructuringStartDate) &&
        Objects.equals(this.lastPaymentAmount, buroAccount.lastPaymentAmount) &&
        Objects.equals(this.email, buroAccount.email) &&
        Objects.equals(this.creditIdentifier, buroAccount.creditIdentifier) &&
        Objects.equals(this.canIdentifier, buroAccount.canIdentifier) &&
        Objects.equals(this.canOpeningDate, buroAccount.canOpeningDate) &&
        Objects.equals(this.canCancellationDate, buroAccount.canCancellationDate) &&
        Objects.equals(this.canHistory, buroAccount.canHistory) &&
        Objects.equals(this.canHistoryMostRecentDate, buroAccount.canHistoryMostRecentDate) &&
        Objects.equals(this.canHistoryOldestDate, buroAccount.canHistoryOldestDate) &&
        Objects.equals(this.currentPaymentStatus, buroAccount.currentPaymentStatus) &&
        Objects.equals(this.creditBureauIdentifier, buroAccount.creditBureauIdentifier) &&
        Objects.equals(this.worstDelinquencyMop, buroAccount.worstDelinquencyMop);
  }

  @Override
  public int hashCode() {
    return Objects.hash(updateDate, disputedRecord, memberCode, grantorName, grantorPhoneNumber, accountNumber, responsibilityType, accountType, contractType, currencyCode, assetValuationAmount, paymentsNumber, paymentFrequency, paymentAmount, openingDate, lastPaymentDate, lastPurchaseDate, closingDate, reportDate, reportingMode, lastZeroBalanceDate, guarantee, maximumCredit, currentBalance, creditLimit, pastDueBalance, pastDuePaymentsNumber, paymentHistory, paymentHistoryMostRecentDate, paymentHistoryOldestDate, observationCode, totalReportedPayments, totalPaymentsMop2, totalPaymentsMop3, totalPaymentsMop4, totalPaymentsMop5, worstDelinquencyBalance, worstDelinquencyDate, restructuringStartDate, lastPaymentAmount, email, creditIdentifier, canIdentifier, canOpeningDate, canCancellationDate, canHistory, canHistoryMostRecentDate, canHistoryOldestDate, currentPaymentStatus, creditBureauIdentifier, worstDelinquencyMop);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroAccount {\n");
    sb.append("    updateDate: ").append(toIndentedString(updateDate)).append("\n");
    sb.append("    disputedRecord: ").append(toIndentedString(disputedRecord)).append("\n");
    sb.append("    memberCode: ").append(toIndentedString(memberCode)).append("\n");
    sb.append("    grantorName: ").append(toIndentedString(grantorName)).append("\n");
    sb.append("    grantorPhoneNumber: ").append(toIndentedString(grantorPhoneNumber)).append("\n");
    sb.append("    accountNumber: ").append(toIndentedString(accountNumber)).append("\n");
    sb.append("    responsibilityType: ").append(toIndentedString(responsibilityType)).append("\n");
    sb.append("    accountType: ").append(toIndentedString(accountType)).append("\n");
    sb.append("    contractType: ").append(toIndentedString(contractType)).append("\n");
    sb.append("    currencyCode: ").append(toIndentedString(currencyCode)).append("\n");
    sb.append("    assetValuationAmount: ").append(toIndentedString(assetValuationAmount)).append("\n");
    sb.append("    paymentsNumber: ").append(toIndentedString(paymentsNumber)).append("\n");
    sb.append("    paymentFrequency: ").append(toIndentedString(paymentFrequency)).append("\n");
    sb.append("    paymentAmount: ").append(toIndentedString(paymentAmount)).append("\n");
    sb.append("    openingDate: ").append(toIndentedString(openingDate)).append("\n");
    sb.append("    lastPaymentDate: ").append(toIndentedString(lastPaymentDate)).append("\n");
    sb.append("    lastPurchaseDate: ").append(toIndentedString(lastPurchaseDate)).append("\n");
    sb.append("    closingDate: ").append(toIndentedString(closingDate)).append("\n");
    sb.append("    reportDate: ").append(toIndentedString(reportDate)).append("\n");
    sb.append("    reportingMode: ").append(toIndentedString(reportingMode)).append("\n");
    sb.append("    lastZeroBalanceDate: ").append(toIndentedString(lastZeroBalanceDate)).append("\n");
    sb.append("    guarantee: ").append(toIndentedString(guarantee)).append("\n");
    sb.append("    maximumCredit: ").append(toIndentedString(maximumCredit)).append("\n");
    sb.append("    currentBalance: ").append(toIndentedString(currentBalance)).append("\n");
    sb.append("    creditLimit: ").append(toIndentedString(creditLimit)).append("\n");
    sb.append("    pastDueBalance: ").append(toIndentedString(pastDueBalance)).append("\n");
    sb.append("    pastDuePaymentsNumber: ").append(toIndentedString(pastDuePaymentsNumber)).append("\n");
    sb.append("    paymentHistory: ").append(toIndentedString(paymentHistory)).append("\n");
    sb.append("    paymentHistoryMostRecentDate: ").append(toIndentedString(paymentHistoryMostRecentDate)).append("\n");
    sb.append("    paymentHistoryOldestDate: ").append(toIndentedString(paymentHistoryOldestDate)).append("\n");
    sb.append("    observationCode: ").append(toIndentedString(observationCode)).append("\n");
    sb.append("    totalReportedPayments: ").append(toIndentedString(totalReportedPayments)).append("\n");
    sb.append("    totalPaymentsMop2: ").append(toIndentedString(totalPaymentsMop2)).append("\n");
    sb.append("    totalPaymentsMop3: ").append(toIndentedString(totalPaymentsMop3)).append("\n");
    sb.append("    totalPaymentsMop4: ").append(toIndentedString(totalPaymentsMop4)).append("\n");
    sb.append("    totalPaymentsMop5: ").append(toIndentedString(totalPaymentsMop5)).append("\n");
    sb.append("    worstDelinquencyBalance: ").append(toIndentedString(worstDelinquencyBalance)).append("\n");
    sb.append("    worstDelinquencyDate: ").append(toIndentedString(worstDelinquencyDate)).append("\n");
    sb.append("    restructuringStartDate: ").append(toIndentedString(restructuringStartDate)).append("\n");
    sb.append("    lastPaymentAmount: ").append(toIndentedString(lastPaymentAmount)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    creditIdentifier: ").append(toIndentedString(creditIdentifier)).append("\n");
    sb.append("    canIdentifier: ").append(toIndentedString(canIdentifier)).append("\n");
    sb.append("    canOpeningDate: ").append(toIndentedString(canOpeningDate)).append("\n");
    sb.append("    canCancellationDate: ").append(toIndentedString(canCancellationDate)).append("\n");
    sb.append("    canHistory: ").append(toIndentedString(canHistory)).append("\n");
    sb.append("    canHistoryMostRecentDate: ").append(toIndentedString(canHistoryMostRecentDate)).append("\n");
    sb.append("    canHistoryOldestDate: ").append(toIndentedString(canHistoryOldestDate)).append("\n");
    sb.append("    currentPaymentStatus: ").append(toIndentedString(currentPaymentStatus)).append("\n");
    sb.append("    creditBureauIdentifier: ").append(toIndentedString(creditBureauIdentifier)).append("\n");
    sb.append("    worstDelinquencyMop: ").append(toIndentedString(worstDelinquencyMop)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

