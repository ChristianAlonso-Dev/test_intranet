package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Score calculation result.
 */

@Schema(name = "buroScore", description = "Score calculation result.")
@JsonTypeName("buroScore")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroScore {

  private String scoreName;

  private String scoreCode;

  private String scoreValue;

  @Valid
  private List<@Size(max = 3)String> reasonCodes = new ArrayList<>();

  private String errorCode;

  public BuroScore scoreName(String scoreName) {
    this.scoreName = scoreName;
    return this;
  }

  /**
   * Indicates that a statistical model (Score or Income Estimator) was requested, e.g. BC SCORE.
   * @return scoreName
  */
  @Size(max = 30) 
  @Schema(name = "scoreName", example = "BC SCORE", description = "Indicates that a statistical model (Score or Income Estimator) was requested, e.g. BC SCORE.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("scoreName")
  public String getScoreName() {
    return scoreName;
  }

  public void setScoreName(String scoreName) {
    this.scoreName = scoreName;
  }

  public BuroScore scoreCode(String scoreCode) {
    this.scoreCode = scoreCode;
    return this;
  }

  /**
   * Code of the requested Score model (Annex 7).
   * @return scoreCode
  */
  @Size(max = 3) 
  @Schema(name = "scoreCode", example = "002", description = "Code of the requested Score model (Annex 7).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("scoreCode")
  public String getScoreCode() {
    return scoreCode;
  }

  public void setScoreCode(String scoreCode) {
    this.scoreCode = scoreCode;
  }

  public BuroScore scoreValue(String scoreValue) {
    this.scoreValue = scoreValue;
    return this;
  }

  /**
   * Score value; a negative value is an exclusion code (Annex 10).
   * @return scoreValue
  */
  @Size(max = 4) 
  @Schema(name = "scoreValue", example = "0724", description = "Score value; a negative value is an exclusion code (Annex 10).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("scoreValue")
  public String getScoreValue() {
    return scoreValue;
  }

  public void setScoreValue(String scoreValue) {
    this.scoreValue = scoreValue;
  }

  public BuroScore reasonCodes(List<@Size(max = 3)String> reasonCodes) {
    this.reasonCodes = reasonCodes;
    return this;
  }

  public BuroScore addReasonCodesItem(String reasonCodesItem) {
    if (this.reasonCodes == null) {
      this.reasonCodes = new ArrayList<>();
    }
    this.reasonCodes.add(reasonCodesItem);
    return this;
  }

  /**
   * Reason codes that explain the calculated Score.
   * @return reasonCodes
  */
  
  @Schema(name = "reasonCodes", example = "[\"22\",\"09\",\"13\"]", description = "Reason codes that explain the calculated Score.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reasonCodes")
  public List<@Size(max = 3)String> getReasonCodes() {
    return reasonCodes;
  }

  public void setReasonCodes(List<@Size(max = 3)String> reasonCodes) {
    this.reasonCodes = reasonCodes;
  }

  public BuroScore errorCode(String errorCode) {
    this.errorCode = errorCode;
    return this;
  }

  /**
   * Error code; when present, scoreValue and reasonCodes are not presented.
   * @return errorCode
  */
  @Size(max = 2) 
  @Schema(name = "errorCode", description = "Error code; when present, scoreValue and reasonCodes are not presented.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("errorCode")
  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroScore buroScore = (BuroScore) o;
    return Objects.equals(this.scoreName, buroScore.scoreName) &&
        Objects.equals(this.scoreCode, buroScore.scoreCode) &&
        Objects.equals(this.scoreValue, buroScore.scoreValue) &&
        Objects.equals(this.reasonCodes, buroScore.reasonCodes) &&
        Objects.equals(this.errorCode, buroScore.errorCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(scoreName, scoreCode, scoreValue, reasonCodes, errorCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroScore {\n");
    sb.append("    scoreName: ").append(toIndentedString(scoreName)).append("\n");
    sb.append("    scoreCode: ").append(toIndentedString(scoreCode)).append("\n");
    sb.append("    scoreValue: ").append(toIndentedString(scoreValue)).append("\n");
    sb.append("    reasonCodes: ").append(toIndentedString(reasonCodes)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

