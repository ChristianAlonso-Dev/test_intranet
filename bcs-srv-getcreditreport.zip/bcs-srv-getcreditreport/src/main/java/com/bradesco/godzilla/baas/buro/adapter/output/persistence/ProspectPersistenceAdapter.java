package com.bradesco.godzilla.baas.buro.adapter.output.persistence;

import com.bradesco.godzilla.baas.buro.port.output.IProspectPort;
import com.bradesco.godzilla.baas.commons.servicedataconnector.repository.onboarding.ProspectoRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class ProspectPersistenceAdapter implements IProspectPort {

    private final ProspectoRepository prospectoRepository;

    public ProspectPersistenceAdapter(ProspectoRepository prospectoRepository) {
        this.prospectoRepository = prospectoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsActiveProspect(String prospectId) {
        Long idProspecto;
        try {
            idProspecto = Long.valueOf(prospectId);
        } catch (NumberFormatException exception) {
            return false;
        }
        return prospectoRepository.findByIdProspectoAndFechaBajaIsNull(idProspecto).isPresent();
    }
}
