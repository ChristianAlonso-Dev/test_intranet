package com.bradesco.godzilla.baas.buro.api.controller;

import com.bradesco.godzilla.baas.buro.api.model.ChannelId;
import com.bradesco.godzilla.baas.buro.api.model.ChannelType;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.BusinessErrorCode;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.regex.Pattern;
import org.springframework.http.InvalidMediaTypeException;
import org.springframework.http.MediaType;
import org.springframework.web.context.request.NativeWebRequest;

public final class ApiUtil {

    private static final String BEARER_PREFIX = "Bearer ";
    private static final Pattern TRACEPARENT = Pattern.compile("^(?:[0-9a-f]{2}-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2})$");
    private static final Pattern TRACESTATE = Pattern.compile("^([a-z0-9_/@-]+=[^,= ]+)(,[a-z0-9_/@-]+=[^,= ]+)*$");
    private static final Pattern REQUEST_ID = Pattern.compile("^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$");

    private ApiUtil() {
    }

    public static void setExampleResponse(NativeWebRequest req, String contentType, String example) {
        try {
            HttpServletResponse res = req.getNativeResponse(HttpServletResponse.class);
            res.setCharacterEncoding("UTF-8");
            res.addHeader("Content-Type", contentType);
            res.getWriter().print(example);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static void validateAuthorization(String authorization) {
        if (authorization == null) {
            throw new BusinessException(BusinessErrorCode.ERROR_8427_MISSING_REQUIRED_HEADER);
        }
        if (!authorization.startsWith(BEARER_PREFIX)
                || authorization.substring(BEARER_PREFIX.length()).isBlank()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    public static void validateContentType(String contentType) {
        if (contentType == null || contentType.isBlank() || !isJson(contentType)) {
            throw new BusinessException(BusinessErrorCode.ERROR_8015_UNSUPPORTED_MEDIATYPE);
        }
    }

    public static void validateTraceparent(String traceparent) {
        if (traceparent == null) {
            throw new BusinessException(BusinessErrorCode.ERROR_8427_MISSING_REQUIRED_HEADER);
        }
        if (!TRACEPARENT.matcher(traceparent).matches()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    public static void validateTracestate(String tracestate) {
        if (tracestate != null && !TRACESTATE.matcher(tracestate).matches()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    public static void validateRequestId(String requestId) {
        if (requestId == null) {
            throw new BusinessException(BusinessErrorCode.ERROR_8427_MISSING_REQUIRED_HEADER);
        }
        if (!REQUEST_ID.matcher(requestId).matches()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    public static void validateChannelId(String channelId) {
        if (channelId == null) {
            throw new BusinessException(BusinessErrorCode.ERROR_8427_MISSING_REQUIRED_HEADER);
        }
        toChannelId(channelId);
    }

    public static void validateChannelType(String channelType) {
        if (channelType == null) {
            throw new BusinessException(BusinessErrorCode.ERROR_8427_MISSING_REQUIRED_HEADER);
        }
        toChannelType(channelType);
    }

    public static ChannelId toChannelId(String value) {
        try {
            return ChannelId.fromValue(value);
        } catch (IllegalArgumentException exception) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    public static ChannelType toChannelType(String value) {
        try {
            return ChannelType.fromValue(value);
        } catch (IllegalArgumentException exception) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    private static boolean isJson(String contentType) {
        try {
            return MediaType.APPLICATION_JSON.equalsTypeAndSubtype(MediaType.parseMediaType(contentType.trim()));
        } catch (InvalidMediaTypeException exception) {
            return false;
        }
    }
}