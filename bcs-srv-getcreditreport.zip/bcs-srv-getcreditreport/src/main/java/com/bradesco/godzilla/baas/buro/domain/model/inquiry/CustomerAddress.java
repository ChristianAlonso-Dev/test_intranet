package com.bradesco.godzilla.baas.buro.domain.model.inquiry;

public record CustomerAddress(
        String street,
        String municipality,
        String city,
        String state,
        String postalCode,
        String countryCode
) {
}
