package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Credit Report response from Buró de Crédito.
 */

@Schema(name = "buroCreditReportResponse", description = "Credit Report response from Buró de Crédito.")
@JsonTypeName("buroCreditReportResponse")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroCreditReportResponse {

  private BuroResponse response;

  public BuroCreditReportResponse response(BuroResponse response) {
    this.response = response;
    return this;
  }

  /**
   * Get response
   * @return response
  */
  @Valid 
  @Schema(name = "response", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("response")
  public BuroResponse getResponse() {
    return response;
  }

  public void setResponse(BuroResponse response) {
    this.response = response;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroCreditReportResponse buroCreditReportResponse = (BuroCreditReportResponse) o;
    return Objects.equals(this.response, buroCreditReportResponse.response);
  }

  @Override
  public int hashCode() {
    return Objects.hash(response);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroCreditReportResponse {\n");
    sb.append("    response: ").append(toIndentedString(response)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

