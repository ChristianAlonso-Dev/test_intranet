package com.bradesco.godzilla.baas.buro.port.output;

import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReportResult;

public interface IGetCreditReportPort {

    CreditReportResult getCreditReport(CreditReportInquiry inquiry);
}