package com.bradesco.godzilla.baas.buro.domain.model.report;

public record CreditReportResult(
        CreditReport creditReport,
        RuntimeException failure,
        String providerRequest,
        String providerResponse
) {

    public static CreditReportResult success(CreditReport creditReport, String providerRequest, String providerResponse) {
        return new CreditReportResult(creditReport, null, providerRequest, providerResponse);
    }

    public static CreditReportResult failed(RuntimeException failure, String providerRequest, String providerResponse) {
        return new CreditReportResult(null, failure, providerRequest, providerResponse);
    }
}