package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Query made to the Customer&#39;s file in the last 24 months.
 */

@Schema(name = "buroInquiry", description = "Query made to the Customer's file in the last 24 months.")
@JsonTypeName("buroInquiry")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroInquiry {

  private String inquiryDate;

  private String memberCode;

  private String grantorName;

  private String grantorPhoneNumber;

  private String contractType;

  private String contractAmount;

  private String responsibilityType;

  private String newConsumer;

  private String currencyCode;

  private String buroIdentification;

  private String inquirySourceIdentifier;

  private String finalResult;

  public BuroInquiry inquiryDate(String inquiryDate) {
    this.inquiryDate = inquiryDate;
    return this;
  }

  /**
   * Query date (DDMMAAAA).
   * @return inquiryDate
  */
  @Size(max = 8) 
  @Schema(name = "inquiryDate", example = "13092022", description = "Query date (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("inquiryDate")
  public String getInquiryDate() {
    return inquiryDate;
  }

  public void setInquiryDate(String inquiryDate) {
    this.inquiryDate = inquiryDate;
  }

  public BuroInquiry memberCode(String memberCode) {
    this.memberCode = memberCode;
    return this;
  }

  /**
   * Member code of the User, only if it is the same institution that queries; otherwise blank spaces.
   * @return memberCode
  */
  @Size(max = 10) 
  @Schema(name = "memberCode", example = "BC00001001", description = "Member code of the User, only if it is the same institution that queries; otherwise blank spaces.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("memberCode")
  public String getMemberCode() {
    return memberCode;
  }

  public void setMemberCode(String memberCode) {
    this.memberCode = memberCode;
  }

  public BuroInquiry grantorName(String grantorName) {
    this.grantorName = grantorName;
    return this;
  }

  /**
   * Name of the grantor, or a generic name (e.g. BANCO) if it is a different institution.
   * @return grantorName
  */
  @Size(max = 16) 
  @Schema(name = "grantorName", example = "ALFANUMERICO", description = "Name of the grantor, or a generic name (e.g. BANCO) if it is a different institution.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("grantorName")
  public String getGrantorName() {
    return grantorName;
  }

  public void setGrantorName(String grantorName) {
    this.grantorName = grantorName;
  }

  public BuroInquiry grantorPhoneNumber(String grantorPhoneNumber) {
    this.grantorPhoneNumber = grantorPhoneNumber;
    return this;
  }

  /**
   * Telephone of the User that made the query. Area code + up to 8 digits.
   * @return grantorPhoneNumber
  */
  @Size(max = 11) 
  @Schema(name = "grantorPhoneNumber", example = "13336400405", description = "Telephone of the User that made the query. Area code + up to 8 digits.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("grantorPhoneNumber")
  public String getGrantorPhoneNumber() {
    return grantorPhoneNumber;
  }

  public void setGrantorPhoneNumber(String grantorPhoneNumber) {
    this.grantorPhoneNumber = grantorPhoneNumber;
  }

  public BuroInquiry contractType(String contractType) {
    this.contractType = contractType;
    return this;
  }

  /**
   * Contract or product type (Annex 3).
   * @return contractType
  */
  @Size(max = 2) 
  @Schema(name = "contractType", example = "CC", description = "Contract or product type (Annex 3).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contractType")
  public String getContractType() {
    return contractType;
  }

  public void setContractType(String contractType) {
    this.contractType = contractType;
  }

  public BuroInquiry contractAmount(String contractAmount) {
    this.contractAmount = contractAmount;
    return this;
  }

  /**
   * Credit amount.
   * @return contractAmount
  */
  @Size(max = 9) 
  @Schema(name = "contractAmount", example = "0", description = "Credit amount.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contractAmount")
  public String getContractAmount() {
    return contractAmount;
  }

  public void setContractAmount(String contractAmount) {
    this.contractAmount = contractAmount;
  }

  public BuroInquiry responsibilityType(String responsibilityType) {
    this.responsibilityType = responsibilityType;
    return this;
  }

  /**
   * Responsibility type: A = Authorized User (Additional), I = Individual, J = Joint, C = Joint and Several Obligor.
   * @return responsibilityType
  */
  @Size(max = 1) 
  @Schema(name = "responsibilityType", example = "I", description = "Responsibility type: A = Authorized User (Additional), I = Individual, J = Joint, C = Joint and Several Obligor.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("responsibilityType")
  public String getResponsibilityType() {
    return responsibilityType;
  }

  public void setResponsibilityType(String responsibilityType) {
    this.responsibilityType = responsibilityType;
  }

  public BuroInquiry newConsumer(String newConsumer) {
    this.newConsumer = newConsumer;
    return this;
  }

  /**
   * Y = new Customer entered in the database as a result of the query.
   * @return newConsumer
  */
  @Size(max = 1) 
  @Schema(name = "newConsumer", example = "Y", description = "Y = new Customer entered in the database as a result of the query.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("newConsumer")
  public String getNewConsumer() {
    return newConsumer;
  }

  public void setNewConsumer(String newConsumer) {
    this.newConsumer = newConsumer;
  }

  public BuroInquiry currencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
    return this;
  }

  /**
   * Credit currency: MX = Mexican Pesos, N$ = Mexican Pesos, UD = Investment Units (UDI's), US = US Dollars.
   * @return currencyCode
  */
  @Size(max = 2) 
  @Schema(name = "currencyCode", description = "Credit currency: MX = Mexican Pesos, N$ = Mexican Pesos, UD = Investment Units (UDI's), US = US Dollars.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currencyCode")
  public String getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
  }

  public BuroInquiry buroIdentification(String buroIdentification) {
    this.buroIdentification = buroIdentification;
    return this;
  }

  /**
   * Reserved for future use (four zeros).
   * @return buroIdentification
  */
  @Size(max = 4) 
  @Schema(name = "buroIdentification", description = "Reserved for future use (four zeros).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("buroIdentification")
  public String getBuroIdentification() {
    return buroIdentification;
  }

  public void setBuroIdentification(String buroIdentification) {
    this.buroIdentification = buroIdentification;
  }

  public BuroInquiry inquirySourceIdentifier(String inquirySourceIdentifier) {
    this.inquirySourceIdentifier = inquirySourceIdentifier;
    return this;
  }

  /**
   * 0 = Buró de Crédito, 1 = Círculo de Crédito.
   * @return inquirySourceIdentifier
  */
  @Size(max = 25) 
  @Schema(name = "inquirySourceIdentifier", example = "0", description = "0 = Buró de Crédito, 1 = Círculo de Crédito.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("inquirySourceIdentifier")
  public String getInquirySourceIdentifier() {
    return inquirySourceIdentifier;
  }

  public void setInquirySourceIdentifier(String inquirySourceIdentifier) {
    this.inquirySourceIdentifier = inquirySourceIdentifier;
  }

  public BuroInquiry finalResult(String finalResult) {
    this.finalResult = finalResult;
    return this;
  }

  /**
   * Zeros when the Credit Report is queried.
   * @return finalResult
  */
  @Size(max = 25) 
  @Schema(name = "finalResult", description = "Zeros when the Credit Report is queried.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("finalResult")
  public String getFinalResult() {
    return finalResult;
  }

  public void setFinalResult(String finalResult) {
    this.finalResult = finalResult;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroInquiry buroInquiry = (BuroInquiry) o;
    return Objects.equals(this.inquiryDate, buroInquiry.inquiryDate) &&
        Objects.equals(this.memberCode, buroInquiry.memberCode) &&
        Objects.equals(this.grantorName, buroInquiry.grantorName) &&
        Objects.equals(this.grantorPhoneNumber, buroInquiry.grantorPhoneNumber) &&
        Objects.equals(this.contractType, buroInquiry.contractType) &&
        Objects.equals(this.contractAmount, buroInquiry.contractAmount) &&
        Objects.equals(this.responsibilityType, buroInquiry.responsibilityType) &&
        Objects.equals(this.newConsumer, buroInquiry.newConsumer) &&
        Objects.equals(this.currencyCode, buroInquiry.currencyCode) &&
        Objects.equals(this.buroIdentification, buroInquiry.buroIdentification) &&
        Objects.equals(this.inquirySourceIdentifier, buroInquiry.inquirySourceIdentifier) &&
        Objects.equals(this.finalResult, buroInquiry.finalResult);
  }

  @Override
  public int hashCode() {
    return Objects.hash(inquiryDate, memberCode, grantorName, grantorPhoneNumber, contractType, contractAmount, responsibilityType, newConsumer, currencyCode, buroIdentification, inquirySourceIdentifier, finalResult);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroInquiry {\n");
    sb.append("    inquiryDate: ").append(toIndentedString(inquiryDate)).append("\n");
    sb.append("    memberCode: ").append(toIndentedString(memberCode)).append("\n");
    sb.append("    grantorName: ").append(toIndentedString(grantorName)).append("\n");
    sb.append("    grantorPhoneNumber: ").append(toIndentedString(grantorPhoneNumber)).append("\n");
    sb.append("    contractType: ").append(toIndentedString(contractType)).append("\n");
    sb.append("    contractAmount: ").append(toIndentedString(contractAmount)).append("\n");
    sb.append("    responsibilityType: ").append(toIndentedString(responsibilityType)).append("\n");
    sb.append("    newConsumer: ").append(toIndentedString(newConsumer)).append("\n");
    sb.append("    currencyCode: ").append(toIndentedString(currencyCode)).append("\n");
    sb.append("    buroIdentification: ").append(toIndentedString(buroIdentification)).append("\n");
    sb.append("    inquirySourceIdentifier: ").append(toIndentedString(inquirySourceIdentifier)).append("\n");
    sb.append("    finalResult: ").append(toIndentedString(finalResult)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

