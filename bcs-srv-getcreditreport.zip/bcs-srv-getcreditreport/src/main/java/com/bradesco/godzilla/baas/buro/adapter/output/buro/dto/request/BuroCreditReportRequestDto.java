package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

public record BuroCreditReportRequestDto(
        @JsonProperty("consulta") Query query
) {

    public record Query(
            @JsonProperty("persona") Person person
    ) {
    }

    @JsonPropertyOrder({"encabezado", "nombre", "domicilios"})
    public record Person(
            @JsonProperty("encabezado") Header header,
            @JsonProperty("nombre") Name name,
            @JsonProperty("domicilios") List<Address> addresses
    ) {
    }

    public record Header(
            @JsonProperty("clavePais") String countryCode,
            @JsonProperty("claveUnidadMonetaria") String currencyCode,
            @JsonProperty("identificadorBuro") String buroIdentifier,
            @JsonProperty("idioma") String language,
            @JsonProperty("numeroReferenciaOperador") String operatorReference,
            @JsonProperty("productoRequerido") String requiredProduct,
            @JsonProperty("tipoConsulta") String inquiryType,
            @JsonProperty("tipoContrato") String contractType
    ) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Name(
            @JsonProperty("apellidoPaterno") String paternalLastName,
            @JsonProperty("apellidoMaterno") String maternalLastName,
            @JsonProperty("primerNombre") String firstName,
            @JsonProperty("rfc") String rfc
    ) {
    }

    public record Address(
            @JsonProperty("direccion1") String street,
            @JsonProperty("delegacionMunicipio") String municipality,
            @JsonProperty("ciudad") String city,
            @JsonProperty("estado") String state,
            @JsonProperty("cp") String postalCode,
            @JsonProperty("codPais") String countryCode
    ) {
    }
}
