package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroUserErrorDto(
        @JsonProperty("numeroReferenciaOperador") String operatorReference,
        @JsonProperty("solicitudClienteErronea") String invalidCustomerRequest,
        @JsonProperty("productoSolicitadoErroneo") String invalidRequestedProduct,
        @JsonProperty("segmentoRequeridoNoProporcionado") String missingRequiredSegment,
        @JsonProperty("ultimaInformacionValidaCliente") String lastValidCustomerInformation,
        @JsonProperty("informacionErroneaParaConsulta") @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY) List<String> invalidQueryInformation,
        @JsonProperty("valorErroneoCampoRelacionado") String invalidRelatedFieldValue,
        @JsonProperty("errorSistemaBuroCredito") String buroSystemError,
        @JsonProperty("etiquetaSegmentoErronea") String invalidSegmentTag,
        @JsonProperty("ordenErroneoSegmento") String invalidSegmentOrder,
        @JsonProperty("numeroErroneoSegmentos") String invalidSegmentCount,
        @JsonProperty("faltaCampoRequerido") @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY) List<String> missingRequiredField,
        @JsonProperty("errorReporteBloqueado") String blockedFileError,
        @JsonProperty("passwordOClaveErronea") String invalidUserCodeOrPassword,
        @JsonProperty("versionProporcionadaErronea") String invalidVersion
) {
}
