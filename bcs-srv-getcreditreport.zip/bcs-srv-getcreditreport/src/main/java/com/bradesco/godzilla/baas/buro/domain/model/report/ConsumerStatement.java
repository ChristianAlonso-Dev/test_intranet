package com.bradesco.godzilla.baas.buro.domain.model.report;


public record ConsumerStatement(
        String consumerStatement
) {
}
