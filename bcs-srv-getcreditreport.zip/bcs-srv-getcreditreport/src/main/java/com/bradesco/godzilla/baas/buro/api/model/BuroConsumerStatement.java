package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Consumer statement.
 */

@Schema(name = "buroConsumerStatement", description = "Consumer statement.")
@JsonTypeName("buroConsumerStatement")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroConsumerStatement {

  private String consumerStatement;

  public BuroConsumerStatement consumerStatement(String consumerStatement) {
    this.consumerStatement = consumerStatement;
    return this;
  }

  /**
   * Customer statement (up to 1,000 words). Statements per credit are identified as CREDITO01 and delimited with ##.
   * @return consumerStatement
  */
  @Size(max = 12000) 
  @Schema(name = "consumerStatement", example = "DECLARATIVA PRUEBA LIBERACION 02-07-2020##CREDITO26 DECLARATIVA CUENTA PRUEBA LIBERACION 02-07-2020", description = "Customer statement (up to 1,000 words). Statements per credit are identified as CREDITO01 and delimited with ##.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("consumerStatement")
  public String getConsumerStatement() {
    return consumerStatement;
  }

  public void setConsumerStatement(String consumerStatement) {
    this.consumerStatement = consumerStatement;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroConsumerStatement buroConsumerStatement = (BuroConsumerStatement) o;
    return Objects.equals(this.consumerStatement, buroConsumerStatement.consumerStatement);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerStatement);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroConsumerStatement {\n");
    sb.append("    consumerStatement: ").append(toIndentedString(consumerStatement)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

