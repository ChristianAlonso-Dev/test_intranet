package com.bradesco.godzilla.baas.buro.domain.model.log;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CreditReportLog {

    private final String requestId;

    private final String customerId;

    private final String rfc;

    private final String requiredProduct;

    private final String operatorReference;

    private final String channelId;

    private final String channelType;

    private final String geoLocation;

    private final String traceparent;

    private final String providerRequest;

    private final String providerResponse;

    private final LocalDateTime requestedAt;
}
