package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Response header.
 */

@Schema(name = "buroHeader", description = "Response header.")
@JsonTypeName("buroHeader")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroHeader {

  private String countryCode;

  private String buroIdentifier;

  private String operatorReference;

  private String memberCode;

  private String primaryConsumerReturnCode;

  private String secondaryConsumerReturnCode;

  private String queryControlNumber;

  public BuroHeader countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Country: MX.
   * @return countryCode
  */
  @Size(max = 3) 
  @Schema(name = "countryCode", example = "MX", description = "Country: MX.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("countryCode")
  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public BuroHeader buroIdentifier(String buroIdentifier) {
    this.buroIdentifier = buroIdentifier;
    return this;
  }

  /**
   * Response origin by Credit Information Company. Positions: 1 TUM, 2 DUN, 3 CC, 4 future use. Values: 0 = No hit, 1 = Hit, 2 = System not available at the SIC, 3 = Extended Credit Report D&B.
   * @return buroIdentifier
  */
  @Size(max = 4) 
  @Schema(name = "buroIdentifier", example = "1110", description = "Response origin by Credit Information Company. Positions: 1 TUM, 2 DUN, 3 CC, 4 future use. Values: 0 = No hit, 1 = Hit, 2 = System not available at the SIC, 3 = Extended Credit Report D&B.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("buroIdentifier")
  public String getBuroIdentifier() {
    return buroIdentifier;
  }

  public void setBuroIdentifier(String buroIdentifier) {
    this.buroIdentifier = buroIdentifier;
  }

  public BuroHeader operatorReference(String operatorReference) {
    this.operatorReference = operatorReference;
    return this;
  }

  /**
   * Reference sent in the query.
   * @return operatorReference
  */
  @Size(max = 25) 
  @Schema(name = "operatorReference", example = "123456789 ", description = "Reference sent in the query.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("operatorReference")
  public String getOperatorReference() {
    return operatorReference;
  }

  public void setOperatorReference(String operatorReference) {
    this.operatorReference = operatorReference;
  }

  public BuroHeader memberCode(String memberCode) {
    this.memberCode = memberCode;
    return this;
  }

  /**
   * User code (member code).
   * @return memberCode
  */
  @Size(max = 10) 
  @Schema(name = "memberCode", example = "BC00001017", description = "User code (member code).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("memberCode")
  public String getMemberCode() {
    return memberCode;
  }

  public void setMemberCode(String memberCode) {
    this.memberCode = memberCode;
  }

  public BuroHeader primaryConsumerReturnCode(String primaryConsumerReturnCode) {
    this.primaryConsumerReturnCode = primaryConsumerReturnCode;
    return this;
  }

  /**
   * 0 = Not found, 1 = Found.
   * @return primaryConsumerReturnCode
  */
  @Size(max = 1) 
  @Schema(name = "primaryConsumerReturnCode", example = "1", description = "0 = Not found, 1 = Found.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("primaryConsumerReturnCode")
  public String getPrimaryConsumerReturnCode() {
    return primaryConsumerReturnCode;
  }

  public void setPrimaryConsumerReturnCode(String primaryConsumerReturnCode) {
    this.primaryConsumerReturnCode = primaryConsumerReturnCode;
  }

  public BuroHeader secondaryConsumerReturnCode(String secondaryConsumerReturnCode) {
    this.secondaryConsumerReturnCode = secondaryConsumerReturnCode;
    return this;
  }

  /**
   * Tag no longer in use. 0 = Not found, 1 = Found.
   * @return secondaryConsumerReturnCode
  */
  @Size(max = 1) 
  @Schema(name = "secondaryConsumerReturnCode", example = "0", description = "Tag no longer in use. 0 = Not found, 1 = Found.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("secondaryConsumerReturnCode")
  public String getSecondaryConsumerReturnCode() {
    return secondaryConsumerReturnCode;
  }

  public void setSecondaryConsumerReturnCode(String secondaryConsumerReturnCode) {
    this.secondaryConsumerReturnCode = secondaryConsumerReturnCode;
  }

  public BuroHeader queryControlNumber(String queryControlNumber) {
    this.queryControlNumber = queryControlNumber;
    return this;
  }

  /**
   * Query control number assigned by Buró de Crédito.
   * @return queryControlNumber
  */
  @Size(max = 99) 
  @Schema(name = "queryControlNumber", example = "2424875572", description = "Query control number assigned by Buró de Crédito.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queryControlNumber")
  public String getQueryControlNumber() {
    return queryControlNumber;
  }

  public void setQueryControlNumber(String queryControlNumber) {
    this.queryControlNumber = queryControlNumber;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroHeader buroHeader = (BuroHeader) o;
    return Objects.equals(this.countryCode, buroHeader.countryCode) &&
        Objects.equals(this.buroIdentifier, buroHeader.buroIdentifier) &&
        Objects.equals(this.operatorReference, buroHeader.operatorReference) &&
        Objects.equals(this.memberCode, buroHeader.memberCode) &&
        Objects.equals(this.primaryConsumerReturnCode, buroHeader.primaryConsumerReturnCode) &&
        Objects.equals(this.secondaryConsumerReturnCode, buroHeader.secondaryConsumerReturnCode) &&
        Objects.equals(this.queryControlNumber, buroHeader.queryControlNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(countryCode, buroIdentifier, operatorReference, memberCode, primaryConsumerReturnCode, secondaryConsumerReturnCode, queryControlNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroHeader {\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("    buroIdentifier: ").append(toIndentedString(buroIdentifier)).append("\n");
    sb.append("    operatorReference: ").append(toIndentedString(operatorReference)).append("\n");
    sb.append("    memberCode: ").append(toIndentedString(memberCode)).append("\n");
    sb.append("    primaryConsumerReturnCode: ").append(toIndentedString(primaryConsumerReturnCode)).append("\n");
    sb.append("    secondaryConsumerReturnCode: ").append(toIndentedString(secondaryConsumerReturnCode)).append("\n");
    sb.append("    queryControlNumber: ").append(toIndentedString(queryControlNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

