package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Customer address. At least one address is required; the postal code must match the state, municipality and city.
 */

@Schema(name = "creditReportAddress", description = "Customer address. At least one address is required; the postal code must match the state, municipality and city.")
@JsonTypeName("creditReportAddress")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class CreditReportAddress {

  private String street;

  private String municipality;

  private String city;

  /**
   * State code of the Mexican Republic.
   */
  public enum StateEnum {
    AGS("AGS"),
    
    BCN("BCN"),
    
    BCS("BCS"),
    
    CAM("CAM"),
    
    CHS("CHS"),
    
    CHI("CHI"),
    
    CDMX("CDMX"),
    
    COA("COA"),
    
    COL("COL"),
    
    DGO("DGO"),
    
    EM("EM"),
    
    GTO("GTO"),
    
    GRO("GRO"),
    
    HGO("HGO"),
    
    JAL("JAL"),
    
    MICH("MICH"),
    
    MOR("MOR"),
    
    NAY("NAY"),
    
    NL("NL"),
    
    OAX("OAX"),
    
    PUE("PUE"),
    
    QRO("QRO"),
    
    QR("QR"),
    
    SLP("SLP"),
    
    SIN("SIN"),
    
    SON("SON"),
    
    TAB("TAB"),
    
    TAM("TAM"),
    
    TLAX("TLAX"),
    
    VER("VER"),
    
    YUC("YUC"),
    
    ZAC("ZAC");

    private String value;

    StateEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StateEnum fromValue(String value) {
      for (StateEnum b : StateEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private StateEnum state;

  private String postalCode;

  /**
   * Country of origin of the address.
   */
  public enum CountryCodeEnum {
    MX("MX");

    private String value;

    CountryCodeEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static CountryCodeEnum fromValue(String value) {
      for (CountryCodeEnum b : CountryCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private CountryCodeEnum countryCode;

  public CreditReportAddress() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public CreditReportAddress(String street, String municipality, String city, StateEnum state, String postalCode, CountryCodeEnum countryCode) {
    this.street = street;
    this.municipality = municipality;
    this.city = city;
    this.state = state;
    this.postalCode = postalCode;
    this.countryCode = countryCode;
  }

  public CreditReportAddress street(String street) {
    this.street = street;
    return this;
  }

  /**
   * Customer’s home address. It must include the street and the exterior and interior number, when they exist. If the address has no number, send “SN” (e.g. REFORMA SN); S/N is also accepted. For an address that is only known, send “DOMICILIO CONOCIDO” or “DOMICILIO CONOCIDO SN”. An address without a number or SN is rejected.
   * @return street
  */
  @NotNull @Pattern(regexp = "^[A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ#.,/-]+( [A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ#.,/-]+)*$") @Size(min = 1, max = 40) 
  @Schema(name = "street", example = "JAIME BALMES 88", description = "Customer’s home address. It must include the street and the exterior and interior number, when they exist. If the address has no number, send “SN” (e.g. REFORMA SN); S/N is also accepted. For an address that is only known, send “DOMICILIO CONOCIDO” or “DOMICILIO CONOCIDO SN”. An address without a number or SN is rejected.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("street")
  public String getStreet() {
    return street;
  }

  public void setStreet(String street) {
    this.street = street;
  }

  public CreditReportAddress municipality(String municipality) {
    this.municipality = municipality;
    return this;
  }

  /**
   * Mayor's office (Alcaldía) or municipality.
   * @return municipality
  */
  @NotNull @Pattern(regexp = "^[A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ#.,/-]+( [A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ#.,/-]+)*$") @Size(min = 1, max = 40) 
  @Schema(name = "municipality", example = "MIGUEL HIDALGO", description = "Mayor's office (Alcaldía) or municipality.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("municipality")
  public String getMunicipality() {
    return municipality;
  }

  public void setMunicipality(String municipality) {
    this.municipality = municipality;
  }

  public CreditReportAddress city(String city) {
    this.city = city;
    return this;
  }

  /**
   * City.
   * @return city
  */
  @NotNull @Pattern(regexp = "^[A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ#.,/-]+( [A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ#.,/-]+)*$") @Size(min = 1, max = 40) 
  @Schema(name = "city", example = "CD DE MEXICO", description = "City.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("city")
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public CreditReportAddress state(StateEnum state) {
    this.state = state;
    return this;
  }

  /**
   * State code of the Mexican Republic.
   * @return state
  */
  @NotNull
  @Schema(name = "state", example = "CDMX", description = "State code of the Mexican Republic.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("state")
  public StateEnum getState() {
    return state;
  }

  public void setState(StateEnum state) {
    this.state = state;
  }

  public CreditReportAddress postalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Postal code, exactly 5 positions. Must match the state, municipality and/or city (SEPOMEX).
   * @return postalCode
  */
  @NotNull @Pattern(regexp = "^[0-9]{5}$") @Size(min = 5, max = 5) 
  @Schema(name = "postalCode", example = "11510", description = "Postal code, exactly 5 positions. Must match the state, municipality and/or city (SEPOMEX).", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("postalCode")
  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public CreditReportAddress countryCode(CountryCodeEnum countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Country of origin of the address.
   * @return countryCode
  */
  @NotNull
  @Schema(name = "countryCode", example = "MX", description = "Country of origin of the address.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("countryCode")
  public CountryCodeEnum getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(CountryCodeEnum countryCode) {
    this.countryCode = countryCode;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CreditReportAddress creditReportAddress = (CreditReportAddress) o;
    return Objects.equals(this.street, creditReportAddress.street) &&
        Objects.equals(this.municipality, creditReportAddress.municipality) &&
        Objects.equals(this.city, creditReportAddress.city) &&
        Objects.equals(this.state, creditReportAddress.state) &&
        Objects.equals(this.postalCode, creditReportAddress.postalCode) &&
        Objects.equals(this.countryCode, creditReportAddress.countryCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(street, municipality, city, state, postalCode, countryCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CreditReportAddress {\n");
    sb.append("    street: ").append(toIndentedString(street)).append("\n");
    sb.append("    municipality: ").append(toIndentedString(municipality)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

