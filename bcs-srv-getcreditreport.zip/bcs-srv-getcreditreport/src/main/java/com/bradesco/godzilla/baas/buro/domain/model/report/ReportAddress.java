package com.bradesco.godzilla.baas.buro.domain.model.report;


public record ReportAddress(
        String addressLine1,
        String addressLine2,
        String neighborhood,
        String municipality,
        String city,
        String state,
        String postalCode,
        String residenceDate,
        String phoneNumber,
        String extension,
        String fax,
        String addressType,
        String specialAddressIndicator,
        String addressReportDate,
        String countryCode
) {
}
