package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroScoreDto(
        @JsonProperty("nombreScore") String scoreName,
        @JsonProperty("codigoScore") String scoreCode,
        @JsonProperty("valorScore") String scoreValue,
        @JsonProperty("codigoRazon") List<String> reasonCodes,
        @JsonProperty("codigoError") String errorCode
) {
}
