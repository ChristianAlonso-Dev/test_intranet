package com.bradesco.godzilla.baas.buro.port.output;

public interface IProspectPort {

    boolean existsActiveProspect(String prospectId);
}
