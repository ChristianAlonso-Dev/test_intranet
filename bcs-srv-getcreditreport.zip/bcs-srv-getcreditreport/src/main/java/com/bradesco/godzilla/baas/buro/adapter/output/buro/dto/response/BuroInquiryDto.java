package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroInquiryDto(
        @JsonProperty("fechaConsulta") String inquiryDate,
        @JsonProperty("claveOtorgante") String memberCode,
        @JsonProperty("nombreOtorgante") String grantorName,
        @JsonProperty("telefonoOtorgante") String grantorPhoneNumber,
        @JsonProperty("tipoContrato") String contractType,
        @JsonProperty("importeContrato") String contractAmount,
        @JsonProperty("indicadorTipoResponsabilidad") String responsibilityType,
        @JsonProperty("consumidorNuevo") String newConsumer,
        @JsonProperty("claveUnidadMonetaria") String currencyCode,
        @JsonProperty("identificacionBuro") String buroIdentification,
        @JsonProperty("identificadorOrigenConsulta") String inquirySourceIdentifier,
        @JsonProperty("resultadoFinal") String finalResult
) {
}
