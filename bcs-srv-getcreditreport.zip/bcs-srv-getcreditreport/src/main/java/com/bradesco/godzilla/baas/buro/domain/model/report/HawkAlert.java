package com.bradesco.godzilla.baas.buro.domain.model.report;


public record HawkAlert(
        String reportDate,
        String keyCode,
        String institutionType,
        String message
) {
}
