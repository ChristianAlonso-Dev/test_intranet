package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroAddressDto(
        @JsonProperty("direccion1") String addressLine1,
        @JsonProperty("direccion2") String addressLine2,
        @JsonProperty("coloniaPoblacion") String neighborhood,
        @JsonProperty("delegacionMunicipio") String municipality,
        @JsonProperty("ciudad") String city,
        @JsonProperty("estado") String state,
        @JsonProperty("cp") String postalCode,
        @JsonProperty("fechaResidencia") String residenceDate,
        @JsonProperty("numeroTelefono") String phoneNumber,
        @JsonProperty("extension") String extension,
        @JsonProperty("fax") String fax,
        @JsonProperty("tipoDomicilio") String addressType,
        @JsonProperty("indicadorEspecialDomicilio") String specialAddressIndicator,
        @JsonProperty("fechaReporteDireccion") String addressReportDate,
        @JsonProperty("codPais") String countryCode
) {
}
