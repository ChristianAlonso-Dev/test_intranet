package com.bradesco.godzilla.baas.buro.domain.model.report;

import java.util.List;

public record ReportScore(
        String scoreName,
        String scoreCode,
        String scoreValue,
        List<String> reasonCodes,
        String errorCode
) {
}
