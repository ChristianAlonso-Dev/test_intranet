package com.bradesco.godzilla.baas.buro.port.input;

import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;

public interface IGetCreditReportUseCase {

    CreditReport execute(GetCreditReportQuery query);
}
