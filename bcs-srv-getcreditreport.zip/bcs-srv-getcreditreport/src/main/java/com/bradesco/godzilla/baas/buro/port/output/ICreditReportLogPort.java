package com.bradesco.godzilla.baas.buro.port.output;

import com.bradesco.godzilla.baas.buro.domain.model.log.CreditReportLog;

public interface ICreditReportLogPort {

    boolean existsByRequestId(String requestId);

    void save(CreditReportLog creditReportLog);
}
