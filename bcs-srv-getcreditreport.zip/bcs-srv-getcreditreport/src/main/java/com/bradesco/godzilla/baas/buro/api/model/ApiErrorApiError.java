package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * ApiErrorApiError
 */

@JsonTypeName("ApiError_apiError")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class ApiErrorApiError {

  private String detailedMessage;

  private Integer errorCode;

  private String message;

  private Integer status;

  @Valid
  private List<@Valid ApiErrorApiErrorSubErrorsInner> subErrors = new ArrayList<>();

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private OffsetDateTime timestamp;

  public ApiErrorApiError() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public ApiErrorApiError(String detailedMessage, Integer errorCode, String message, Integer status, List<@Valid ApiErrorApiErrorSubErrorsInner> subErrors, OffsetDateTime timestamp) {
    this.detailedMessage = detailedMessage;
    this.errorCode = errorCode;
    this.message = message;
    this.status = status;
    this.subErrors = subErrors;
    this.timestamp = timestamp;
  }

  public ApiErrorApiError detailedMessage(String detailedMessage) {
    this.detailedMessage = detailedMessage;
    return this;
  }

  /**
   * Descripcion mas especifica del problema.
   * @return detailedMessage
  */
  @NotNull @Size(min = 1) 
  @Schema(name = "detailedMessage", example = "InvalidParameters.", description = "Descripcion mas especifica del problema.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("detailedMessage")
  public String getDetailedMessage() {
    return detailedMessage;
  }

  public void setDetailedMessage(String detailedMessage) {
    this.detailedMessage = detailedMessage;
  }

  public ApiErrorApiError errorCode(Integer errorCode) {
    this.errorCode = errorCode;
    return this;
  }

  /**
   * Codigo interno del error.
   * minimum: 1
   * @return errorCode
  */
  @NotNull @Min(1) 
  @Schema(name = "errorCode", example = "8410", description = "Codigo interno del error.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("errorCode")
  public Integer getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(Integer errorCode) {
    this.errorCode = errorCode;
  }

  public ApiErrorApiError message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Mensaje general del error.
   * @return message
  */
  @NotNull @Size(min = 1) 
  @Schema(name = "message", example = "BAD_REQUEST", description = "Mensaje general del error.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public ApiErrorApiError status(Integer status) {
    this.status = status;
    return this;
  }

  /**
   * Codigo HTTP de la respuesta.
   * minimum: 100
   * maximum: 599
   * @return status
  */
  @NotNull @Min(100) @Max(599) 
  @Schema(name = "status", example = "400", description = "Codigo HTTP de la respuesta.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("status")
  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  public ApiErrorApiError subErrors(List<@Valid ApiErrorApiErrorSubErrorsInner> subErrors) {
    this.subErrors = subErrors;
    return this;
  }

  public ApiErrorApiError addSubErrorsItem(ApiErrorApiErrorSubErrorsInner subErrorsItem) {
    if (this.subErrors == null) {
      this.subErrors = new ArrayList<>();
    }
    this.subErrors.add(subErrorsItem);
    return this;
  }

  /**
   * Lista de errores especificos.
   * @return subErrors
  */
  @NotNull @Valid 
  @Schema(name = "subErrors", description = "Lista de errores especificos.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("subErrors")
  public List<@Valid ApiErrorApiErrorSubErrorsInner> getSubErrors() {
    return subErrors;
  }

  public void setSubErrors(List<@Valid ApiErrorApiErrorSubErrorsInner> subErrors) {
    this.subErrors = subErrors;
  }

  public ApiErrorApiError timestamp(OffsetDateTime timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  /**
   * Fecha y hora en que ocurrio el error en formato ISO 8601.
   * @return timestamp
  */
  @NotNull @Valid 
  @Schema(name = "timestamp", example = "2026-10-02T16:34:39.111057100Z", description = "Fecha y hora en que ocurrio el error en formato ISO 8601.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("timestamp")
  public OffsetDateTime getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(OffsetDateTime timestamp) {
    this.timestamp = timestamp;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApiErrorApiError apiErrorApiError = (ApiErrorApiError) o;
    return Objects.equals(this.detailedMessage, apiErrorApiError.detailedMessage) &&
        Objects.equals(this.errorCode, apiErrorApiError.errorCode) &&
        Objects.equals(this.message, apiErrorApiError.message) &&
        Objects.equals(this.status, apiErrorApiError.status) &&
        Objects.equals(this.subErrors, apiErrorApiError.subErrors) &&
        Objects.equals(this.timestamp, apiErrorApiError.timestamp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(detailedMessage, errorCode, message, status, subErrors, timestamp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApiErrorApiError {\n");
    sb.append("    detailedMessage: ").append(toIndentedString(detailedMessage)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    subErrors: ").append(toIndentedString(subErrors)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

