package com.bradesco.godzilla.baas.buro.domain.model.report;


public record ReportInquiry(
        String inquiryDate,
        String memberCode,
        String grantorName,
        String grantorPhoneNumber,
        String contractType,
        String contractAmount,
        String responsibilityType,
        String newConsumer,
        String currencyCode,
        String buroIdentification,
        String inquirySourceIdentifier,
        String finalResult
) {
}
