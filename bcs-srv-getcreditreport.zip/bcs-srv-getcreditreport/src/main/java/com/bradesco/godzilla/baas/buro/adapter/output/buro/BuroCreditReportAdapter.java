package com.bradesco.godzilla.baas.buro.adapter.output.buro;

import com.bradesco.godzilla.baas.buro.adapter.output.buro.mapper.BuroCreditReportMapper;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerAddress;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerName;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.InquiryHeader;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReportResult;
import com.bradesco.godzilla.baas.buro.port.output.IGetCreditReportPort;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.client.ICreditReport;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.enums.ClaveUnidadMonetaria;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.enums.CodigoPais;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.enums.Estado;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.enums.ProductoRequerido;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.enums.TipoContrato;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.Consulta;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.Domicilio;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.Encabezado;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.Nombre;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.Persona;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.CreditReportRequest;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.CreditReportResponse;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.SystemErrorCode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

@Component
@Slf4j
public class BuroCreditReportAdapter implements IGetCreditReportPort {

    private static final int OPERATOR_REFERENCE_LENGTH = 25;
    private static final String KNOWN_ADDRESS = "DOMICILIO CONOCIDO";
    private static final String KNOWN_ADDRESS_WITHOUT_NUMBER = "DOMICILIO CONOCIDO SN";
    private static final String WITHOUT_NUMBER = "SN";
    private static final Pattern DIACRITICAL_MARKS = Pattern.compile("\\p{M}+");
    private static final Pattern WHITESPACES = Pattern.compile("\\s+");
    private static final Pattern WITHOUT_NUMBER_SLASH = Pattern.compile("\\bS/N\\b");
    private static final Pattern ADDRESS_SYMBOLS = Pattern.compile("[#.,/-]");

    private final ICreditReport creditReport;
    private final BuroCreditReportMapper mapper;
    private final ObjectWriter objectWriter;
    private final String countryCode;
    private final ClaveUnidadMonetaria currencyCode;
    private final String buroIdentifier;
    private final String language;
    private final String inquiryType;

    public BuroCreditReportAdapter(
            ICreditReport creditReport,
            BuroCreditReportMapper mapper,
            ObjectMapper objectMapper,
            @Value("${buro.country-code}") String countryCode,
            @Value("${buro.currency-code}") String currencyCode,
            @Value("${buro.buro-identifier}") String buroIdentifier,
            @Value("${buro.language}") String language,
            @Value("${buro.inquiry-type}") String inquiryType) {
        this.creditReport = creditReport;
        this.mapper = mapper;
        this.objectWriter = objectMapper.writer().without(SerializationFeature.INDENT_OUTPUT);
        this.countryCode = countryCode;
        this.currencyCode = ClaveUnidadMonetaria.fromCode(currencyCode);
        this.buroIdentifier = buroIdentifier;
        this.language = language;
        this.inquiryType = inquiryType;
    }

    @Override
    public CreditReportResult getCreditReport(CreditReportInquiry inquiry) {
        CreditReportRequest request = toRequest(inquiry);
        String providerRequest = toJson(request);

        CreditReportResponse response;
        try {
            response = creditReport.getCreditReport(request).getBody();
        } catch (ResourceAccessException exception) {
            log.error("Buró de Crédito credit report call failed. cause={}", exception.getClass().getName());
            return CreditReportResult.failed(new BusinessException(SystemErrorCode.INTEGRATION_TIMEOUT), providerRequest, null);
        } catch (RestClientResponseException exception) {
            log.error("Buró de Crédito credit report call failed. cause={}, status={}",
                    exception.getClass().getName(), exception.getStatusCode().value());
            return CreditReportResult.failed(new BusinessException(SystemErrorCode.INTEGRATION_ERROR),
                    providerRequest, toProviderResponse(exception));
        } catch (RestClientException exception) {
            log.error("Buró de Crédito credit report call failed. cause={}", exception.getClass().getName());
            return CreditReportResult.failed(new BusinessException(SystemErrorCode.INTEGRATION_ERROR), providerRequest, null);
        } catch (RuntimeException exception) {
            return CreditReportResult.failed(exception, providerRequest, null);
        }

        String providerResponse = toJson(response);

        if (response == null || response.getRespuesta() == null || response.getRespuesta().getPersona() == null
                || response.getRespuesta().getPersona().getEncabezado() == null) {
            log.error("Buró de Crédito response does not contain a credit report");
            return CreditReportResult.failed(new BusinessException(SystemErrorCode.INTEGRATION_ERROR),
                    providerRequest, providerResponse);
        }

        return CreditReportResult.success(
                mapper.toCreditReport(response.getRespuesta().getPersona()), providerRequest, providerResponse);
    }

    private CreditReportRequest toRequest(CreditReportInquiry inquiry) {
        Persona persona = Persona.builder()
                .encabezado(toEncabezado(inquiry.header()))
                .nombre(toNombre(inquiry.name()))
                .domicilios(inquiry.addresses().stream().map(this::toDomicilio).toList())
                .build();
        return CreditReportRequest.builder()
                .consulta(Consulta.builder().persona(persona).build())
                .build();
    }

    private Encabezado toEncabezado(InquiryHeader header) {
        return Encabezado.builder()
                .clavePais(countryCode)
                .claveUnidadMonetaria(currencyCode)
                .identificadorBuro(buroIdentifier)
                .idioma(language)
                .numeroReferenciaOperador(padOperatorReference(header.operatorReference()))
                .productoRequerido(ProductoRequerido.fromCodigo(header.requiredProduct()))
                .tipoConsulta(inquiryType)
                .tipoContrato(TipoContrato.valueOf(header.contractType()))
                .build();
    }

    private Nombre toNombre(CustomerName name) {
        return Nombre.builder()
                .apellidoPaterno(normalizeName(name.paternalLastName()))
                .apellidoMaterno(normalizeName(name.maternalLastName()))
                .primerNombre(normalizeName(name.firstName()))
                .rfc(name.rfc() == null ? null : name.rfc().trim().toUpperCase(Locale.ROOT))
                .build();
    }

    private Domicilio toDomicilio(CustomerAddress address) {
        return Domicilio.builder()
                .direccion1(normalizeStreet(address.street()))
                .delegacionMunicipio(normalizeAddress(address.municipality()))
                .ciudad(normalizeAddress(address.city()))
                .estado(Estado.valueOf(address.state()))
                .cp(address.postalCode())
                .codPais(CodigoPais.valueOf(address.countryCode()))
                .build();
    }

    private String toJson(Object value) {
        try {
            return objectWriter.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Buró de Crédito message could not be serialized", exception);
        }
    }

    private String toProviderResponse(RestClientResponseException exception) {
        String body = exception.getResponseBodyAsString();
        return body.isBlank() ? null : body;
    }

    private String padOperatorReference(String operatorReference) {
        String value = operatorReference == null ? "" : operatorReference.trim();
        return String.format("%" + OPERATOR_REFERENCE_LENGTH + "s", value);
    }

    private String normalizeName(String value) {
        return value == null ? null : collapseWhitespaces(toPlainUpperCase(value));
    }

    private String normalizeStreet(String value) {
        String street = normalizeAddress(value);
        return KNOWN_ADDRESS.equals(street) ? KNOWN_ADDRESS_WITHOUT_NUMBER : street;
    }

    private String normalizeAddress(String value) {
        if (value == null) {
            return null;
        }
        String normalized = WITHOUT_NUMBER_SLASH.matcher(toPlainUpperCase(value)).replaceAll(WITHOUT_NUMBER);
        normalized = ADDRESS_SYMBOLS.matcher(normalized).replaceAll(" ");
        return collapseWhitespaces(normalized);
    }

    private String toPlainUpperCase(String value) {
        String decomposed = Normalizer.normalize(value.toUpperCase(Locale.ROOT), Normalizer.Form.NFD);
        return DIACRITICAL_MARKS.matcher(decomposed).replaceAll("");
    }

    private String collapseWhitespaces(String value) {
        return WHITESPACES.matcher(value).replaceAll(" ").trim();
    }
}