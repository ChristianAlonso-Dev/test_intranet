package com.bradesco.godzilla.baas.buro.adapter.output.persistence;

import com.bradesco.godzilla.baas.buro.domain.model.log.CreditReportLog;
import com.bradesco.godzilla.baas.buro.port.output.ICreditReportLogPort;
import com.bradesco.godzilla.baas.commons.servicedataconnector.domain.credito.DetalleTransaccionReporteCredito;
import com.bradesco.godzilla.baas.commons.servicedataconnector.domain.credito.TransaccionReporteCredito;
import com.bradesco.godzilla.baas.commons.servicedataconnector.repository.credito.DetalleTransaccionReporteCreditoRepository;
import com.bradesco.godzilla.baas.commons.servicedataconnector.repository.credito.TransaccionReporteCreditoRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class CreditReportLogPersistenceAdapter implements ICreditReportLogPort {

    private final TransaccionReporteCreditoRepository transaccionRepository;
    private final DetalleTransaccionReporteCreditoRepository detalleRepository;

    public CreditReportLogPersistenceAdapter(
            TransaccionReporteCreditoRepository transaccionRepository,
            DetalleTransaccionReporteCreditoRepository detalleRepository) {
        this.transaccionRepository = transaccionRepository;
        this.detalleRepository = detalleRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByRequestId(String requestId) {
        return transaccionRepository.existsByIdTransaccionReporteCredito(requestId);
    }

    @Override
    @Transactional
    public void save(CreditReportLog creditReportLog) {
        TransaccionReporteCredito transaccion = transaccionRepository.save(toTransaccion(creditReportLog));
        detalleRepository.save(toDetalle(transaccion, creditReportLog));
    }

    private TransaccionReporteCredito toTransaccion(CreditReportLog creditReportLog) {
        TransaccionReporteCredito transaccion = new TransaccionReporteCredito();
        transaccion.setIdTransaccionReporteCredito(creditReportLog.getRequestId());
        transaccion.setIdProspecto(Long.valueOf(creditReportLog.getCustomerId()));
        transaccion.setRfc(creditReportLog.getRfc());
        transaccion.setProductoRequerido(creditReportLog.getRequiredProduct());
        transaccion.setNumeroReferenciaOperador(creditReportLog.getOperatorReference());
        transaccion.setCanal(creditReportLog.getChannelId());
        transaccion.setTipoCanal(creditReportLog.getChannelType());
        transaccion.setGeoLocalizacion(creditReportLog.getGeoLocation());
        transaccion.setTraceparent(creditReportLog.getTraceparent());
        transaccion.setFechaSolicitud(creditReportLog.getRequestedAt());
        return transaccion;
    }

    private DetalleTransaccionReporteCredito toDetalle(
            TransaccionReporteCredito transaccion, CreditReportLog creditReportLog) {
        DetalleTransaccionReporteCredito detalle = new DetalleTransaccionReporteCredito();
        detalle.setTransaccionReporteCredito(transaccion);
        detalle.setSolicitudProveedor(creditReportLog.getProviderRequest());
        detalle.setRespuestaProveedor(creditReportLog.getProviderResponse());
        return detalle;
    }
}
