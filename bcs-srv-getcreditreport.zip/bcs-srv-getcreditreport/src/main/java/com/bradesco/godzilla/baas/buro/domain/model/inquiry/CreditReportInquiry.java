package com.bradesco.godzilla.baas.buro.domain.model.inquiry;

import java.util.List;

public record CreditReportInquiry(
        InquiryHeader header,
        CustomerName name,
        List<CustomerAddress> addresses
) {

    public CreditReportInquiry {
        addresses = addresses == null ? List.of() : List.copyOf(addresses);
    }
}
