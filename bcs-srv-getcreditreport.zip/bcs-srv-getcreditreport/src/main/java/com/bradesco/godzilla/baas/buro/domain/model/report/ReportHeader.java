package com.bradesco.godzilla.baas.buro.domain.model.report;


public record ReportHeader(
        String countryCode,
        String buroIdentifier,
        String operatorReference,
        String memberCode,
        String primaryConsumerReturnCode,
        String secondaryConsumerReturnCode,
        String queryControlNumber
) {
}
