package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroPersonDto(
        @JsonProperty("encabezado") BuroHeaderDto header,
        @JsonProperty("nombre") BuroNameDto name,
        @JsonProperty("domicilios") List<BuroAddressDto> addresses,
        @JsonProperty("empleos") List<BuroEmploymentDto> employments,
        @JsonProperty("cuentas") List<BuroAccountDto> accounts,
        @JsonProperty("consultaEfectuadas") List<BuroInquiryDto> inquiries,
        @JsonProperty("resumenReporte") List<BuroReportSummaryDto> reportSummary,
        @JsonProperty("hawkAlertConsulta") List<BuroHawkAlertDto> hawkAlertInquiry,
        @JsonProperty("hawkAlertBD") List<BuroHawkAlertDto> hawkAlertDatabase,
        @JsonProperty("declaracionesCliente") BuroConsumerStatementDto consumerStatements,
        @JsonProperty("scoreBuroCredito") List<BuroScoreDto> scores,
        @JsonProperty("error") ErrorSegment error
) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ErrorSegment(
            @JsonProperty("ur") BuroUserErrorDto userError
    ) {
    }
}
