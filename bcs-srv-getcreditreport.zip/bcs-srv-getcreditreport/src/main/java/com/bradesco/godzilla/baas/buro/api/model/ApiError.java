package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * ApiError
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class ApiError {

  private ApiErrorApiError apiError;

  public ApiError() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public ApiError(ApiErrorApiError apiError) {
    this.apiError = apiError;
  }

  public ApiError apiError(ApiErrorApiError apiError) {
    this.apiError = apiError;
    return this;
  }

  /**
   * Get apiError
   * @return apiError
  */
  @NotNull @Valid 
  @Schema(name = "apiError", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("apiError")
  public ApiErrorApiError getApiError() {
    return apiError;
  }

  public void setApiError(ApiErrorApiError apiError) {
    this.apiError = apiError;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApiError apiError = (ApiError) o;
    return Objects.equals(this.apiError, apiError.apiError);
  }

  @Override
  public int hashCode() {
    return Objects.hash(apiError);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApiError {\n");
    sb.append("    apiError: ").append(toIndentedString(apiError)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

