package com.bradesco.godzilla.baas.buro.adapter.output.buro.mapper;

import com.bradesco.godzilla.baas.buro.domain.model.report.ConsumerStatement;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;
import com.bradesco.godzilla.baas.buro.domain.model.report.HawkAlert;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportAccount;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportAddress;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportEmployment;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportHeader;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportInquiry;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportName;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportScore;
import com.bradesco.godzilla.baas.buro.domain.model.report.ReportSummary;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.ConsultaEfectuada;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.Cuenta;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.DeclaracionesCliente;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.Domicilio;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.Empleo;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.Encabezado;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.HawkAlertBD;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.HawkAlertConsulta;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.Nombre;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.Persona;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.ResumenReporte;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.ScoreBuroCredito;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface BuroCreditReportMapper {

    @Mapping(target = "header", source = "encabezado")
    @Mapping(target = "name", source = "nombre")
    @Mapping(target = "addresses", source = "domicilios")
    @Mapping(target = "employments", source = "empleos")
    @Mapping(target = "accounts", source = "cuentas")
    @Mapping(target = "inquiries", source = "consultaEfectuadas")
    @Mapping(target = "reportSummary", source = "resumenReporte")
    @Mapping(target = "hawkAlertInquiry", source = "hawkAlertConsulta")
    @Mapping(target = "hawkAlertDatabase", source = "hawkAlertBD")
    @Mapping(target = "consumerStatements", source = "declaracionesCliente")
    @Mapping(target = "scores", source = "scoreBuroCredito")
    CreditReport toCreditReport(Persona persona);

    @Mapping(target = "countryCode", source = "clavePais")
    @Mapping(target = "buroIdentifier", source = "identificadorBuro")
    @Mapping(target = "operatorReference", source = "numeroReferenciaOperador")
    @Mapping(target = "memberCode", source = "claveOtorgante")
    @Mapping(target = "primaryConsumerReturnCode", source = "claveRetornoConsumidorPrincipal")
    @Mapping(target = "secondaryConsumerReturnCode", source = "claveRetornoConsumidorSecundario")
    @Mapping(target = "queryControlNumber", source = "numeroControlConsulta")
    ReportHeader toHeader(Encabezado header);

    @Mapping(target = "paternalLastName", source = "apellidoPaterno")
    @Mapping(target = "maternalLastName", source = "apellidoMaterno")
    @Mapping(target = "additionalLastName", source = "apellidoAdicional")
    @Mapping(target = "firstName", source = "primerNombre")
    @Mapping(target = "secondName", source = "segundoNombre")
    @Mapping(target = "birthDate", source = "fechaNacimiento")
    @Mapping(target = "prefix", source = "prefijo")
    @Mapping(target = "suffix", source = "sufijo")
    @Mapping(target = "nationality", source = "nacionalidad")
    @Mapping(target = "residenceType", source = "residencia")
    @Mapping(target = "driverLicenseNumber", source = "numeroLicenciaConducir")
    @Mapping(target = "maritalStatus", source = "estadoCivil")
    @Mapping(target = "gender", source = "sexo")
    @Mapping(target = "professionalLicenseNumber", source = "numeroCedulaProfesional")
    @Mapping(target = "voterRegistrationNumber", source = "numeroRegistroElectoral")
    @Mapping(target = "otherCountryCode", source = "claveOtroPais")
    @Mapping(target = "dependentsNumber", source = "numeroDependientes")
    @Mapping(target = "dependentsAges", source = "edadesDependientes")
    @Mapping(target = "dependentsInformationDate", source = "fechaRecepcionInformacionDependientes")
    @Mapping(target = "deathDate", source = "fechaDefuncion")
    @Mapping(target = "foreignTaxId", source = "claveImpuestosOtroPais")
    ReportName toName(Nombre name);

    @Mapping(target = "addressLine1", source = "direccion1")
    @Mapping(target = "addressLine2", source = "direccion2")
    @Mapping(target = "neighborhood", source = "coloniaPoblacion")
    @Mapping(target = "municipality", source = "delegacionMunicipio")
    @Mapping(target = "city", source = "ciudad")
    @Mapping(target = "state", source = "estado")
    @Mapping(target = "postalCode", source = "cp")
    @Mapping(target = "residenceDate", source = "fechaResidencia")
    @Mapping(target = "phoneNumber", source = "numeroTelefono")
    @Mapping(target = "addressType", source = "tipoDomicilio")
    @Mapping(target = "specialAddressIndicator", source = "indicadorEspecialDomicilio")
    @Mapping(target = "addressReportDate", source = "fechaReporteDireccion")
    @Mapping(target = "countryCode", source = "codPais")
    ReportAddress toAddress(Domicilio address);

    @Mapping(target = "companyName", source = "nombreEmpresa")
    @Mapping(target = "addressLine1", source = "direccion1")
    @Mapping(target = "addressLine2", source = "direccion2")
    @Mapping(target = "neighborhood", source = "coloniaPoblacion")
    @Mapping(target = "municipality", source = "delegacionMunicipio")
    @Mapping(target = "city", source = "ciudad")
    @Mapping(target = "state", source = "estado")
    @Mapping(target = "postalCode", source = "cp")
    @Mapping(target = "phoneNumber", source = "numeroTelefono")
    @Mapping(target = "position", source = "cargo")
    @Mapping(target = "hireDate", source = "fechaContratacion")
    @Mapping(target = "salaryCurrency", source = "claveMonedaSalario")
    @Mapping(target = "salary", source = "salario")
    @Mapping(target = "salaryPeriod", source = "baseSalarial")
    @Mapping(target = "employeeNumber", source = "numeroEmpleado")
    @Mapping(target = "lastEmploymentDate", source = "fechaUltimoDiaEmpleo")
    @Mapping(target = "employmentReportDate", source = "fechaReportoEmpleo")
    @Mapping(target = "verificationDate", source = "fechaVerificacion")
    @Mapping(target = "verificationMode", source = "modoVerificacion")
    @Mapping(target = "countryCode", source = "codPais")
    ReportEmployment toEmployment(Empleo employment);

    @Mapping(target = "updateDate", source = "fechaActualizacion")
    @Mapping(target = "disputedRecord", source = "registroImpugnado")
    @Mapping(target = "memberCode", source = "claveOtorgante")
    @Mapping(target = "grantorName", source = "nombreOtorgante")
    @Mapping(target = "grantorPhoneNumber", source = "numeroTelefono")
    @Mapping(target = "accountNumber", source = "numeroCuentaActual")
    @Mapping(target = "responsibilityType", source = "indicadorTipoResponsabilidad")
    @Mapping(target = "accountType", source = "tipoCuenta")
    @Mapping(target = "contractType", source = "tipoContrato")
    @Mapping(target = "currencyCode", source = "claveUnidadMonetaria")
    @Mapping(target = "assetValuationAmount", ignore = true)
    @Mapping(target = "paymentsNumber", source = "numeroPagos")
    @Mapping(target = "paymentFrequency", source = "frecuenciaPagos")
    @Mapping(target = "paymentAmount", source = "montoPagar")
    @Mapping(target = "openingDate", source = "fechaAperturaCuenta")
    @Mapping(target = "lastPaymentDate", source = "fechaUltimoPago")
    @Mapping(target = "lastPurchaseDate", source = "fechaUltimaCompra")
    @Mapping(target = "closingDate", source = "fechaCierreCuenta")
    @Mapping(target = "reportDate", source = "fechaReporte")
    @Mapping(target = "reportingMode", source = "modoReportar")
    @Mapping(target = "lastZeroBalanceDate", source = "ultimaFechaSaldoCero")
    @Mapping(target = "guarantee", source = "garantia")
    @Mapping(target = "maximumCredit", source = "creditoMaximo")
    @Mapping(target = "currentBalance", source = "saldoActual")
    @Mapping(target = "creditLimit", source = "limiteCredito")
    @Mapping(target = "pastDueBalance", source = "saldoVencido")
    @Mapping(target = "pastDuePaymentsNumber", source = "numeroPagosVencidos")
    @Mapping(target = "paymentHistory", source = "historicoPagos")
    @Mapping(target = "paymentHistoryMostRecentDate", source = "fechaMasRecienteHistoricoPagos")
    @Mapping(target = "paymentHistoryOldestDate", source = "fechaMasAntiguaHistoricoPagos")
    @Mapping(target = "observationCode", source = "claveObservacion")
    @Mapping(target = "totalReportedPayments", source = "totalPagosReportados")
    @Mapping(target = "totalPaymentsMop2", source = "totalPagosCalificadosMOP2")
    @Mapping(target = "totalPaymentsMop3", source = "totalPagosCalificadosMOP3")
    @Mapping(target = "totalPaymentsMop4", source = "totalPagosCalificadosMOP4")
    @Mapping(target = "totalPaymentsMop5", ignore = true)
    @Mapping(target = "worstDelinquencyBalance", source = "importeSaldoMorosidadHistMasGrave")
    @Mapping(target = "worstDelinquencyDate", source = "fechaHistoricaMorosidadMasGrave")
    @Mapping(target = "restructuringStartDate", ignore = true)
    @Mapping(target = "lastPaymentAmount", source = "montoUltimoPago")
    @Mapping(target = "email", source = "correoElectronico")
    @Mapping(target = "creditIdentifier", source = "identificadorCredito")
    @Mapping(target = "canIdentifier", source = "identificadorCAN")
    @Mapping(target = "canOpeningDate", source = "fechaAperturaCAN")
    @Mapping(target = "canCancellationDate", source = "fechaCancelacionCAN")
    @Mapping(target = "canHistory", source = "historicoCAN")
    @Mapping(target = "canHistoryMostRecentDate", source = "fechaMasRecienteHistoricoCAN")
    @Mapping(target = "canHistoryOldestDate", source = "fechaMasAntiguaHistoricoCAN")
    @Mapping(target = "currentPaymentStatus", ignore = true)
    @Mapping(target = "creditBureauIdentifier", source = "identificadorSociedadInformacionCrediticia")
    @Mapping(target = "worstDelinquencyMop", source = "mopHistoricoMorosidadMasGrave")
    ReportAccount toAccount(Cuenta account);

    @Mapping(target = "inquiryDate", source = "fechaConsulta")
    @Mapping(target = "memberCode", source = "claveOtorgante")
    @Mapping(target = "grantorName", source = "nombreOtorgante")
    @Mapping(target = "grantorPhoneNumber", ignore = true)
    @Mapping(target = "contractType", source = "tipoContrato")
    @Mapping(target = "contractAmount", source = "importeContrato")
    @Mapping(target = "responsibilityType", source = "indicadorTipoResponsabilidad")
    @Mapping(target = "newConsumer", source = "consumidorNuevo")
    @Mapping(target = "currencyCode", source = "claveUnidadMonetaria")
    @Mapping(target = "buroIdentification", ignore = true)
    @Mapping(target = "inquirySourceIdentifier", source = "identificadorOrigenConsulta")
    @Mapping(target = "finalResult", ignore = true)
    ReportInquiry toInquiry(ConsultaEfectuada inquiry);

    @Mapping(target = "databaseEntryDate", source = "fechaIngresoBD")
    @Mapping(target = "accountsMop7", source = "numeroMOP7")
    @Mapping(target = "accountsMop6", source = "numeroMOP6")
    @Mapping(target = "accountsMop5", source = "numeroMOP5")
    @Mapping(target = "accountsMop4", source = "numeroMOP4")
    @Mapping(target = "accountsMop3", source = "numeroMOP3")
    @Mapping(target = "accountsMop2", source = "numeroMOP2")
    @Mapping(target = "accountsMop1", source = "numeroMOP1")
    @Mapping(target = "accountsMop0", source = "numeroMOP0")
    @Mapping(target = "accountsMopUr", source = "numeroMOPUR")
    @Mapping(target = "totalAccounts", source = "numeroCuentas")
    @Mapping(target = "fixedPaymentMortgageAccounts", source = "cuentasPagosFijosHipotecas")
    @Mapping(target = "openRevolvingAccounts", source = "cuentasRevolventesAbiertas")
    @Mapping(target = "closedAccounts", source = "cuentasCerradas")
    @Mapping(target = "currentNegativeAccounts", source = "cuentasNegativasActuales")
    @Mapping(target = "negativeHistoryAccounts", source = "cuentasClavesHistoriaNegativa")
    @Mapping(target = "disputedAccounts", source = "cuentasDisputa")
    @Mapping(target = "newAddressLast60Days", source = "nuevaDireccionReportadaUltimos60Dias")
    @Mapping(target = "alertMessages", source = "mensajesAlerta")
    @Mapping(target = "currencyCode", source = "tipoMoneda")
    @Mapping(target = "revolvingTotalMaximumCredit", source = "totalCreditosMaximosRevolventes")
    @Mapping(target = "revolvingTotalCreditLimit", source = "totalLimitesCreditoRevolventes")
    @Mapping(target = "revolvingTotalCurrentBalance", source = "totalSaldosActualesRevolventes")
    @Mapping(target = "revolvingTotalPastDueBalance", source = "totalSaldosVencidosRevolventes")
    @Mapping(target = "revolvingTotalPayments", source = "totalPagosRevolventes")
    @Mapping(target = "revolvingCreditLimitUsedPercentage", source = "pctLimiteCreditoUtilizadoRevolventes")
    @Mapping(target = "accountsMop96", source = "numeroMOP96")
    @Mapping(target = "accountsMop97", source = "numeroMOP97")
    @Mapping(target = "accountsMop99", source = "numeroMOP99")
    @Mapping(target = "oldestAccountOpeningDate", source = "fechaAperturaCuentaMasAntigua")
    @Mapping(target = "newestAccountOpeningDate", source = "fechaAperturaCuentaMasReciente")
    @Mapping(target = "totalInquiries", source = "totalSolicitudesReporte")
    @Mapping(target = "mostRecentInquiryDate", source = "fechaSolicitudReporteMasReciente")
    @Mapping(target = "collectionAgencyAccounts", source = "numeroTotalCuentasDespachoCobranza")
    @Mapping(target = "collectionAgencyNewestAccountOpeningDate", source = "fechaAperturaCuentaMasRecienteDespachoCobranza")
    @Mapping(target = "collectionAgencyInquiries", source = "numeroTotalSolicitudesDespachosCobranza")
    @Mapping(target = "collectionAgencyMostRecentInquiryDate", source = "fechaSolicitudMasRecienteDespachoCobranza")
    @Mapping(target = "consumerStatementExists", source = "existenciaDeclaracionesConsumidor")
    @Mapping(target = "inquiriesLast6Months", source = "numeroSolicitudesUltimos6Meses")
    @Mapping(target = "fixedPaymentTotalMaximumCredit", source = "totalCreditosMaximosPagosFijos")
    @Mapping(target = "fixedPaymentTotalPastDueBalance", source = "totalSaldosVencidosPagosFijos")
    @Mapping(target = "fixedPaymentTotalPayments", source = "totalPagosPagosFijos")
    @Mapping(target = "fixedPaymentTotalCurrentBalance", source = "totalSaldosActualesPagosFijos")
    ReportSummary toReportSummary(ResumenReporte reportSummary);

    @Mapping(target = "reportDate", source = "fechaReporte")
    @Mapping(target = "keyCode", source = "codigoClave")
    @Mapping(target = "institutionType", source = "tipoInstitucion")
    @Mapping(target = "message", source = "mensaje")
    HawkAlert toHawkAlert(HawkAlertConsulta hawkAlert);

    @Mapping(target = "reportDate", source = "fechaReporte")
    @Mapping(target = "keyCode", source = "codigoClave")
    @Mapping(target = "institutionType", source = "tipoInstitucion")
    @Mapping(target = "message", source = "mensaje")
    HawkAlert toHawkAlert(HawkAlertBD hawkAlert);

    @Mapping(target = "consumerStatement", source = "declaracionConsumidor")
    ConsumerStatement toConsumerStatement(DeclaracionesCliente consumerStatement);

    @Mapping(target = "scoreName", source = "nombreScore")
    @Mapping(target = "scoreCode", source = "codigoScore")
    @Mapping(target = "scoreValue", source = "valorScore")
    @Mapping(target = "reasonCodes", source = "codigoRazon")
    @Mapping(target = "errorCode", source = "codigoError")
    ReportScore toScore(ScoreBuroCredito score);
}