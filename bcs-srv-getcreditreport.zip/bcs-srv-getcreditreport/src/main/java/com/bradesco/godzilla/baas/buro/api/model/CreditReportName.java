package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Customer name. If a required field is missing or incorrect, the record is rejected.
 */

@Schema(name = "creditReportName", description = "Customer name. If a required field is missing or incorrect, the record is rejected.")
@JsonTypeName("creditReportName")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class CreditReportName {

  private String paternalLastName;

  private String maternalLastName;

  private String firstName;

  private String rfc;

  public CreditReportName() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public CreditReportName(String paternalLastName, String maternalLastName, String firstName) {
    this.paternalLastName = paternalLastName;
    this.maternalLastName = maternalLastName;
    this.firstName = firstName;
  }

  public CreditReportName paternalLastName(String paternalLastName) {
    this.paternalLastName = paternalLastName;
    return this;
  }

  /**
   * Complete paternal last name, without abbreviations, special characters or prefixes.
   * @return paternalLastName
  */
  @NotNull @Pattern(regexp = "^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+( [A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*$") @Size(min = 2, max = 26) 
  @Schema(name = "paternalLastName", example = "PRUEBA", description = "Complete paternal last name, without abbreviations, special characters or prefixes.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("paternalLastName")
  public String getPaternalLastName() {
    return paternalLastName;
  }

  public void setPaternalLastName(String paternalLastName) {
    this.paternalLastName = paternalLastName;
  }

  public CreditReportName maternalLastName(String maternalLastName) {
    this.maternalLastName = maternalLastName;
    return this;
  }

  /**
   * Complete maternal last name, same rules as the paternal last name. If the person has only one last name, send NO PROPORCIONADO.
   * @return maternalLastName
  */
  @NotNull @Pattern(regexp = "^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+( [A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*$") @Size(min = 2, max = 26) 
  @Schema(name = "maternalLastName", example = "UNO", description = "Complete maternal last name, same rules as the paternal last name. If the person has only one last name, send NO PROPORCIONADO.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("maternalLastName")
  public String getMaternalLastName() {
    return maternalLastName;
  }

  public void setMaternalLastName(String maternalLastName) {
    this.maternalLastName = maternalLastName;
  }

  public CreditReportName firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * First name, without abbreviations, spaces or special characters. At least 2 letters.
   * @return firstName
  */
  @NotNull @Pattern(regexp = "^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+$") @Size(min = 2, max = 26) 
  @Schema(name = "firstName", example = "JUAN", description = "First name, without abbreviations, spaces or special characters. At least 2 letters.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("firstName")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public CreditReportName rfc(String rfc) {
    this.rfc = rfc;
    return this;
  }

  /**
   * Customer RFC: at least the first 10 positions (AAAANNNNNN) and, if possible, the 3-character homoclave. Required for accounts opened after January 1998.
   * @return rfc
  */
  @Pattern(regexp = "^[A-Za-z]{4}[0-9]{6}([A-Za-z0-9]{3})?$") @Size(min = 10, max = 13) 
  @Schema(name = "rfc", example = "NOPX800101XXX", description = "Customer RFC: at least the first 10 positions (AAAANNNNNN) and, if possible, the 3-character homoclave. Required for accounts opened after January 1998.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rfc")
  public String getRfc() {
    return rfc;
  }

  public void setRfc(String rfc) {
    this.rfc = rfc;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CreditReportName creditReportName = (CreditReportName) o;
    return Objects.equals(this.paternalLastName, creditReportName.paternalLastName) &&
        Objects.equals(this.maternalLastName, creditReportName.maternalLastName) &&
        Objects.equals(this.firstName, creditReportName.firstName) &&
        Objects.equals(this.rfc, creditReportName.rfc);
  }

  @Override
  public int hashCode() {
    return Objects.hash(paternalLastName, maternalLastName, firstName, rfc);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CreditReportName {\n");
    sb.append("    paternalLastName: ").append(toIndentedString(paternalLastName)).append("\n");
    sb.append("    maternalLastName: ").append(toIndentedString(maternalLastName)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    rfc: ").append(toIndentedString(rfc)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

