package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroNameDto(
        @JsonProperty("apellidoPaterno") String paternalLastName,
        @JsonProperty("apellidoMaterno") String maternalLastName,
        @JsonProperty("apellidoAdicional") String additionalLastName,
        @JsonProperty("primerNombre") String firstName,
        @JsonProperty("segundoNombre") String secondName,
        @JsonProperty("fechaNacimiento") String birthDate,
        @JsonProperty("rfc") String rfc,
        @JsonProperty("prefijo") String prefix,
        @JsonProperty("sufijo") String suffix,
        @JsonProperty("nacionalidad") String nationality,
        @JsonProperty("residencia") String residenceType,
        @JsonProperty("numeroLicenciaConducir") String driverLicenseNumber,
        @JsonProperty("estadoCivil") String maritalStatus,
        @JsonProperty("sexo") String gender,
        @JsonProperty("numeroCedulaProfesional") String professionalLicenseNumber,
        @JsonProperty("numeroRegistroElectoral") String voterRegistrationNumber,
        @JsonProperty("claveOtroPais") String otherCountryCode,
        @JsonProperty("numeroDependientes") String dependentsNumber,
        @JsonProperty("edadesDependientes") String dependentsAges,
        @JsonProperty("fechaRecepcionInformacionDependientes") String dependentsInformationDate,
        @JsonProperty("fechaDefuncion") String deathDate,
        @JsonProperty("claveImpuestosOtroPais") String foreignTaxId
) {
}
