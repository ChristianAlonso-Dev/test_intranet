package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * BuroResponse
 */

@JsonTypeName("buroResponse")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroResponse {

  private BuroPerson person;

  public BuroResponse person(BuroPerson person) {
    this.person = person;
    return this;
  }

  /**
   * Get person
   * @return person
  */
  @Valid 
  @Schema(name = "person", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("person")
  public BuroPerson getPerson() {
    return person;
  }

  public void setPerson(BuroPerson person) {
    this.person = person;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroResponse buroResponse = (BuroResponse) o;
    return Objects.equals(this.person, buroResponse.person);
  }

  @Override
  public int hashCode() {
    return Objects.hash(person);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroResponse {\n");
    sb.append("    person: ").append(toIndentedString(person)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

