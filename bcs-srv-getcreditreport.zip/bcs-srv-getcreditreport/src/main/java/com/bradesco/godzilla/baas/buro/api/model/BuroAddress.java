package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Customer address.
 */

@Schema(name = "buroAddress", description = "Customer address.")
@JsonTypeName("buroAddress")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroAddress {

  private String addressLine1;

  private String addressLine2;

  private String neighborhood;

  private String municipality;

  private String city;

  private String state;

  private String postalCode;

  private String residenceDate;

  private String phoneNumber;

  private String extension;

  private String fax;

  private String addressType;

  private String specialAddressIndicator;

  private String addressReportDate;

  private String countryCode;

  public BuroAddress addressLine1(String addressLine1) {
    this.addressLine1 = addressLine1;
    return this;
  }

  /**
   * Address line 1.
   * @return addressLine1
  */
  @Size(max = 40) 
  @Schema(name = "addressLine1", example = "JAIME BALMES 8", description = "Address line 1.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addressLine1")
  public String getAddressLine1() {
    return addressLine1;
  }

  public void setAddressLine1(String addressLine1) {
    this.addressLine1 = addressLine1;
  }

  public BuroAddress addressLine2(String addressLine2) {
    this.addressLine2 = addressLine2;
    return this;
  }

  /**
   * Address line 2.
   * @return addressLine2
  */
  @Size(max = 40) 
  @Schema(name = "addressLine2", example = "DEPTO 001", description = "Address line 2.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addressLine2")
  public String getAddressLine2() {
    return addressLine2;
  }

  public void setAddressLine2(String addressLine2) {
    this.addressLine2 = addressLine2;
  }

  public BuroAddress neighborhood(String neighborhood) {
    this.neighborhood = neighborhood;
    return this;
  }

  /**
   * Neighborhood (colonia) or town.
   * @return neighborhood
  */
  @Size(max = 40) 
  @Schema(name = "neighborhood", example = "LOS MORALES", description = "Neighborhood (colonia) or town.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("neighborhood")
  public String getNeighborhood() {
    return neighborhood;
  }

  public void setNeighborhood(String neighborhood) {
    this.neighborhood = neighborhood;
  }

  public BuroAddress municipality(String municipality) {
    this.municipality = municipality;
    return this;
  }

  /**
   * Mayor's office (Alcaldía) or municipality.
   * @return municipality
  */
  @Size(max = 40) 
  @Schema(name = "municipality", example = "MIGUEL HIDALGO", description = "Mayor's office (Alcaldía) or municipality.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("municipality")
  public String getMunicipality() {
    return municipality;
  }

  public void setMunicipality(String municipality) {
    this.municipality = municipality;
  }

  public BuroAddress city(String city) {
    this.city = city;
    return this;
  }

  /**
   * City.
   * @return city
  */
  @Size(max = 40) 
  @Schema(name = "city", example = "MEXICO", description = "City.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("city")
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public BuroAddress state(String state) {
    this.state = state;
    return this;
  }

  /**
   * State code (Annex 6).
   * @return state
  */
  @Size(max = 4) 
  @Schema(name = "state", example = "CDMX", description = "State code (Annex 6).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("state")
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public BuroAddress postalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Postal code.
   * @return postalCode
  */
  @Size(max = 5) 
  @Schema(name = "postalCode", example = "11230", description = "Postal code.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("postalCode")
  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public BuroAddress residenceDate(String residenceDate) {
    this.residenceDate = residenceDate;
    return this;
  }

  /**
   * Date since the Customer has lived at the address (DDMMAAAA).
   * @return residenceDate
  */
  @Size(max = 8) 
  @Schema(name = "residenceDate", description = "Date since the Customer has lived at the address (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("residenceDate")
  public String getResidenceDate() {
    return residenceDate;
  }

  public void setResidenceDate(String residenceDate) {
    this.residenceDate = residenceDate;
  }

  public BuroAddress phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

  /**
   * Home telephone. Area code + up to 8 digits.
   * @return phoneNumber
  */
  @Size(max = 11) 
  @Schema(name = "phoneNumber", description = "Home telephone. Area code + up to 8 digits.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public BuroAddress extension(String extension) {
    this.extension = extension;
    return this;
  }

  /**
   * Telephone extension.
   * @return extension
  */
  @Size(max = 8) 
  @Schema(name = "extension", description = "Telephone extension.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("extension")
  public String getExtension() {
    return extension;
  }

  public void setExtension(String extension) {
    this.extension = extension;
  }

  public BuroAddress fax(String fax) {
    this.fax = fax;
    return this;
  }

  /**
   * Fax number. Area code + up to 8 digits.
   * @return fax
  */
  @Size(max = 11) 
  @Schema(name = "fax", description = "Fax number. Area code + up to 8 digits.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fax")
  public String getFax() {
    return fax;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public BuroAddress addressType(String addressType) {
    this.addressType = addressType;
    return this;
  }

  /**
   * Address type: B = Business, C = User's address, H = Home, P = Post office box.
   * @return addressType
  */
  @Size(max = 1) 
  @Schema(name = "addressType", description = "Address type: B = Business, C = User's address, H = Home, P = Post office box.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addressType")
  public String getAddressType() {
    return addressType;
  }

  public void setAddressType(String addressType) {
    this.addressType = addressType;
  }

  public BuroAddress specialAddressIndicator(String specialAddressIndicator) {
    this.specialAddressIndicator = specialAddressIndicator;
    return this;
  }

  /**
   * Location type: M = Military, R = Rural, K = Known address.
   * @return specialAddressIndicator
  */
  @Size(max = 1) 
  @Schema(name = "specialAddressIndicator", description = "Location type: M = Military, R = Rural, K = Known address.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("specialAddressIndicator")
  public String getSpecialAddressIndicator() {
    return specialAddressIndicator;
  }

  public void setSpecialAddressIndicator(String specialAddressIndicator) {
    this.specialAddressIndicator = specialAddressIndicator;
  }

  public BuroAddress addressReportDate(String addressReportDate) {
    this.addressReportDate = addressReportDate;
    return this;
  }

  /**
   * Date the address was reported to Buró de Crédito (DDMMAAAA).
   * @return addressReportDate
  */
  @Size(max = 8) 
  @Schema(name = "addressReportDate", example = "01092022", description = "Date the address was reported to Buró de Crédito (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("addressReportDate")
  public String getAddressReportDate() {
    return addressReportDate;
  }

  public void setAddressReportDate(String addressReportDate) {
    this.addressReportDate = addressReportDate;
  }

  public BuroAddress countryCode(String countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Country of origin of the address (Annex 5).
   * @return countryCode
  */
  @Size(max = 2) 
  @Schema(name = "countryCode", example = "MX", description = "Country of origin of the address (Annex 5).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("countryCode")
  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroAddress buroAddress = (BuroAddress) o;
    return Objects.equals(this.addressLine1, buroAddress.addressLine1) &&
        Objects.equals(this.addressLine2, buroAddress.addressLine2) &&
        Objects.equals(this.neighborhood, buroAddress.neighborhood) &&
        Objects.equals(this.municipality, buroAddress.municipality) &&
        Objects.equals(this.city, buroAddress.city) &&
        Objects.equals(this.state, buroAddress.state) &&
        Objects.equals(this.postalCode, buroAddress.postalCode) &&
        Objects.equals(this.residenceDate, buroAddress.residenceDate) &&
        Objects.equals(this.phoneNumber, buroAddress.phoneNumber) &&
        Objects.equals(this.extension, buroAddress.extension) &&
        Objects.equals(this.fax, buroAddress.fax) &&
        Objects.equals(this.addressType, buroAddress.addressType) &&
        Objects.equals(this.specialAddressIndicator, buroAddress.specialAddressIndicator) &&
        Objects.equals(this.addressReportDate, buroAddress.addressReportDate) &&
        Objects.equals(this.countryCode, buroAddress.countryCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(addressLine1, addressLine2, neighborhood, municipality, city, state, postalCode, residenceDate, phoneNumber, extension, fax, addressType, specialAddressIndicator, addressReportDate, countryCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroAddress {\n");
    sb.append("    addressLine1: ").append(toIndentedString(addressLine1)).append("\n");
    sb.append("    addressLine2: ").append(toIndentedString(addressLine2)).append("\n");
    sb.append("    neighborhood: ").append(toIndentedString(neighborhood)).append("\n");
    sb.append("    municipality: ").append(toIndentedString(municipality)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    residenceDate: ").append(toIndentedString(residenceDate)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    extension: ").append(toIndentedString(extension)).append("\n");
    sb.append("    fax: ").append(toIndentedString(fax)).append("\n");
    sb.append("    addressType: ").append(toIndentedString(addressType)).append("\n");
    sb.append("    specialAddressIndicator: ").append(toIndentedString(specialAddressIndicator)).append("\n");
    sb.append("    addressReportDate: ").append(toIndentedString(addressReportDate)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

