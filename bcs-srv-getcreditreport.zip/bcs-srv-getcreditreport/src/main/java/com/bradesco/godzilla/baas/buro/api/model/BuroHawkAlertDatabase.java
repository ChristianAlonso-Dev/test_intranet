package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Hawk alert based on the Customer&#39;s file data.
 */

@Schema(name = "buroHawkAlertDatabase", description = "Hawk alert based on the Customer's file data.")
@JsonTypeName("buroHawkAlertDatabase")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroHawkAlertDatabase {

  private String reportDate;

  private String keyCode;

  private String institutionType;

  private String message;

  public BuroHawkAlertDatabase reportDate(String reportDate) {
    this.reportDate = reportDate;
    return this;
  }

  /**
   * Date the possible fraud was reported in Hawk (DDMMAAAA).
   * @return reportDate
  */
  @Size(max = 8) 
  @Schema(name = "reportDate", example = "29122015", description = "Date the possible fraud was reported in Hawk (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reportDate")
  public String getReportDate() {
    return reportDate;
  }

  public void setReportDate(String reportDate) {
    this.reportDate = reportDate;
  }

  public BuroHawkAlertDatabase keyCode(String keyCode) {
    this.keyCode = keyCode;
    return this;
  }

  /**
   * Code to classify the prevention.
   * @return keyCode
  */
  @Size(max = 3) 
  @Schema(name = "keyCode", example = "890", description = "Code to classify the prevention.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("keyCode")
  public String getKeyCode() {
    return keyCode;
  }

  public void setKeyCode(String keyCode) {
    this.keyCode = keyCode;
  }

  public BuroHawkAlertDatabase institutionType(String institutionType) {
    this.institutionType = institutionType;
    return this;
  }

  /**
   * Generic name of the reporting User (e.g. OFAC, Banco). CLV OBS EN PF = observation code FD or RI matched.
   * @return institutionType
  */
  @Size(max = 16) 
  @Schema(name = "institutionType", example = "BURO DE CREDITO ", description = "Generic name of the reporting User (e.g. OFAC, Banco). CLV OBS EN PF = observation code FD or RI matched.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("institutionType")
  public String getInstitutionType() {
    return institutionType;
  }

  public void setInstitutionType(String institutionType) {
    this.institutionType = institutionType;
  }

  public BuroHawkAlertDatabase message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Prevention description (Annex 8).
   * @return message
  */
  @Size(max = 48) 
  @Schema(name = "message", example = "COLONIA NO COINCIDE CON CODIGO POSTAL 38400", description = "Prevention description (Annex 8).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroHawkAlertDatabase buroHawkAlertDatabase = (BuroHawkAlertDatabase) o;
    return Objects.equals(this.reportDate, buroHawkAlertDatabase.reportDate) &&
        Objects.equals(this.keyCode, buroHawkAlertDatabase.keyCode) &&
        Objects.equals(this.institutionType, buroHawkAlertDatabase.institutionType) &&
        Objects.equals(this.message, buroHawkAlertDatabase.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(reportDate, keyCode, institutionType, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroHawkAlertDatabase {\n");
    sb.append("    reportDate: ").append(toIndentedString(reportDate)).append("\n");
    sb.append("    keyCode: ").append(toIndentedString(keyCode)).append("\n");
    sb.append("    institutionType: ").append(toIndentedString(institutionType)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

