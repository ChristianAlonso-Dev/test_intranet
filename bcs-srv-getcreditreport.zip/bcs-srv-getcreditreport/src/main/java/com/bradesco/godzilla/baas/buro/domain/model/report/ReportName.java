package com.bradesco.godzilla.baas.buro.domain.model.report;


public record ReportName(
        String paternalLastName,
        String maternalLastName,
        String additionalLastName,
        String firstName,
        String secondName,
        String birthDate,
        String rfc,
        String prefix,
        String suffix,
        String nationality,
        String residenceType,
        String driverLicenseNumber,
        String maritalStatus,
        String gender,
        String professionalLicenseNumber,
        String voterRegistrationNumber,
        String otherCountryCode,
        String dependentsNumber,
        String dependentsAges,
        String dependentsInformationDate,
        String deathDate,
        String foreignTaxId
) {
}
