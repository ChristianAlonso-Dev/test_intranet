package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroReportSummaryDto(
        @JsonProperty("fechaIngresoBD") String databaseEntryDate,
        @JsonProperty("numeroMOP7") String accountsMop7,
        @JsonProperty("numeroMOP6") String accountsMop6,
        @JsonProperty("numeroMOP5") String accountsMop5,
        @JsonProperty("numeroMOP4") String accountsMop4,
        @JsonProperty("numeroMOP3") String accountsMop3,
        @JsonProperty("numeroMOP2") String accountsMop2,
        @JsonProperty("numeroMOP1") String accountsMop1,
        @JsonProperty("numeroMOP0") String accountsMop0,
        @JsonProperty("numeroMOPUR") String accountsMopUr,
        @JsonProperty("numeroCuentas") String totalAccounts,
        @JsonProperty("cuentasPagosFijosHipotecas") String fixedPaymentMortgageAccounts,
        @JsonProperty("cuentasRevolventesAbiertas") String openRevolvingAccounts,
        @JsonProperty("cuentasCerradas") String closedAccounts,
        @JsonProperty("cuentasNegativasActuales") String currentNegativeAccounts,
        @JsonProperty("cuentasClavesHistoriaNegativa") String negativeHistoryAccounts,
        @JsonProperty("cuentasDisputa") String disputedAccounts,
        @JsonProperty("nuevaDireccionReportadaUltimos60Dias") String newAddressLast60Days,
        @JsonProperty("mensajesAlerta") String alertMessages,
        @JsonProperty("tipoMoneda") String currencyCode,
        @JsonProperty("totalCreditosMaximosRevolventes") String revolvingTotalMaximumCredit,
        @JsonProperty("totalLimitesCreditoRevolventes") String revolvingTotalCreditLimit,
        @JsonProperty("totalSaldosActualesRevolventes") String revolvingTotalCurrentBalance,
        @JsonProperty("totalSaldosVencidosRevolventes") String revolvingTotalPastDueBalance,
        @JsonProperty("totalPagosRevolventes") String revolvingTotalPayments,
        @JsonProperty("pctLimiteCreditoUtilizadoRevolventes") String revolvingCreditLimitUsedPercentage,
        @JsonProperty("numeroMOP96") String accountsMop96,
        @JsonProperty("numeroMOP97") String accountsMop97,
        @JsonProperty("numeroMOP99") String accountsMop99,
        @JsonProperty("fechaAperturaCuentaMasAntigua") String oldestAccountOpeningDate,
        @JsonProperty("fechaAperturaCuentaMasReciente") String newestAccountOpeningDate,
        @JsonProperty("totalSolicitudesReporte") String totalInquiries,
        @JsonProperty("fechaSolicitudReporteMasReciente") String mostRecentInquiryDate,
        @JsonProperty("numeroTotalCuentasDespachoCobranza") String collectionAgencyAccounts,
        @JsonProperty("fechaAperturaCuentaMasRecienteDespachoCobranza") String collectionAgencyNewestAccountOpeningDate,
        @JsonProperty("numeroTotalSolicitudesDespachosCobranza") String collectionAgencyInquiries,
        @JsonProperty("fechaSolicitudMasRecienteDespachoCobranza") String collectionAgencyMostRecentInquiryDate,
        @JsonProperty("existenciaDeclaracionesConsumidor") String consumerStatementExists,
        @JsonProperty("numeroSolicitudesUltimos6Meses") String inquiriesLast6Months,
        @JsonProperty("totalCreditosMaximosPagosFijos") String fixedPaymentTotalMaximumCredit,
        @JsonProperty("totalSaldosVencidosPagosFijos") String fixedPaymentTotalPastDueBalance,
        @JsonProperty("totalPagosPagosFijos") String fixedPaymentTotalPayments,
        @JsonProperty("totalSaldosActualesPagosFijos") String fixedPaymentTotalCurrentBalance
) {
}
