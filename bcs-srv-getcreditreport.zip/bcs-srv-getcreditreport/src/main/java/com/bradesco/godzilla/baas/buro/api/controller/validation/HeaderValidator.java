package com.bradesco.godzilla.baas.buro.api.controller.validation;

import com.bradesco.godzilla.baas.buro.api.controller.ApiUtil;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.BusinessErrorCode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import org.springframework.stereotype.Component;

@Component
public class HeaderValidator {

    private final ObjectReader geoLocationReader;

    public HeaderValidator(ObjectMapper objectMapper) {
        this.geoLocationReader = objectMapper.copy()
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
                .readerFor(GeoLocationHeader.class);
    }

    public void validate(
            String geoLocation,
            String authorization,
            String contentType,
            String traceparent,
            String channelId,
            String channelType,
            String requestId,
            String tracestate) {
        validateGeoLocation(geoLocation);
        ApiUtil.validateAuthorization(authorization);
        ApiUtil.validateContentType(contentType);
        ApiUtil.validateTraceparent(traceparent);
        ApiUtil.validateTracestate(tracestate);
        ApiUtil.validateChannelId(channelId);
        ApiUtil.validateChannelType(channelType);
        ApiUtil.validateRequestId(requestId);
    }

    private void validateGeoLocation(String header) {
        if (header == null) {
            throw new BusinessException(BusinessErrorCode.ERROR_8427_MISSING_REQUIRED_HEADER);
        }
        if (header.isBlank()) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
        GeoLocationHeader geoLocation;
        try {
            geoLocation = geoLocationReader.readValue(header);
        } catch (JsonProcessingException exception) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
        if (!isValid(geoLocation)) {
            throw new BusinessException(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS);
        }
    }

    private boolean isValid(GeoLocationHeader geoLocation) {
        return geoLocation != null
                && geoLocation.latitude() != null
                && geoLocation.longitude() != null
                && geoLocation.timestamp() != null
                && isOffsetDateTime(geoLocation.timestamp());
    }

    private boolean isOffsetDateTime(String value) {
        try {
            OffsetDateTime.parse(value);
            return true;
        } catch (DateTimeParseException exception) {
            return false;
        }
    }

    record GeoLocationHeader(Double latitude, Double longitude, Double accuracy, String timestamp) {
    }
}