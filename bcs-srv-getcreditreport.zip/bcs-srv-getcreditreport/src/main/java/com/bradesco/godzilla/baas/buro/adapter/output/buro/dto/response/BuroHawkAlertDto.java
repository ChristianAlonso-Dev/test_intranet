package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroHawkAlertDto(
        @JsonProperty("fechaReporte") String reportDate,
        @JsonProperty("codigoClave") String keyCode,
        @JsonProperty("tipoInstitucion") String institutionType,
        @JsonProperty("mensaje") String message
) {
}
