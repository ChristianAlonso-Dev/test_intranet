package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Customer name.
 */

@Schema(name = "buroName", description = "Customer name.")
@JsonTypeName("buroName")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroName {

  private String paternalLastName;

  private String maternalLastName;

  private String additionalLastName;

  private String firstName;

  private String secondName;

  private String birthDate;

  private String rfc;

  private String prefix;

  private String suffix;

  private String nationality;

  private String residenceType;

  private String driverLicenseNumber;

  private String maritalStatus;

  private String gender;

  private String professionalLicenseNumber;

  private String voterRegistrationNumber;

  private String otherCountryCode;

  private String dependentsNumber;

  private String dependentsAges;

  private String dependentsInformationDate;

  private String deathDate;

  private String foreignTaxId;

  public BuroName paternalLastName(String paternalLastName) {
    this.paternalLastName = paternalLastName;
    return this;
  }

  /**
   * Paternal last name.
   * @return paternalLastName
  */
  @Size(max = 26) 
  @Schema(name = "paternalLastName", example = "PRUEBA", description = "Paternal last name.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("paternalLastName")
  public String getPaternalLastName() {
    return paternalLastName;
  }

  public void setPaternalLastName(String paternalLastName) {
    this.paternalLastName = paternalLastName;
  }

  public BuroName maternalLastName(String maternalLastName) {
    this.maternalLastName = maternalLastName;
    return this;
  }

  /**
   * Maternal last name.
   * @return maternalLastName
  */
  @Size(max = 26) 
  @Schema(name = "maternalLastName", example = "UNO", description = "Maternal last name.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("maternalLastName")
  public String getMaternalLastName() {
    return maternalLastName;
  }

  public void setMaternalLastName(String maternalLastName) {
    this.maternalLastName = maternalLastName;
  }

  public BuroName additionalLastName(String additionalLastName) {
    this.additionalLastName = additionalLastName;
    return this;
  }

  /**
   * Additional last name; for women, the married last name may be presented.
   * @return additionalLastName
  */
  @Size(max = 26) 
  @Schema(name = "additionalLastName", description = "Additional last name; for women, the married last name may be presented.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("additionalLastName")
  public String getAdditionalLastName() {
    return additionalLastName;
  }

  public void setAdditionalLastName(String additionalLastName) {
    this.additionalLastName = additionalLastName;
  }

  public BuroName firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * First name.
   * @return firstName
  */
  @Size(max = 26) 
  @Schema(name = "firstName", example = "JUAN", description = "First name.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("firstName")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public BuroName secondName(String secondName) {
    this.secondName = secondName;
    return this;
  }

  /**
   * Second name, if it exists.
   * @return secondName
  */
  @Size(max = 26) 
  @Schema(name = "secondName", description = "Second name, if it exists.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("secondName")
  public String getSecondName() {
    return secondName;
  }

  public void setSecondName(String secondName) {
    this.secondName = secondName;
  }

  public BuroName birthDate(String birthDate) {
    this.birthDate = birthDate;
    return this;
  }

  /**
   * Date of birth (DDMMAAAA).
   * @return birthDate
  */
  @Size(max = 8) 
  @Schema(name = "birthDate", example = "01011980", description = "Date of birth (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("birthDate")
  public String getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(String birthDate) {
    this.birthDate = birthDate;
  }

  public BuroName rfc(String rfc) {
    this.rfc = rfc;
    return this;
  }

  /**
   * Customer RFC (AAAANNNNNNZZZ).
   * @return rfc
  */
  @Size(max = 13) 
  @Schema(name = "rfc", example = "NOPX800101XXX", description = "Customer RFC (AAAANNNNNNZZZ).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rfc")
  public String getRfc() {
    return rfc;
  }

  public void setRfc(String rfc) {
    this.rfc = rfc;
  }

  public BuroName prefix(String prefix) {
    this.prefix = prefix;
    return this;
  }

  /**
   * Personal or professional prefix (Annex 4).
   * @return prefix
  */
  @Size(max = 4) 
  @Schema(name = "prefix", example = "SR", description = "Personal or professional prefix (Annex 4).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("prefix")
  public String getPrefix() {
    return prefix;
  }

  public void setPrefix(String prefix) {
    this.prefix = prefix;
  }

  public BuroName suffix(String suffix) {
    this.suffix = suffix;
    return this;
  }

  /**
   * Suffix: JR = Junior, II = Second, III = Third.
   * @return suffix
  */
  @Size(max = 4) 
  @Schema(name = "suffix", description = "Suffix: JR = Junior, II = Second, III = Third.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("suffix")
  public String getSuffix() {
    return suffix;
  }

  public void setSuffix(String suffix) {
    this.suffix = suffix;
  }

  public BuroName nationality(String nationality) {
    this.nationality = nationality;
    return this;
  }

  /**
   * Nationality (Annex 5).
   * @return nationality
  */
  @Size(max = 2) 
  @Schema(name = "nationality", example = "MX", description = "Nationality (Annex 5).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("nationality")
  public String getNationality() {
    return nationality;
  }

  public void setNationality(String nationality) {
    this.nationality = nationality;
  }

  public BuroName residenceType(String residenceType) {
    this.residenceType = residenceType;
    return this;
  }

  /**
   * Housing status: 1 = Owner, 2 = Rent, 3 = Boarding / Lives with relatives.
   * @return residenceType
  */
  @Size(max = 1) 
  @Schema(name = "residenceType", example = "1", description = "Housing status: 1 = Owner, 2 = Rent, 3 = Boarding / Lives with relatives.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("residenceType")
  public String getResidenceType() {
    return residenceType;
  }

  public void setResidenceType(String residenceType) {
    this.residenceType = residenceType;
  }

  public BuroName driverLicenseNumber(String driverLicenseNumber) {
    this.driverLicenseNumber = driverLicenseNumber;
    return this;
  }

  /**
   * Driver's license number.
   * @return driverLicenseNumber
  */
  @Size(max = 20) 
  @Schema(name = "driverLicenseNumber", description = "Driver's license number.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("driverLicenseNumber")
  public String getDriverLicenseNumber() {
    return driverLicenseNumber;
  }

  public void setDriverLicenseNumber(String driverLicenseNumber) {
    this.driverLicenseNumber = driverLicenseNumber;
  }

  public BuroName maritalStatus(String maritalStatus) {
    this.maritalStatus = maritalStatus;
    return this;
  }

  /**
   * Marital status: D = Divorced, S = Single, F = Common-law union, W = Widowed, M = Married.
   * @return maritalStatus
  */
  @Size(max = 1) 
  @Schema(name = "maritalStatus", example = "D", description = "Marital status: D = Divorced, S = Single, F = Common-law union, W = Widowed, M = Married.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("maritalStatus")
  public String getMaritalStatus() {
    return maritalStatus;
  }

  public void setMaritalStatus(String maritalStatus) {
    this.maritalStatus = maritalStatus;
  }

  public BuroName gender(String gender) {
    this.gender = gender;
    return this;
  }

  /**
   * Gender: F = Female, M = Male.
   * @return gender
  */
  @Size(max = 1) 
  @Schema(name = "gender", example = "M", description = "Gender: F = Female, M = Male.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("gender")
  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public BuroName professionalLicenseNumber(String professionalLicenseNumber) {
    this.professionalLicenseNumber = professionalLicenseNumber;
    return this;
  }

  /**
   * Professional license (cédula profesional) number.
   * @return professionalLicenseNumber
  */
  @Size(max = 20) 
  @Schema(name = "professionalLicenseNumber", example = "11111222225555444444", description = "Professional license (cédula profesional) number.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("professionalLicenseNumber")
  public String getProfessionalLicenseNumber() {
    return professionalLicenseNumber;
  }

  public void setProfessionalLicenseNumber(String professionalLicenseNumber) {
    this.professionalLicenseNumber = professionalLicenseNumber;
  }

  public BuroName voterRegistrationNumber(String voterRegistrationNumber) {
    this.voterRegistrationNumber = voterRegistrationNumber;
    return this;
  }

  /**
   * Electoral registration (INE) number.
   * @return voterRegistrationNumber
  */
  @Size(max = 20) 
  @Schema(name = "voterRegistrationNumber", description = "Electoral registration (INE) number.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("voterRegistrationNumber")
  public String getVoterRegistrationNumber() {
    return voterRegistrationNumber;
  }

  public void setVoterRegistrationNumber(String voterRegistrationNumber) {
    this.voterRegistrationNumber = voterRegistrationNumber;
  }

  public BuroName otherCountryCode(String otherCountryCode) {
    this.otherCountryCode = otherCountryCode;
    return this;
  }

  /**
   * Country of citizenship code, as indicated in the query.
   * @return otherCountryCode
  */
  @Size(max = 2) 
  @Schema(name = "otherCountryCode", example = "AD", description = "Country of citizenship code, as indicated in the query.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("otherCountryCode")
  public String getOtherCountryCode() {
    return otherCountryCode;
  }

  public void setOtherCountryCode(String otherCountryCode) {
    this.otherCountryCode = otherCountryCode;
  }

  public BuroName dependentsNumber(String dependentsNumber) {
    this.dependentsNumber = dependentsNumber;
    return this;
  }

  /**
   * Number of economic dependents (maximum 15).
   * @return dependentsNumber
  */
  @Size(max = 2) 
  @Schema(name = "dependentsNumber", description = "Number of economic dependents (maximum 15).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("dependentsNumber")
  public String getDependentsNumber() {
    return dependentsNumber;
  }

  public void setDependentsNumber(String dependentsNumber) {
    this.dependentsNumber = dependentsNumber;
  }

  public BuroName dependentsAges(String dependentsAges) {
    this.dependentsAges = dependentsAges;
    return this;
  }

  /**
   * Ages of the dependents, 2 characters per age, consecutive and without spaces. Ages under 1 year: 01.
   * @return dependentsAges
  */
  @Size(max = 30) 
  @Schema(name = "dependentsAges", description = "Ages of the dependents, 2 characters per age, consecutive and without spaces. Ages under 1 year: 01.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("dependentsAges")
  public String getDependentsAges() {
    return dependentsAges;
  }

  public void setDependentsAges(String dependentsAges) {
    this.dependentsAges = dependentsAges;
  }

  public BuroName dependentsInformationDate(String dependentsInformationDate) {
    this.dependentsInformationDate = dependentsInformationDate;
    return this;
  }

  /**
   * Most recent date on which dependents information was received (DDMMAAAA).
   * @return dependentsInformationDate
  */
  @Size(max = 8) 
  @Schema(name = "dependentsInformationDate", description = "Most recent date on which dependents information was received (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("dependentsInformationDate")
  public String getDependentsInformationDate() {
    return dependentsInformationDate;
  }

  public void setDependentsInformationDate(String dependentsInformationDate) {
    this.dependentsInformationDate = dependentsInformationDate;
  }

  public BuroName deathDate(String deathDate) {
    this.deathDate = deathDate;
    return this;
  }

  /**
   * Date of death (DDMMAAAA).
   * @return deathDate
  */
  @Size(max = 8) 
  @Schema(name = "deathDate", description = "Date of death (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("deathDate")
  public String getDeathDate() {
    return deathDate;
  }

  public void setDeathDate(String deathDate) {
    this.deathDate = deathDate;
  }

  public BuroName foreignTaxId(String foreignTaxId) {
    this.foreignTaxId = foreignTaxId;
    return this;
  }

  /**
   * Unique identification number; for Mexican customers it may be the CURP.
   * @return foreignTaxId
  */
  @Size(max = 20) 
  @Schema(name = "foreignTaxId", description = "Unique identification number; for Mexican customers it may be the CURP.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("foreignTaxId")
  public String getForeignTaxId() {
    return foreignTaxId;
  }

  public void setForeignTaxId(String foreignTaxId) {
    this.foreignTaxId = foreignTaxId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroName buroName = (BuroName) o;
    return Objects.equals(this.paternalLastName, buroName.paternalLastName) &&
        Objects.equals(this.maternalLastName, buroName.maternalLastName) &&
        Objects.equals(this.additionalLastName, buroName.additionalLastName) &&
        Objects.equals(this.firstName, buroName.firstName) &&
        Objects.equals(this.secondName, buroName.secondName) &&
        Objects.equals(this.birthDate, buroName.birthDate) &&
        Objects.equals(this.rfc, buroName.rfc) &&
        Objects.equals(this.prefix, buroName.prefix) &&
        Objects.equals(this.suffix, buroName.suffix) &&
        Objects.equals(this.nationality, buroName.nationality) &&
        Objects.equals(this.residenceType, buroName.residenceType) &&
        Objects.equals(this.driverLicenseNumber, buroName.driverLicenseNumber) &&
        Objects.equals(this.maritalStatus, buroName.maritalStatus) &&
        Objects.equals(this.gender, buroName.gender) &&
        Objects.equals(this.professionalLicenseNumber, buroName.professionalLicenseNumber) &&
        Objects.equals(this.voterRegistrationNumber, buroName.voterRegistrationNumber) &&
        Objects.equals(this.otherCountryCode, buroName.otherCountryCode) &&
        Objects.equals(this.dependentsNumber, buroName.dependentsNumber) &&
        Objects.equals(this.dependentsAges, buroName.dependentsAges) &&
        Objects.equals(this.dependentsInformationDate, buroName.dependentsInformationDate) &&
        Objects.equals(this.deathDate, buroName.deathDate) &&
        Objects.equals(this.foreignTaxId, buroName.foreignTaxId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(paternalLastName, maternalLastName, additionalLastName, firstName, secondName, birthDate, rfc, prefix, suffix, nationality, residenceType, driverLicenseNumber, maritalStatus, gender, professionalLicenseNumber, voterRegistrationNumber, otherCountryCode, dependentsNumber, dependentsAges, dependentsInformationDate, deathDate, foreignTaxId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroName {\n");
    sb.append("    paternalLastName: ").append(toIndentedString(paternalLastName)).append("\n");
    sb.append("    maternalLastName: ").append(toIndentedString(maternalLastName)).append("\n");
    sb.append("    additionalLastName: ").append(toIndentedString(additionalLastName)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    secondName: ").append(toIndentedString(secondName)).append("\n");
    sb.append("    birthDate: ").append(toIndentedString(birthDate)).append("\n");
    sb.append("    rfc: ").append(toIndentedString(rfc)).append("\n");
    sb.append("    prefix: ").append(toIndentedString(prefix)).append("\n");
    sb.append("    suffix: ").append(toIndentedString(suffix)).append("\n");
    sb.append("    nationality: ").append(toIndentedString(nationality)).append("\n");
    sb.append("    residenceType: ").append(toIndentedString(residenceType)).append("\n");
    sb.append("    driverLicenseNumber: ").append(toIndentedString(driverLicenseNumber)).append("\n");
    sb.append("    maritalStatus: ").append(toIndentedString(maritalStatus)).append("\n");
    sb.append("    gender: ").append(toIndentedString(gender)).append("\n");
    sb.append("    professionalLicenseNumber: ").append(toIndentedString(professionalLicenseNumber)).append("\n");
    sb.append("    voterRegistrationNumber: ").append(toIndentedString(voterRegistrationNumber)).append("\n");
    sb.append("    otherCountryCode: ").append(toIndentedString(otherCountryCode)).append("\n");
    sb.append("    dependentsNumber: ").append(toIndentedString(dependentsNumber)).append("\n");
    sb.append("    dependentsAges: ").append(toIndentedString(dependentsAges)).append("\n");
    sb.append("    dependentsInformationDate: ").append(toIndentedString(dependentsInformationDate)).append("\n");
    sb.append("    deathDate: ").append(toIndentedString(deathDate)).append("\n");
    sb.append("    foreignTaxId: ").append(toIndentedString(foreignTaxId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

