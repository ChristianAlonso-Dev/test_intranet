package com.bradesco.godzilla.baas.buro.port.input;

import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class GetCreditReportQuery {

    private final String requestId;

    private final String customerId;

    private final String channelId;

    private final String channelType;

    private final String geoLocation;

    private final String traceparent;

    private final CreditReportInquiry inquiry;
}
