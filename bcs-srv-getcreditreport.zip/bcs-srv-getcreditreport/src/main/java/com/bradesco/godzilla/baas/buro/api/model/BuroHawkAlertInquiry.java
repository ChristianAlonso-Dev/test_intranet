package com.bradesco.godzilla.baas.buro.api.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import jakarta.annotation.Generated;

/**
 * Hawk alert based on the query data.
 */

@Schema(name = "buroHawkAlertInquiry", description = "Hawk alert based on the query data.")
@JsonTypeName("buroHawkAlertInquiry")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2026-10-28T16:27:00.217529300-06:00[America/Mexico_City]", comments = "Generator version: 7.6.0")
public class BuroHawkAlertInquiry {

  private String reportDate;

  private String keyCode;

  private String institutionType;

  private String message;

  public BuroHawkAlertInquiry reportDate(String reportDate) {
    this.reportDate = reportDate;
    return this;
  }

  /**
   * Date the possible fraud was reported in Hawk (DDMMAAAA).
   * @return reportDate
  */
  @Size(max = 8) 
  @Schema(name = "reportDate", example = "14101999", description = "Date the possible fraud was reported in Hawk (DDMMAAAA).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reportDate")
  public String getReportDate() {
    return reportDate;
  }

  public void setReportDate(String reportDate) {
    this.reportDate = reportDate;
  }

  public BuroHawkAlertInquiry keyCode(String keyCode) {
    this.keyCode = keyCode;
    return this;
  }

  /**
   * Code to classify the prevention.
   * @return keyCode
  */
  @Size(max = 3) 
  @Schema(name = "keyCode", example = "710", description = "Code to classify the prevention.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("keyCode")
  public String getKeyCode() {
    return keyCode;
  }

  public void setKeyCode(String keyCode) {
    this.keyCode = keyCode;
  }

  public BuroHawkAlertInquiry institutionType(String institutionType) {
    this.institutionType = institutionType;
    return this;
  }

  /**
   * Generic name of the reporting User (e.g. OFAC, Banco). CLV OBS EN PF = observation code FD or RI matched.
   * @return institutionType
  */
  @Size(max = 16) 
  @Schema(name = "institutionType", example = "BANKOLAT", description = "Generic name of the reporting User (e.g. OFAC, Banco). CLV OBS EN PF = observation code FD or RI matched.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("institutionType")
  public String getInstitutionType() {
    return institutionType;
  }

  public void setInstitutionType(String institutionType) {
    this.institutionType = institutionType;
  }

  public BuroHawkAlertInquiry message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Prevention description (Annex 8).
   * @return message
  */
  @Size(max = 48) 
  @Schema(name = "message", example = "PN1, NOM. REGISTRADO COMO SOLICITANTE", description = "Prevention description (Annex 8).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BuroHawkAlertInquiry buroHawkAlertInquiry = (BuroHawkAlertInquiry) o;
    return Objects.equals(this.reportDate, buroHawkAlertInquiry.reportDate) &&
        Objects.equals(this.keyCode, buroHawkAlertInquiry.keyCode) &&
        Objects.equals(this.institutionType, buroHawkAlertInquiry.institutionType) &&
        Objects.equals(this.message, buroHawkAlertInquiry.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(reportDate, keyCode, institutionType, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuroHawkAlertInquiry {\n");
    sb.append("    reportDate: ").append(toIndentedString(reportDate)).append("\n");
    sb.append("    keyCode: ").append(toIndentedString(keyCode)).append("\n");
    sb.append("    institutionType: ").append(toIndentedString(institutionType)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

