package com.bradesco.godzilla.baas.buro.adapter.output.buro.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BuroEmploymentDto(
        @JsonProperty("nombreEmpresa") String companyName,
        @JsonProperty("direccion1") String addressLine1,
        @JsonProperty("direccion2") String addressLine2,
        @JsonProperty("coloniaPoblacion") String neighborhood,
        @JsonProperty("delegacionMunicipio") String municipality,
        @JsonProperty("ciudad") String city,
        @JsonProperty("estado") String state,
        @JsonProperty("cp") String postalCode,
        @JsonProperty("numeroTelefono") String phoneNumber,
        @JsonProperty("extension") String extension,
        @JsonProperty("fax") String fax,
        @JsonProperty("cargo") String position,
        @JsonProperty("fechaContratacion") String hireDate,
        @JsonProperty("claveMonedaSalario") String salaryCurrency,
        @JsonProperty("salario") String salary,
        @JsonProperty("baseSalarial") String salaryPeriod,
        @JsonProperty("numeroEmpleado") String employeeNumber,
        @JsonProperty("fechaUltimoDiaEmpleo") String lastEmploymentDate,
        @JsonProperty("fechaReportoEmpleo") String employmentReportDate,
        @JsonProperty("fechaVerificacion") String verificationDate,
        @JsonProperty("modoVerificacion") String verificationMode,
        @JsonProperty("codPais") String countryCode
) {
}
