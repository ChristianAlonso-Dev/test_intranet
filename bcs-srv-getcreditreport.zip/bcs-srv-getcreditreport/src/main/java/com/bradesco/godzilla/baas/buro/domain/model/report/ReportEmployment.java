package com.bradesco.godzilla.baas.buro.domain.model.report;


public record ReportEmployment(
        String companyName,
        String addressLine1,
        String addressLine2,
        String neighborhood,
        String municipality,
        String city,
        String state,
        String postalCode,
        String phoneNumber,
        String extension,
        String fax,
        String position,
        String hireDate,
        String salaryCurrency,
        String salary,
        String salaryPeriod,
        String employeeNumber,
        String lastEmploymentDate,
        String employmentReportDate,
        String verificationDate,
        String verificationMode,
        String countryCode
) {
}
