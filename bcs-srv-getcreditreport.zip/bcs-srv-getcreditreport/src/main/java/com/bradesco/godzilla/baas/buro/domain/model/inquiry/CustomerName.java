package com.bradesco.godzilla.baas.buro.domain.model.inquiry;

public record CustomerName(
        String paternalLastName,
        String maternalLastName,
        String firstName,
        String rfc
) {
}
