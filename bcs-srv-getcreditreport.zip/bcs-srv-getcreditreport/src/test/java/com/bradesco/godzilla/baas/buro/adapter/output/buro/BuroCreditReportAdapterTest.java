package com.bradesco.godzilla.baas.buro.adapter.output.buro;

import com.bradesco.godzilla.baas.buro.adapter.output.buro.mapper.BuroCreditReportMapper;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerAddress;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerName;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.InquiryHeader;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReportResult;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.client.ICreditReport;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.request.CreditReportRequest;
import com.bradesco.godzilla.baas.commons.buro.api.creditreport.entities.response.CreditReportResponse;
import com.bradesco.godzilla.baas.commons.exception.base.BaseException;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.BusinessErrorCode;
import com.bradesco.godzilla.baas.commons.exception.code.SystemErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BuroCreditReportAdapterTest {

    private static final String EXPECTED_REQUEST = "{\"consulta\":{\"persona\":{"
            + "\"domicilios\":[{\"direccion1\":\"DOMICILIO CONOCIDO SN\",\"delegacionMunicipio\":\"ALVARO OBREGON\","
            + "\"ciudad\":\"CD DE MEXICO\",\"estado\":\"CDMX\",\"cp\":\"01000\",\"codPais\":\"MX\"}],"
            + "\"encabezado\":{\"clavePais\":\"MX\",\"claveUnidadMonetaria\":\"MX\",\"identificadorBuro\":\"0000\","
            + "\"idioma\":\"SP\",\"numeroReferenciaOperador\":\"                 12345678\",\"productoRequerido\":\"047\","
            + "\"tipoConsulta\":\"I\",\"tipoContrato\":\"CC\"},"
            + "\"nombre\":{\"apellidoPaterno\":\"PENA NUNEZ\",\"apellidoMaterno\":\"NO PROPORCIONADO\","
            + "\"primerNombre\":\"JOSE\",\"rfc\":\"NOPX800101XXX\"}}}}";

    private static final String EXPECTED_REQUEST_JAIME_BALMES = EXPECTED_REQUEST
            .replace("DOMICILIO CONOCIDO SN", "JAIME BALMES 88");

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Mock
    private ICreditReport creditReport;

    @Mock
    private BuroCreditReportMapper mapper;

    private BuroCreditReportAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new BuroCreditReportAdapter(creditReport, mapper, objectMapper, "MX", "MX", "0000", "SP", "I");
    }

    @Test
    void getCreditReportSendsNormalizedRequestAndMapsResponse() throws Exception {
        CreditReport report = new CreditReport(null, null, List.of(), List.of(), List.of(), List.of(), List.of(),
                List.of(), List.of(), null, List.of());
        when(creditReport.getCreditReport(any())).thenReturn(ResponseEntity.ok(
                response("{\"respuesta\":{\"persona\":{\"encabezado\":{\"numeroControlConsulta\":\"2424875572\"}}}}")));
        when(mapper.toCreditReport(any())).thenReturn(report);

        CreditReportResult result = adapter.getCreditReport(inquiry("Domicilio conocido"));

        assertSame(report, result.creditReport());
        assertNull(result.failure());
        ArgumentCaptor<CreditReportRequest> captor = ArgumentCaptor.forClass(CreditReportRequest.class);
        verify(creditReport).getCreditReport(captor.capture());
        assertEquals(EXPECTED_REQUEST, objectMapper.writeValueAsString(captor.getValue()));
        assertEquals(EXPECTED_REQUEST, result.providerRequest());
        assertTrue(result.providerResponse().contains("\"numeroControlConsulta\":\"2424875572\""));
    }

    @Test
    void getCreditReportNormalizesStreetSymbols() {
        when(creditReport.getCreditReport(any()))
                .thenReturn(ResponseEntity.ok(response("{\"respuesta\":{\"persona\":{\"encabezado\":{}}}}")));

        CreditReportResult result = adapter.getCreditReport(inquiry("Av. Juárez #12-B s/n"));

        assertTrue(result.providerRequest().contains("\"direccion1\":\"AV JUAREZ 12 B SN\""));
    }

    @Test
    void getCreditReportReturnsIntegrationErrorWhenThereIsNoReport() {
        when(creditReport.getCreditReport(any())).thenReturn(ResponseEntity.ok(response("{\"respuesta\":{}}")));

        CreditReportResult result = adapter.getCreditReport(inquiry("JAIME BALMES 88"));

        assertEquals(SystemErrorCode.INTEGRATION_ERROR, ((BaseException) result.failure()).getErrorCode());
        assertEquals("{\"respuesta\":{\"persona\":null}}", result.providerResponse());
    }

    @Test
    void getCreditReportReturnsIntegrationErrorWhenBuroAnswersWithErrorStatus() {
        when(creditReport.getCreditReport(any()))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        CreditReportResult result = adapter.getCreditReport(inquiry("Domicilio conocido"));

        assertEquals(SystemErrorCode.INTEGRATION_ERROR, ((BaseException) result.failure()).getErrorCode());
        assertEquals(EXPECTED_REQUEST, result.providerRequest());
        assertNull(result.providerResponse());
    }

    @Test
    void getCreditReportKeepsBuroErrorBodyWhenBuroAnswersWithErrorStatus() {
        String body = "{\"causa\":\"Error en request\"}";
        when(creditReport.getCreditReport(any())).thenThrow(new RestClientResponseException(
                "Error in the BURO's response", 400, "Bad Request", HttpHeaders.EMPTY,
                body.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));

        CreditReportResult result = adapter.getCreditReport(inquiry("JAIME BALMES 88"));

        assertEquals(SystemErrorCode.INTEGRATION_ERROR, ((BaseException) result.failure()).getErrorCode());
        assertEquals(EXPECTED_REQUEST_JAIME_BALMES, result.providerRequest());
        assertEquals(body, result.providerResponse());
    }

    @Test
    void getCreditReportPropagatesBuroUserErrors() {
        BusinessException userError = new BusinessException(BusinessErrorCode.ERROR_8428_SATELITE_ERROR_REQUEST);
        when(creditReport.getCreditReport(any())).thenThrow(userError);

        CreditReportResult result = adapter.getCreditReport(inquiry("JAIME BALMES 88"));

        assertSame(userError, result.failure());
        assertEquals(EXPECTED_REQUEST_JAIME_BALMES, result.providerRequest());
        assertNull(result.providerResponse());
    }

    @Test
    void getCreditReportSendsConfiguredCurrencyCode() {
        BuroCreditReportAdapter pesosAdapter =
                new BuroCreditReportAdapter(creditReport, mapper, objectMapper, "MX", "N$", "0000", "SP", "I");
        when(creditReport.getCreditReport(any()))
                .thenReturn(ResponseEntity.ok(response("{\"respuesta\":{\"persona\":{\"encabezado\":{}}}}")));

        CreditReportResult result = pesosAdapter.getCreditReport(inquiry("JAIME BALMES 88"));

        assertTrue(result.providerRequest().contains("\"claveUnidadMonetaria\":\"N$\""));
    }

    @Test
    void getCreditReportReturnsTimeoutWhenBuroCannotBeReached() {
        when(creditReport.getCreditReport(any())).thenThrow(new ResourceAccessException("timeout"));

        CreditReportResult result = adapter.getCreditReport(inquiry("JAIME BALMES 88"));

        assertEquals(SystemErrorCode.INTEGRATION_TIMEOUT, ((BaseException) result.failure()).getErrorCode());
    }

    private CreditReportResponse response(String json) {
        try {
            return objectMapper.readValue(json, CreditReportResponse.class);
        } catch (Exception exception) {
            throw new IllegalStateException(exception);
        }
    }

    private static CreditReportInquiry inquiry(String street) {
        return new CreditReportInquiry(
                new InquiryHeader("12345678", "CC", "047"),
                new CustomerName("Peña  Núñez", "NO PROPORCIONADO", "José", "nopx800101xxx"),
                List.of(new CustomerAddress(street, "Álvaro Obregón", "Cd. de México", "CDMX", "01000", "MX")));
    }
}