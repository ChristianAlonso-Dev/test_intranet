package com.bradesco.godzilla.baas.buro.domain.service;

import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerAddress;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CustomerName;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.InquiryHeader;
import com.bradesco.godzilla.baas.buro.domain.model.log.CreditReportLog;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReportResult;
import com.bradesco.godzilla.baas.buro.port.input.GetCreditReportQuery;
import com.bradesco.godzilla.baas.buro.port.output.ICreditReportLogPort;
import com.bradesco.godzilla.baas.buro.port.output.IGetCreditReportPort;
import com.bradesco.godzilla.baas.buro.port.output.IProspectPort;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.BusinessErrorCode;
import com.bradesco.godzilla.baas.commons.exception.code.SystemErrorCode;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GetCreditReportServiceTest {

    private static final String REQUEST_ID = "019a0c4e-7d21-7b3a-9f10-3c5e2b8a4d61";
    private static final String PROVIDER_REQUEST = "{\"consulta\":{}}";
    private static final String PROVIDER_RESPONSE = "{\"respuesta\":{}}";
    private static final String CUSTOMER_ID = "100245871";
    private static final String GEO_LOCATION = "{\"latitude\":19.432509,\"longitude\":-99.133240}";
    private static final String TRACEPARENT = "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01";

    @Mock
    private IGetCreditReportPort getCreditReportPort;

    @Mock
    private ICreditReportLogPort creditReportLogPort;

    @Mock
    private IProspectPort prospectPort;

    private GetCreditReportService service;

    @BeforeEach
    void setUp() {
        service = new GetCreditReportService(getCreditReportPort, creditReportLogPort, prospectPort);
    }

    @Test
    void executeReturnsCreditReportAndSavesProviderMessages() {
        GetCreditReportQuery query = query(CUSTOMER_ID, "JAIME BALMES 88");
        CreditReport creditReport = creditReport();
        when(prospectPort.existsActiveProspect(CUSTOMER_ID)).thenReturn(true);
        when(getCreditReportPort.getCreditReport(query.getInquiry()))
                .thenReturn(CreditReportResult.success(creditReport, PROVIDER_REQUEST, PROVIDER_RESPONSE));

        CreditReport result = service.execute(query);

        assertSame(creditReport, result);
        CreditReportLog log = savedLog();
        assertEquals(REQUEST_ID, log.getRequestId());
        assertEquals(CUSTOMER_ID, log.getCustomerId());
        assertEquals("NOPX800101XXX", log.getRfc());
        assertEquals("047", log.getRequiredProduct());
        assertEquals("12345678", log.getOperatorReference());
        assertEquals("sistema_interno", log.getChannelId());
        assertEquals("attended", log.getChannelType());
        assertEquals(GEO_LOCATION, log.getGeoLocation());
        assertEquals(TRACEPARENT, log.getTraceparent());
        assertEquals(PROVIDER_REQUEST, log.getProviderRequest());
        assertEquals(PROVIDER_RESPONSE, log.getProviderResponse());
        assertNotNull(log.getRequestedAt());
    }

    @Test
    void executeRethrowsFailureAndSavesRequestSent() {
        GetCreditReportQuery query = query(CUSTOMER_ID, "JAIME BALMES 88");
        when(prospectPort.existsActiveProspect(CUSTOMER_ID)).thenReturn(true);
        BusinessException failure = new BusinessException(SystemErrorCode.INTEGRATION_ERROR);
        when(getCreditReportPort.getCreditReport(query.getInquiry()))
                .thenReturn(CreditReportResult.failed(failure, PROVIDER_REQUEST, null));

        BusinessException exception = assertThrows(BusinessException.class, () -> service.execute(query));

        assertSame(failure, exception);
        CreditReportLog log = savedLog();
        assertEquals(PROVIDER_REQUEST, log.getProviderRequest());
        assertNull(log.getProviderResponse());
    }

    @Test
    void executeRejectsDuplicatedRequestId() {
        GetCreditReportQuery query = query(CUSTOMER_ID, "DOMICILIO CONOCIDO");
        when(creditReportLogPort.existsByRequestId(REQUEST_ID)).thenReturn(true);

        BusinessException exception = assertThrows(BusinessException.class, () -> service.execute(query));

        assertEquals(BusinessErrorCode.ERROR_892_REQUESTED_ALREADY_EXISTS, exception.getErrorCode());
        verify(getCreditReportPort, never()).getCreditReport(any());
    }

    @Test
    void executeRejectsProspectThatDoesNotExist() {
        GetCreditReportQuery query = query(CUSTOMER_ID, "JAIME BALMES 88");
        when(prospectPort.existsActiveProspect(CUSTOMER_ID)).thenReturn(false);

        BusinessException exception = assertThrows(BusinessException.class, () -> service.execute(query));

        assertEquals(BusinessErrorCode.ERROR_8044_NONEXISTENT_RESOURCE, exception.getErrorCode());
        verify(getCreditReportPort, never()).getCreditReport(any());
        verify(creditReportLogPort, never()).save(any());
    }

    @Test
    void executeRejectsStreetWithoutNumber() {
        GetCreditReportQuery query = query(CUSTOMER_ID, "REFORMA");

        BusinessException exception = assertThrows(BusinessException.class, () -> service.execute(query));

        assertEquals(BusinessErrorCode.ERROR_8423_INVALID_DATA, exception.getErrorCode());
        verify(getCreditReportPort, never()).getCreditReport(any());
    }

    @Test
    void executeRejectsInvalidCustomerId() {
        GetCreditReportQuery query = query("ABC", "JAIME BALMES 88");

        BusinessException exception = assertThrows(BusinessException.class, () -> service.execute(query));

        assertEquals(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS, exception.getErrorCode());
    }

    private CreditReportLog savedLog() {
        ArgumentCaptor<CreditReportLog> captor = ArgumentCaptor.forClass(CreditReportLog.class);
        verify(creditReportLogPort).save(captor.capture());
        return captor.getValue();
    }

    private static GetCreditReportQuery query(String customerId, String street) {
        CreditReportInquiry inquiry = new CreditReportInquiry(
                new InquiryHeader("12345678", "CC", "047"),
                new CustomerName("PRUEBA", "UNO", "JUAN", "NOPX800101XXX"),
                List.of(new CustomerAddress(street, "MIGUEL HIDALGO", "CD DE MEXICO", "CDMX", "11510", "MX")));
        return GetCreditReportQuery.builder()
                .requestId(REQUEST_ID)
                .customerId(customerId)
                .channelId("sistema_interno")
                .channelType("attended")
                .geoLocation(GEO_LOCATION)
                .traceparent(TRACEPARENT)
                .inquiry(inquiry)
                .build();
    }

    private static CreditReport creditReport() {
        return new CreditReport(null, null, List.of(), List.of(), List.of(), List.of(), List.of(), List.of(), List.of(),
                null, List.of());
    }
}
