package com.bradesco.godzilla.baas.buro.adapter.output.persistence;

import com.bradesco.godzilla.baas.buro.domain.model.log.CreditReportLog;
import com.bradesco.godzilla.baas.commons.servicedataconnector.domain.credito.DetalleTransaccionReporteCredito;
import com.bradesco.godzilla.baas.commons.servicedataconnector.domain.credito.TransaccionReporteCredito;
import com.bradesco.godzilla.baas.commons.servicedataconnector.repository.credito.DetalleTransaccionReporteCreditoRepository;
import com.bradesco.godzilla.baas.commons.servicedataconnector.repository.credito.TransaccionReporteCreditoRepository;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreditReportLogPersistenceAdapterTest {

    private static final String REQUEST_ID = "019a0c4e-7d21-7b3a-9f10-3c5e2b8a4d61";
    private static final Long PROSPECT_ID = 100245871L;
    private static final LocalDateTime REQUESTED_AT = LocalDateTime.of(2026, 11, 10, 16, 30);

    @Mock
    private TransaccionReporteCreditoRepository transaccionRepository;

    @Mock
    private DetalleTransaccionReporteCreditoRepository detalleRepository;

    private CreditReportLogPersistenceAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new CreditReportLogPersistenceAdapter(transaccionRepository, detalleRepository);
    }

    @Test
    void existsByRequestIdSearchesTheTransactionIdentifier() {
        when(transaccionRepository.existsByIdTransaccionReporteCredito(REQUEST_ID)).thenReturn(true);

        assertTrue(adapter.existsByRequestId(REQUEST_ID));
    }

    @Test
    void saveStoresTransactionAndProviderMessages() {
        when(transaccionRepository.save(any(TransaccionReporteCredito.class))).thenAnswer(invocation -> {
            TransaccionReporteCredito saved = invocation.getArgument(0);
            saved.setSkTransaccionReporteCredito(10L);
            return saved;
        });

        adapter.save(log("{\"respuesta\":{}}"));

        ArgumentCaptor<TransaccionReporteCredito> transaccion = ArgumentCaptor.forClass(TransaccionReporteCredito.class);
        verify(transaccionRepository).save(transaccion.capture());
        assertEquals(REQUEST_ID, transaccion.getValue().getIdTransaccionReporteCredito());
        assertEquals(PROSPECT_ID, transaccion.getValue().getIdProspecto());
        assertEquals("NOPX800101XXX", transaccion.getValue().getRfc());
        assertEquals("047", transaccion.getValue().getProductoRequerido());
        assertEquals("12345678", transaccion.getValue().getNumeroReferenciaOperador());
        assertEquals("sistema_interno", transaccion.getValue().getCanal());
        assertEquals("attended", transaccion.getValue().getTipoCanal());
        assertEquals("{\"latitude\":19.432509}", transaccion.getValue().getGeoLocalizacion());
        assertEquals("00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01", transaccion.getValue().getTraceparent());
        assertEquals(REQUESTED_AT, transaccion.getValue().getFechaSolicitud());

        ArgumentCaptor<DetalleTransaccionReporteCredito> detalle =
                ArgumentCaptor.forClass(DetalleTransaccionReporteCredito.class);
        verify(detalleRepository).save(detalle.capture());
        assertSame(transaccion.getValue(), detalle.getValue().getTransaccionReporteCredito());
        assertEquals("{\"consulta\":{}}", detalle.getValue().getSolicitudProveedor());
        assertEquals("{\"respuesta\":{}}", detalle.getValue().getRespuestaProveedor());
    }

    @Test
    void saveKeepsEmptyResponseWhenProviderDidNotAnswer() {
        when(transaccionRepository.save(any(TransaccionReporteCredito.class))).thenAnswer(invocation -> invocation.getArgument(0));

        adapter.save(log(null));

        ArgumentCaptor<DetalleTransaccionReporteCredito> detalle =
                ArgumentCaptor.forClass(DetalleTransaccionReporteCredito.class);
        verify(detalleRepository).save(detalle.capture());
        assertNull(detalle.getValue().getRespuestaProveedor());
    }

    private static CreditReportLog log(String providerResponse) {
        return CreditReportLog.builder()
                .requestId(REQUEST_ID)
                .customerId("100245871")
                .rfc("NOPX800101XXX")
                .requiredProduct("047")
                .operatorReference("12345678")
                .channelId("sistema_interno")
                .channelType("attended")
                .geoLocation("{\"latitude\":19.432509}")
                .traceparent("00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01")
                .providerRequest("{\"consulta\":{}}")
                .providerResponse(providerResponse)
                .requestedAt(REQUESTED_AT)
                .build();
    }
}
