package com.bradesco.godzilla.baas.buro.adapter.output.persistence;

import com.bradesco.godzilla.baas.commons.servicedataconnector.domain.onboarding.Prospecto;
import com.bradesco.godzilla.baas.commons.servicedataconnector.repository.onboarding.ProspectoRepository;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProspectPersistenceAdapterTest {

    @Mock
    private ProspectoRepository prospectoRepository;

    private ProspectPersistenceAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new ProspectPersistenceAdapter(prospectoRepository);
    }

    @Test
    void existsActiveProspectReturnsTrueWhenProspectIsActive() {
        when(prospectoRepository.findByIdProspectoAndFechaBajaIsNull(100245871L)).thenReturn(Optional.of(new Prospecto()));

        assertTrue(adapter.existsActiveProspect("100245871"));
    }

    @Test
    void existsActiveProspectReturnsFalseWhenProspectIsMissing() {
        when(prospectoRepository.findByIdProspectoAndFechaBajaIsNull(100245871L)).thenReturn(Optional.empty());

        assertFalse(adapter.existsActiveProspect("100245871"));
    }

    @Test
    void existsActiveProspectReturnsFalseWhenIdentifierExceedsProspectRange() {
        assertFalse(adapter.existsActiveProspect("99999999999999999999"));

        verify(prospectoRepository, never()).findByIdProspectoAndFechaBajaIsNull(any());
    }
}
