package com.bradesco.godzilla.baas.buro.api.controller;


import com.bradesco.godzilla.baas.buro.adapter.input.mapper.CreditReportApiMapper;
import com.bradesco.godzilla.baas.buro.api.controller.CustomersApiController;
import com.bradesco.godzilla.baas.buro.api.controller.validation.HeaderValidator;
import com.bradesco.godzilla.baas.buro.api.model.BuroCreditReportResponse;
import com.bradesco.godzilla.baas.buro.api.model.ChannelId;
import com.bradesco.godzilla.baas.buro.api.model.ChannelType;
import com.bradesco.godzilla.baas.buro.api.model.GetCustomerCreditReportRequest;
import com.bradesco.godzilla.baas.buro.domain.model.report.CreditReport;
import com.bradesco.godzilla.baas.buro.port.input.GetCreditReportQuery;
import com.bradesco.godzilla.baas.buro.port.input.IGetCreditReportUseCase;
import com.bradesco.godzilla.baas.buro.domain.model.inquiry.CreditReportInquiry;
import java.util.List;
import com.bradesco.godzilla.baas.commons.exception.business.BusinessException;
import com.bradesco.godzilla.baas.commons.exception.code.BusinessErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomersApiControllerTest {

    private static final String GEO_LOCATION =
            "{\"latitude\":19.432509,\"longitude\":-99.133240,\"accuracy\":10.0,\"timestamp\":\"2026-07-17T13:26:19.925Z\"}";
    private static final String AUTHORIZATION = "Bearer token";
    private static final String CONTENT_TYPE = "application/json";
    private static final String REQUEST_ID = "019a0c4e-7d21-7b3a-9f10-3c5e2b8a4d61";
    private static final String CUSTOMER_ID = "100245871";
    private static final String TRACEPARENT = "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01";

    @Mock
    private NativeWebRequest request;

    @Mock
    private IGetCreditReportUseCase useCase;

    @Mock
    private CreditReportApiMapper mapper;

    private CustomersApiController controller;

    @BeforeEach
    void setUp() {
        controller = new CustomersApiController(request, useCase, mapper, new HeaderValidator(new ObjectMapper()));
        when(request.getHeader("Channel-ID")).thenReturn("sistema_interno");
        when(request.getHeader("Channel-Type")).thenReturn("attended");
    }

    @Test
    void getCustomerCreditReportReturnsMappedReport() {
        GetCustomerCreditReportRequest body = new GetCustomerCreditReportRequest();
        CreditReport report = new CreditReport(null, null, List.of(), List.of(), List.of(), List.of(), List.of(), List.of(),
                List.of(), null, List.of());
        CreditReportInquiry inquiry = new CreditReportInquiry(null, null, List.of());
        BuroCreditReportResponse apiResponse = new BuroCreditReportResponse();
        when(mapper.toInquiry(body)).thenReturn(inquiry);
        when(useCase.execute(any())).thenReturn(report);
        when(mapper.toApiResponse(report)).thenReturn(apiResponse);

        ResponseEntity<BuroCreditReportResponse> response = call(REQUEST_ID, body);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(apiResponse, response.getBody());
        ArgumentCaptor<GetCreditReportQuery> query = ArgumentCaptor.forClass(GetCreditReportQuery.class);
        verify(useCase).execute(query.capture());
        assertEquals(REQUEST_ID, query.getValue().getRequestId());
        assertEquals(CUSTOMER_ID, query.getValue().getCustomerId());
        assertEquals("sistema_interno", query.getValue().getChannelId());
        assertEquals("attended", query.getValue().getChannelType());
        assertSame(inquiry, query.getValue().getInquiry());
    }

    @Test
    void getCustomerCreditReportRejectsInvalidRequestId() {
        GetCustomerCreditReportRequest body = new GetCustomerCreditReportRequest();

        BusinessException exception = assertThrows(BusinessException.class,
                () -> call("019a0c4e-7d21-4b3a-9f10-3c5e2b8a4d61", body));

        assertEquals(BusinessErrorCode.ERROR_8410_INVALID_PARAMETERS, exception.getErrorCode());
        verify(useCase, never()).execute(any());
    }

    private ResponseEntity<BuroCreditReportResponse> call(String requestId, GetCustomerCreditReportRequest body) {
        return controller.getCustomerCreditReport(
                GEO_LOCATION,
                AUTHORIZATION,
                CONTENT_TYPE,
                TRACEPARENT,
                ChannelId.SISTEMA_INTERNO,
                ChannelType.ATTENDED,
                requestId,
                CUSTOMER_ID,
                body,
                null);
    }
}
