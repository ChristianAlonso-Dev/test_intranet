# bcs-srv-getcreditreport

Get-CreditReport API (`BR-MX-API-000151`). Queries the Buró de Crédito Credit Report API (Manual API PF V.026) for an individual and returns the report as delivered by Buró de Crédito.

- **Base path:** `/baas/v1/credito/credit-report`
- **Endpoint:** `POST /customers/{customerId}/credit-reports`
- **Contract:** `src/main/resources/openapi.yaml`

## Code generation

The contract, the models (`com.bradesco.api.model`) and the interface `CustomersApi` are generated and are not modified by hand:

```bash
java -jar openapi-generator-cli-7.6.0.jar generate -g spring \
  -i src/main/resources/openapi.yaml -o <output> \
  --additional-properties=useSpringBoot3=true,basePackage=com.bradesco.api,apiPackage=com.bradesco.api.controller,modelPackage=com.bradesco.api.model,configPackage=org.openapitools.configuration
```

## Stack

- Java 17, Spring Boot, Maven
- OpenAPI Generator 7.6.0 (interface and models only)
- MapStruct, Lombok
- JUnit 5, Mockito, JaCoCo, PMD
- `commons-support` 3.0.0 (error codes, exceptions and `ApiError` format)

## Structure

| Package (`com.bradesco.godzilla.baas.buro` unless stated) | Content |
|---------|---------|
| `com.bradesco.api.model` | Generated models |
| `com.bradesco.api.controller` | Generated interface, `CustomersApiController`, header validation (`HeaderValidator`, `ApiUtil`) |
| `adapter/input/mapper` | `CreditReportApiMapper`: API request to domain inquiry, domain report to API response |
| `port/input` | `IGetCreditReportUseCase`, `GetCreditReportQuery` |
| `domain/model` | `inquiry` (query data and request context), `report` (credit report), `provider` (exchange with the provider), `log` (log entries) |
| `domain/exception` | `CreditReportErrorCode` (subcodes), `ProviderErrorCategory` (parent codes), `ProviderCommunicationException` |
| `domain/service` | `GetCreditReportService`, `CreditReportInquiryValidator`, `ProviderErrorResolver` |
| `port/output` | `ICreditReportProviderPort`, `ICreditReportLogPort` |
| `adapter/output/buro` | `BuroCreditReportAdapter`, request factory, response and error mappers, Buró DTOs, caller boundary |
| `adapter/output/log` | `CreditReportLogAdapter`, persistence records, repository boundary |

## Flow

1. The controller validates the headers (`Geo-Location`, `Authorization`, `Content-Type`, `traceparent`, `tracestate`, `Channel-ID`, `Channel-Type`, `Request-ID`) and maps the body to `CreditReportInquiry`.
2. `CreditReportInquiryValidator` validates `customerId` and that each street has a number, `SN`/`S/N` or is `DOMICILIO CONOCIDO`.
3. The request is registered in the log. If the `Request-ID` already exists, the query is rejected with `892` and Buró de Crédito is not called.
4. `BuroCreditReportAdapter` builds the query, calls Buró de Crédito and reads the response.
5. The result (report, `ur` errors or communication failure) is registered in the log together with the exact payload sent and the raw response.
6. A report is returned with `200`; `ur` errors are returned as `ApiError` with subErrors.

## Query sent to Buró de Crédito

| Field | Value |
|-------|-------|
| `clavePais` | `MX` |
| `claveUnidadMonetaria` | `MX` |
| `identificadorBuro` | `0000` |
| `idioma` | `SP` |
| `tipoConsulta` | `I` |
| `numeroReferenciaOperador` | `operatorReference`, padded with spaces on the left up to 25 positions |
| `productoRequerido`, `tipoContrato` | As received |
| `nombre` | Uppercase, accents removed, `Ñ` replaced by `N`, repeated spaces removed |
| `domicilios` | Same as `nombre`; `S/N` becomes `SN`; `# . , - /` are replaced by a space; `DOMICILIO CONOCIDO` becomes `DOMICILIO CONOCIDO SN` |
| `rfc` | Uppercase; omitted when not received |

## Errors

The `ur` segment is reviewed even when Buró de Crédito answers HTTP 200. Each field with a value becomes a subError; the parent `errorCode` is taken from the highest priority category.

| Category | Parent | Subcodes |
|----------|--------|----------|
| Provider failure | `855` | `8510`-`8516` |
| Access denied | `830` | `8310` |
| Invalid data | `8423` | `8428`-`8432` |

Any other response without a report (non 2xx status, body that is not JSON, response without `encabezado`) returns `855`. A timeout returns `856`.

## Integration points

| Point | Class to replace | Contract |
|-------|------------------|----------|
| Buró de Crédito caller | `PendingBuroCreditReportCaller` | `BuroCreditReportCaller.execute(String requestPayload)` sends the JSON as is and returns HTTP status and body. Authentication (token) belongs to the caller. |
| Log persistence | `PendingCreditReportLogRepository` | `insertRequest` returns `false` when the `requestId` already exists; `updateResponse` completes the same record. |

Both placeholders throw `SystemException` (`853` and `852`) until they are replaced. Remove the placeholder when adding the real implementation so only one bean of each interface exists.

### Log records

`CreditReportRequestRecord`: `requestId` (unique key), `customerId`, `channelId`, `channelType`, `operatorReference`, `requestBody` (JSON of the inquiry), `receivedAt`.

`CreditReportResponseRecord`: `requestId`, `outcome` (`SUCCESS`, `PROVIDER_REJECTED`, `PROVIDER_FAILURE`, `INTERNAL_FAILURE`), `errorCode`, `subErrorCodes` (comma separated), `providerRequestBody`, `providerResponseBody`, `providerHttpStatus`, `providerSentAt`, `providerReceivedAt`, `completedAt`.

The request record must be inserted under a unique constraint on `requestId`. A failure while completing the response record is logged and does not change the response to the consumer. The records contain personal data and the full credit report; they never contain the `Authorization` header or the Buró de Crédito token.
