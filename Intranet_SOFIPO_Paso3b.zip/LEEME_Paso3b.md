# Intranet SOFIPO · Paso 3b: corrección sobre Portal v7

## Diagnóstico de tu descarga v7

1. **No se ven los avisos:** en v7 ya no existen los 4 permisos de lectura del rol **Usuarios autenticados** (PermisoAvisos, PermisoCategoriasAviso, PermisoAreas y PermisoAudiencia). Sin ellos, Liquid no devuelve ningún aviso a los colaboradores.
2. **No aparece "Publicación":** la página, su regla de acceso solo para Admin RH, el vínculo del menú, la plantilla, la Web API y los permisos de Admin RH **sí se crearon bien**. Si tampoco ves los avisos con tu usuario, tu sesión no está entrando con el rol **Admin RH** (si lo tuviera, vería los avisos por sus propios permisos).
3. Hay 4 permisos duplicados creados a mano ("Aviso publicacion", "Categoría anexar", "Área anexar", "Audiencia anexar") que repiten los del paquete. No rompen nada, pero conviene quitarlos.

## Contenido del paquete

| Tipo | Archivo | Qué hace |
|---|---|---|
| Nuevo | `table-permissions/PermisoAvisos…`, `PermisoCategoriasAviso…`, `PermisoAreas…`, `PermisoAudiencia…` | Vuelve a dar **Lectura global** a **Usuarios autenticados** sobre las 4 tablas |
| Cambia | `web-pages/publicación-de-avisos/…webpage.yml` (2) | La página deja de estar oculta del mapa del sitio; el acceso sigue restringido a Admin RH |

## A. Subir

1. Respaldo: `pac pages download --path ./respaldo-paso3b --webSiteId a5595b5a-e6e0-4342-a230-25a2ec76cebe`
2. Copia el contenido de `intranet-sofipo` de este paquete sobre tu carpeta de **Portal v7** y acepta reemplazar.
3. `pac pages upload --path ./intranet-sofipo`

## B. Limpieza en la interfaz

1. Estudio → Seguridad → **Permisos de tabla** → elimina los 4 creados a mano: **Aviso publicacion**, **Categoría anexar**, **Área anexar** y **Audiencia anexar**. Deja los que empiezan con **Permiso…** y **Publicacion…**.
2. Pendiente de pasos anteriores: Administración del portal → **Páginas web** → *Página principal* (Español) → pestaña **Avanzado** → borra **CSS personalizado** y **JavaScript personalizado** → Guardar. Repite en *Noticias Internas* (Español).

## C. Confirmar tu rol Admin RH

1. Administración del portal → **Contactos** → busca tu nombre. Si aparecen **dos o más contactos** con tu nombre o correo, el bueno es el que tiene tu correo corporativo y la fecha de creación de tu primer inicio de sesión en el sitio.
2. Abre ese contacto → **Relacionado** → **Roles web**: debe aparecer **Admin RH**. Si no aparece: **Agregar rol web existente** → *Admin RH* → **Agregar**.
3. Estudio → **Sincronizar**. Después `https://<tu-sitio>/_services/about` → **Clear cache**.
4. En el sitio, **cierra sesión** y vuelve a iniciarla: los roles se cargan al iniciar sesión.

## D. Prueba

- [ ] Con tu usuario: Inicio y Noticias vuelven a mostrar los avisos.
- [ ] El menú muestra **Publicación** y `/publicacion-avisos/` abre la lista de avisos.
- [ ] Si `/publicacion-avisos/` te lleva a **Acceso denegado**, tu sesión sigue sin el rol: repite la sección C y revisa si hay contactos duplicados.
