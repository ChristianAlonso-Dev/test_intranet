# Intranet SOFIPO · Paso 1: correcciones sobre Portal v4

Este paquete contiene solo los 21 archivos que cambian respecto a tu descarga **Portal v4**, en las mismas rutas de la carpeta `intranet-sofipo`. No se agregó ni se eliminó ningún registro.

## Qué corrige

| # | Archivo | Cambio |
|---|---|---|
| 1 | `webrole.yml` | Admin RH deja de ser el rol de todos los usuarios autenticados |
| 2 | `table-permissions/PermisoAvisos…`, `PermisoCategoriasAviso…` | Se quita el rol Usuarios anónimos (lectura sin sesión) |
| 3 | `web-pages/aviso/…copy.html` (2) | La página Aviso muestra el componente de detalle |
| 4 | `…Página-principal.es-ES.webpage.custom_css.css` y `.custom_javascript.js`, y los mismos de Noticias (4) | Se vacían el CSS y el JS de la primera entrega, que duplicaban el carrusel |
| 5 | `web-pages/acerca-de-nosotros/…yml`, `preguntas-frecuentes/…yml` (4) | Las páginas pasan a estado Borrador |
| 6 | `weblink-sets/default/…weblink.yml` | Menú: Inicio, Noticias. Acerca de Nosotros y Preguntas Frecuentes quedan inactivos |
| 7 | `…Página-principal…webpage.yml`, `…Noticias-Internas…webpage.yml` (4) | Título de página Inicio y Noticias, para el breadcrumb |
| 8 | `content-snippets/logo-alt-text/…` | Texto alternativo del logo: "Intranet SOFIPO, ir al inicio" |
| 9 | `sitesetting.yml` | `Profile/ShowMarketingOptionsPanel = False` y `Authentication/Registration/InvitationEnabled = False` |
| 10 | `web-templates/header/Header.webtemplate.source.html` | Se quitan los comentarios del bloque de estilos; las reglas quedan iguales |

## Cómo aplicarlo

1. **Respaldo:** descarga el estado actual en una carpeta nueva:
   `pac pages download --path ./respaldo-paso1 --webSiteId a5595b5a-e6e0-4342-a230-25a2ec76cebe`
2. **Antes de copiar,** confirma que la carpeta sobre la que vas a trabajar es la de Portal v4, sin cambios posteriores. Si modificaste algo después, avísame antes de copiar.
3. Copia el contenido de `intranet-sofipo` de este paquete sobre tu carpeta `intranet-sofipo` y acepta reemplazar.
4. Sube los cambios: `pac pages upload --path ./intranet-sofipo`
5. En el estudio pulsa **Sincronizar**. Después abre `https://<tu-sitio>/_services/about` y pulsa **Clear cache**.

## Verificación en la interfaz (obligatoria)

Los cambios de seguridad se revisan en la interfaz, porque son los que más importa que hayan quedado aplicados:

- [ ] Administración del portal → **Roles web** → Admin RH: *Rol de usuarios autenticados* = **No**.
- [ ] Usuarios autenticados: *Rol de usuarios autenticados* = **Sí**.
- [ ] Estudio → Seguridad → **Permisos de tabla** → PermisoAvisos y PermisoCategoriasAviso: solo el rol **Usuarios autenticados**.
- [ ] Administración del portal → **Vínculos web**: Acerca de Nosotros y Preguntas Frecuentes en estado **Inactivo**.
- [ ] Administración del portal → **Páginas web**: Acerca de Nosotros y Preguntas Frecuentes (principal y Español) en **Borrador**.
- [ ] **Páginas web** → Página principal y Noticias Internas (Español) → pestaña Avanzado: CSS y JavaScript personalizados **vacíos**.

Si algún punto no quedó, aplícalo a mano en esa misma pantalla.

## Prueba en el sitio

- [ ] El menú dice **Inicio · Noticias**.
- [ ] El carrusel muestra **un punto por cada aviso destacado**.
- [ ] **Leer más** abre el detalle del aviso, con breadcrumb Inicio › Noticias › título.
- [ ] En **Noticias** funcionan la búsqueda, los chips y la paginación.
- [ ] En una ventana de incógnito, sin sesión, **no** se ven avisos.

Al terminar, haz un `pac pages download` nuevo y comparte el zip para validar el resultado.
